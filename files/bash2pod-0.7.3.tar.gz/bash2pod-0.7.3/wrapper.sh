#!/bin/sh
while :; do
./bash2pod >> bash2pod.log
sleep 120 #something went wrong but wait 2 minutes before retrying
done
