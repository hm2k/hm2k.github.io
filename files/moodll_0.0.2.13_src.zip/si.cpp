// hmm 

#include "windows.h"
#include "string.h"
#include "stdio.h"
#include "si.h"

CSysInfo::CSysInfo()
{
	// Constructor
	ZeroMemory(pstrUptime,100);
	ZeroMemory(pstrCPU,100);
	ZeroMemory(pstrOSInfo,100);
	ZeroMemory(pstrMemInfo,100);
	ZeroMemory(pstrVersion,100);
}

CSysInfo::~CSysInfo()
{
	// Destructor
}

void CSysInfo::UpdateUptime()
{
	// Updates Uptime var
	unsigned int intWeeks = 0;
	unsigned int intDays = 0;
	unsigned int intHours = 0;
	unsigned int intMinutes = 0;
	unsigned int intCurPos = 0;
	unsigned int intSeconds = 0;
	unsigned long lintTicks;

	lintTicks = GetTickCount();
	intSeconds = (lintTicks / 1000) % 60;
	intMinutes = ( (lintTicks / 1000) / 60) % 60;
	intHours = ( ( (lintTicks / 1000) / 60) / 60) % 24;
	intDays = ( ( ( (lintTicks / 1000) / 60) / 60) / 24) % 7;
    intWeeks = ( ( ( ( (lintTicks / 1000) / 60) / 60) / 24) / 7) % 52; // fuck months :)

	if (intWeeks > 0) {
		_ui64toa(intWeeks,pstrUptime+intCurPos,10);
		intCurPos += 1;
		if (intWeeks > 9) { intCurPos += 1; }
		strcpy(pstrUptime+intCurPos, "w");
		intCurPos += 1;
	}

	if (intDays > 0) { 
		_ui64toa(intDays,pstrUptime+intCurPos,10);
		intCurPos += 1;
		if (intDays > 9) { intCurPos += 1; }
		strcpy(pstrUptime+intCurPos, "d");
		intCurPos += 1;
	}

	if (intHours > 0) {
		_ui64toa(intHours,pstrUptime+intCurPos,10);
		intCurPos += 1;
		if (intHours > 9) { intCurPos += 1; }
		strcpy(pstrUptime+intCurPos, "h");
		intCurPos += 1;
	}

	if (intMinutes > 0) {
		_ui64toa(intMinutes,pstrUptime+intCurPos,10);
		intCurPos += 1;
		if (intMinutes > 9) { intCurPos += 1; }
		strcpy(pstrUptime+intCurPos, "m");
		intCurPos += 1;
	}

	if (intSeconds > 0) {
		_ui64toa(intSeconds,pstrUptime+intCurPos,10);
		intCurPos += 1;
		if (intSeconds > 9) { intCurPos += 1; }
		strcpy(pstrUptime+intCurPos, "s");
		intCurPos += 1;
	}


}

void CSysInfo::UpdateCPU()
{
	// Updates CPU var
    SYSTEM_INFO sysi;
	char strProcessor[50] = "";
	CTimer timer;

	long tickslong;
	long tickslongextra;
	timer.Start(); Sleep(1000); 
	unsigned cpuspeed100 = (unsigned)(timer.Stop()/10000);
	tickslong = cpuspeed100/100;
	tickslongextra = cpuspeed100-(tickslong*100);

	GetSystemInfo(&sysi);
	_ui64toa(sysi.dwNumberOfProcessors,pstrCPU,10);
    strcat(pstrCPU,"-");
    GetProcessorType(strProcessor);
    strcat(pstrCPU,strProcessor);
    strcat(pstrCPU,", ");
    _ui64toa(tickslong,pstrCPU+strlen(pstrCPU),10);
	//strcat(pstrCPU,".");
    //_ui64toa(tickslongextra,pstrCPU+strlen(pstrCPU),10);
    strcat(pstrCPU,"MHz");


}

void CSysInfo::UpdateOSInfo()
{
	// Updates OSInfo var
    // fills our char array with full os version
	// e.g. Windows 98 (4.10 - 1998)
	//		Windows 2000 Professional, Service Pack 1 (5.0 - 2195)
	ZeroMemory(pstrOSInfo,sizeof(pstrOSInfo));
	OSVERSIONINFO osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);

	switch(osvi.dwPlatformId)
	{
		case VER_PLATFORM_WIN32s:
		{
			// Win32s on Win3.1
			strcpy(pstrOSInfo,"Win32s on Windows 3.1");
			break;
		}
		case VER_PLATFORM_WIN32_WINDOWS:
		{
			// Windows 95/98/ME
			if (osvi.dwMajorVersion == 4) {
				if (osvi.dwMinorVersion == 0) {
					// Windows 95
                    strcpy(pstrOSInfo,"Windows 95");
				} else if (osvi.dwMajorVersion == 4 && (osvi.dwBuildNumber & 0xFFFF)<2250) {
					// Windows 98
                    strcpy(pstrOSInfo,"Windows 98");
				} else if (osvi.dwMajorVersion == 4 && (osvi.dwBuildNumber & 0xFFFF)>=2250) {
                    strcpy(pstrOSInfo,"Windows ME");
				}
			} else { strcpy(pstrOSInfo,"Unknown Windows 9X Kernel OS"); }
			// Format the version (major.minor - build)
			strcat(pstrOSInfo," (");
			_ui64toa((osvi.dwMajorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,".");
			_ui64toa((osvi.dwMinorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo," - ");
			_ui64toa((osvi.dwBuildNumber & 0xFFFF),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,")");
			break;
		}
		case VER_PLATFORM_WIN32_NT:
		{
			// Windows NT/2000
			if (osvi.dwMajorVersion <= 4) {
				// Windows NT
				HKEY hKey;
				char szProductType[80];
				DWORD dwBufLen;
				RegOpenKeyEx( HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\ProductOptions",0, KEY_QUERY_VALUE, &hKey );
				RegQueryValueEx( hKey, "ProductType", NULL, NULL,(LPBYTE) szProductType, &dwBufLen);
				RegCloseKey( hKey );
				if ( lstrcmpi( "WINNT", szProductType) == 0 )
					strcpy(pstrOSInfo,"Windows NT Workstation");
				if ( lstrcmpi( "SERVERNT", szProductType) == 0 )
					strcpy(pstrOSInfo,"Windows NT Server");
				if ( strlen(osvi.szCSDVersion) > 0 ) {
					// Service Pack Installed
					strcat(pstrOSInfo,", ");
					strcat(pstrOSInfo,osvi.szCSDVersion);
				}
			} else if (osvi.dwMajorVersion == 5) {
				// Windows NT 5.X (2000)
				// Use new version info
				OSVERSIONINFOEX osvi2k;
				ZeroMemory(&osvi2k, sizeof(OSVERSIONINFOEX));
				osvi2k.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
				GetVersionEx((OSVERSIONINFO *)&osvi2k);
				strcpy(pstrOSInfo,"Windows 2000");
				switch(osvi2k.wProductType) {
					case VER_NT_WORKSTATION:
					{
						// Windows 2000 Professional
						strcat(pstrOSInfo," Professional");
						break;
					}
					case VER_NT_DOMAIN_CONTROLLER:
					{
						// Windows 2000 Domain Controller
						strcat(pstrOSInfo," Domain Controller");
						break;
					}
					case VER_NT_SERVER:
					{
						// Windows 2000 Server
						strcat(pstrOSInfo," Server");
						break;
					}
				}
				if ( strlen(osvi2k.szCSDVersion) > 0 ) {
					// Service Pack Installed
					strcat(pstrOSInfo,", ");
					strcat(pstrOSInfo,osvi2k.szCSDVersion);
				}
			} else { strcpy(pstrOSInfo,"Unknown Windows NT Kernel OS"); }
			// Format the version (major.minor - build)
			strcat(pstrOSInfo," (");
			_ui64toa((osvi.dwMajorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,".");
			_ui64toa((osvi.dwMinorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo," - ");
			_ui64toa((osvi.dwBuildNumber & 0xFFFF),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,")");
			break;
		}
		default:
		{
			// Fuck knows
			strcpy(pstrOSInfo,"Unknown");
			break;
		}
	}
}

void CSysInfo::UpdateMemInfo()
{
	// Updates MemInfo var
	MEMORYSTATUS memi;
	DWORD ramtotal;
	DWORD ramused;
	float pctused = 0;

	GlobalMemoryStatus(&memi);
	ramtotal = (((memi.dwTotalPhys / 1024) / 1024) + 1); // stops the peons whining :|
	ramused = ramtotal - (((memi.dwAvailPhys / 1024) / 1024) + 1);
	strcpy(pstrMemInfo,"Usage: ");
    _ui64toa(ramused,pstrMemInfo+strlen(pstrMemInfo),10);
    strcat(pstrMemInfo,"/");
    _ui64toa(ramtotal,pstrMemInfo+strlen(pstrMemInfo),10);
	strcat(pstrMemInfo,"MB (");
	pctused = (((float)ramused / (float)ramtotal)*100);
    sprintf(pstrMemInfo+strlen(pstrMemInfo),"%.2f",pctused);
	strcat(pstrMemInfo,"%)");
}

void CSysInfo::UpdateVersion()
{
	// Updates Version var
	strcpy(pstrVersion,VERSION);
}

// Other functions used by this class

void GetProcessorType(char *proctext)

{
	DWORD regEAX = 0;
	DWORD regEBX = 0;

    char strVendorID[13];
	ZeroMemory(strVendorID,13);

    GetProcessorVendor((char*)&strVendorID);

	__try { 
		_asm {
			mov eax, 1		// set up CPUID to return processor version and features
						    //	0 = vendor string, 1 = version info, 2 = cache info
			CPUID			// code bytes = 0fh,  0a2h
			and eax, 03fffh		// type, family, model, stepping returned in eax
			mov regEAX, eax
			mov regEBX, ebx
		}
	} __except(EXCEPTION_EXECUTE_HANDLER) {regEAX = 0;}


	DWORD type, family, model, stepping, brand;
	int extra;

	type     = (regEAX>>12) & 0x3;
	family   = (regEAX>>8)  & 0xf;
	model    = (regEAX>>4)  & 0xf;
	stepping =  regEAX      & 0xf;
    brand    =  (regEBX>>12);
    extra = GetProcessorExtra();

	// strcpy(strVendorID,"TestTestTest");

	if ( strcmp(strVendorID,"GenuineIntel") == 0 )
	{
		strcpy(proctext,"Intel ");
		// Intel CPUs
		if (family == 5)
			strcat(proctext,INTEL_P1_NORMAL);
		else if (family == 6 && (model == 1 || model == 2))
			strcat(proctext,INTEL_P1_PRO);
		else if (family == 6 && model == 3)
			strcat(proctext,INTEL_P2_NORMAL);
		else if (family == 6 && model == 4)
			strcat(proctext,INTEL_P2_NORMAL);
		else if (family == 6 && model == 5 && extra == 1)
			strcat(proctext,INTEL_P2_NORMAL);
		else if (family == 6 && model == 5 && extra == 2)
			strcat(proctext,INTEL_P2_CELERON);
		else if (family == 6 && model == 5 && extra == 3)
			strcat(proctext,INTEL_P2_XEON);
		else if (family == 6 && model == 6)
			strcat(proctext,INTEL_P2_CELERON);
		else if (family == 6 && model == 7 && extra == 1)
			strcat(proctext,INTEL_P3_NORMAL);
		else if (family == 6 && model == 7 && extra == 2)
			strcat(proctext,INTEL_P3_CELERON);
		else if (family == 6 && model == 7 && extra == 3)
			strcat(proctext,INTEL_P3_XEON);
		else if (family == 6 && model == 8 && extra == 1)
			strcat(proctext,INTEL_P3_NORMAL);
		else if (family == 6 && model == 8 && extra == 2)
			strcat(proctext,INTEL_P3_CELERON);
		else if (family == 6 && model == 8 && extra == 3)
			strcat(proctext,INTEL_P3_XEON);
		else if (family == 6 && model == 0xA)
			strcat(proctext,INTEL_P3_XEON);
	}
	else if ( strcmp(strVendorID,"AuthenticAMD") == 0 )
	{
        strcpy(proctext,"AMD ");
	    // AMD CPUs
		if (family == 5 && model < 4)
			strcat(proctext,AMD_K5);
		else if (family == 5 && model == 6)
			strcat(proctext,AMD_K6);
		else if (family == 5 && model == 7)
			strcat(proctext,AMD_K6);
		else if (family == 5 && model == 8)
			strcat(proctext,AMD_K6_2);
		else if (family == 5 && model == 9)
			strcat(proctext,AMD_K6_3);
		else if (family == 5 && model == 0xD)
			strcat(proctext,AMD_K6_3PLUS);
		else if (family == 6 && model == 1)
			strcat(proctext,AMD_K7);
		else if (family == 6 && model == 2)
			strcat(proctext,AMD_K7);
		else if (family == 6 && model == 3)
			strcat(proctext,AMD_K7);
		else if (family == 6 && model == 4)
			strcat(proctext,AMD_K7);
	}
	else if ( strcmp(strVendorID,"CyrixInstead") == 0 )
	{
        strcpy(proctext,"Cyrix :/");
	    // Cyrix CPUs
	}
	else
	{
		// Unknown CPUs
	    strcpy(proctext,strVendorID);
		strcat(proctext," T(");
		_itoa(type,proctext+strlen(proctext),10);
		strcat(proctext,")F(");
		_itoa(family,proctext+strlen(proctext),10);
		strcat(proctext,")M(");
		_itoa(model,proctext+strlen(proctext),10);
		strcat(proctext,")S(");
		_itoa(stepping,proctext+strlen(proctext),10);
		strcat(proctext,")B(");
        _itoa(brand,proctext+strlen(proctext),10);
		strcat(proctext,")");
	}

    

}

void GetProcessorVendor(char *vid)
{

	DWORD regEBX = 0x00000000;
	DWORD regECX = 0x00000000;
	DWORD regEDX = 0x00000000;
	DWORD *curDWORD; // point to the byte to convert

	int reps = 0;

	__try { 
		_asm {
			mov eax, 0
			CPUID
			mov regEBX, ebx
			mov regECX, ecx
			mov regEDX, edx
		}
	} __except(EXCEPTION_EXECUTE_HANDLER) { return; }

	curDWORD = &regEBX;
	strncpy(vid,(char*)curDWORD,4);
	curDWORD = &regEDX;
	strncat(vid,(char*)curDWORD,4);
	curDWORD = &regECX;
	strncat(vid,(char*)curDWORD,4);


}

int GetProcessorExtra(void)
{

    // Function to return whether chip is plain old PII/PIII, Celeron or Xeon 
	// 1 = Normal, 2 = Celeron (0/128K cache), 3 = XEON (>512KB cache)

    DWORD regEAX, regEBX, regECX, regEDX;

	__try { 
		_asm {
			mov eax, 2
			CPUID
			mov regEAX, eax
			mov regEBX, ebx
			mov regECX, ecx
			mov regEDX, edx
		}
	} __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }

	// enumerate through each value
	// 15 checks in total, AL need not be checked (but is currently), should = 0x01
	// EAX
    // (((regEAX & 0xFF000000) >> 24) == 0x40) - Celeron 0K L2 Cache
	// (((regEAX & 0xFF000000) >> 24) == 0x41) - Celeron 128K L2 Cache
	// (((regEAX & 0xFF000000) >> 24) > 0x43) - Xeon

	DWORD ShiftTable[4] =
	{
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF
	};

    DWORD *regCurrent[4] =
	{
		&regEAX, &regEBX, &regECX, &regEDX
	};
	
	for ( int regreps = 0; regreps < 4; regreps++ ) {
		for ( int shreps = 0; shreps < 4; shreps++ ) {
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x40) { return 2; }
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x41) { return 2; }
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x44) { return 3; }
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x45) { return 3; }
		}
    }

    return 1;
}