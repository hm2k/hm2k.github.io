#include "main.h"

typedef DWORD (CALLBACK* LPGETIFTABLE)(PMIB_IFTABLE, PULONG, BOOL);
LPGETIFTABLE get_if_table;
typedef DWORD (CALLBACK* LPGETIFTABLE)(PMIB_IFTABLE, PULONG, BOOL);
typedef DWORD (APIENTRY *LPRASENUMCCONNECTIONSA)(LPRASCONNA,LPDWORD,LPDWORD );
LPRASENUMCCONNECTIONSA RasEnumConnectionsA;

DWORD band()
{
  DWORD download=0,download2=0,band=0;

  char *buffer = NULL;
  DWORD count;
  HINSTANCE ip_help_handle = NULL;
  DWORD getiftable_rc;
  ULONG buf_size;
  MIB_IFROW *ifr;
  MIB_IFTABLE *ift;
  DWORD ii=0,jj=0;

  ip_help_handle = LoadLibrary("iphlpapi.dll");
  if (ip_help_handle == NULL)
	  return 0;
  get_if_table = (LPGETIFTABLE) GetProcAddress(ip_help_handle, "GetIfTable");
  if (get_if_table == NULL)
	  return 0;
  buf_size = 0;
  getiftable_rc = (*get_if_table)((PMIB_IFTABLE) buffer, &buf_size, TRUE);
  if (getiftable_rc != ERROR_INSUFFICIENT_BUFFER)
	  return 0;
  buffer = (char *) malloc(buf_size);
  if (buffer == NULL)
	  return 0;
  memset(buffer, 0, buf_size);
  getiftable_rc = (*get_if_table)((PMIB_IFTABLE) buffer, &buf_size, TRUE);
  if (getiftable_rc != NO_ERROR)
	  return 0;
  ift = (MIB_IFTABLE *) buffer;
  count = ift->dwNumEntries;
  for (ii = 0; ii < count ; ii++)
  {
	  ifr = (ift->table) + ii;
	  if(ifr->dwInUcastPkts > 0 && ifr->dwOutUcastPkts > 0)
	  {
		  if(ifr->dwInUcastPkts == ifr->dwOutUcastPkts)
			  goto next;
		 download=(DWORD)ifr->dwInOctets;
		 goto exitproc;
next:
		 ii=ii;
	  }
  }
exitproc:
  free(buffer);
  FreeLibrary(ip_help_handle);
  return download;
}

DWORD upband()
{
  DWORD download=0,download2=0,band=0;
  char *buffer = NULL;
  DWORD count;
  HINSTANCE ip_help_handle = NULL;
  DWORD getiftable_rc;
  ULONG buf_size;
  MIB_IFROW *ifr;
  MIB_IFTABLE *ift;
  DWORD ii=0,jj=0;
  ip_help_handle = LoadLibrary("iphlpapi.dll");
  if (ip_help_handle == NULL)
	  return 0;
  get_if_table = (LPGETIFTABLE) GetProcAddress(ip_help_handle, "GetIfTable");
  if (get_if_table == NULL)
	  return 0;
  buf_size = 0;
  getiftable_rc = (*get_if_table)((PMIB_IFTABLE) buffer, &buf_size, TRUE);
  if (getiftable_rc != ERROR_INSUFFICIENT_BUFFER)
	  return 0;
  buffer = (char *) malloc(buf_size);
  if (buffer == NULL)
	  return 0;
  memset(buffer, 0, buf_size);
  getiftable_rc = (*get_if_table)((PMIB_IFTABLE) buffer, &buf_size, TRUE);
  if (getiftable_rc != NO_ERROR)
	  return 0;
  ift = (MIB_IFTABLE *) buffer;
  count = ift->dwNumEntries;
  for (ii = 0; ii < count ; ii++)
  {
	  ifr = (ift->table) + ii;
	  if(ifr->dwInUcastPkts > 0 && ifr->dwOutUcastPkts > 0)
	  {
		  if(ifr->dwInUcastPkts == ifr->dwOutUcastPkts)
			  goto next;
		 download=(DWORD)ifr->dwOutOctets;
		 goto exitproc;
next:
		 ii=ii;
	  }
  }
exitproc:
  free(buffer);
  FreeLibrary(ip_help_handle);
  return download;
}