Acutally, read ClownScript.txt, hell it's not that big.  It also tells you the commands and how to install.  Read history.txt if your bored too.

  - Clown-Man