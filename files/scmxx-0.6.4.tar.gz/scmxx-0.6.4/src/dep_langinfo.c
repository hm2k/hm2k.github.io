/***************************************************************************
 *   copyright           : (C) 2002 by Hendrik Sattler                     *
 *   mail                : post@hendrik-sattler.de                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
 * this should replace the functionality of nl_langinfo
 * but only as far as needed by our program and only for fixed values
 *
 * This is pretty dumb but easy way to try it, I hope it works alright
 */

#include "depincludes.h"
inline char* nl_langinfo(char* type) {
  return type;
}
