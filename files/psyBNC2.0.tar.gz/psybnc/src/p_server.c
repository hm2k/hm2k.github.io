/************************************************************************
 *   psybnc2.1.1, src/p_server.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_server.c, v 2.1.1 2000/03/17 20:20:00 psychoid Exp $";
#endif

#define P_SERVER

#include <p_global.h>

int serverinit(int usern,int msgn)
{
    FILE *userb;
    char fname[40];
    char buf[200];
    char *zer;
    pcontext;
    if (user(usern)->srinit == 0) return 0x0;
    snprintf(fname,sizeof(fname),"USER%d.MOTD",usern);
    if (msgn == 1) {
       zer=strstr(ircbuf," 001 ");
       if(zer!=NULL)
       {
           zer=strchr(zer,'@');
	   if(zer!=NULL)
	   {
	       zer++;
	       *zer=0;
	       if(strlen(ircbuf)+strlen(user(usern)->host)<sizeof(ircbuf))
	           strcat(ircbuf,user(usern)->host);
	   }
       }
       user(usern)->welcome=1;
       if (strlen(user(usern)->lastwhois)) {
          rejoinwhois(usern);
       }
       snprintf(user(usern)->server,sizeof(user(usern)->server),"%s",ircfrom);
       snprintf(user(usern)->nick,sizeof(user(usern)->nick),"%s",ircto);
       snprintf(user(usern)->firstnick,sizeof(user(usern)->firstnick),"%s",ircto);
       snprintf(buf,sizeof(buf),"MODE %s +i\r\n",ircto);
       writesock(user(usern)->outsock,buf);
       userb=fopen(fname,"w");
       user(usern)->gotop=0;
    } else {
       userb=fopen(fname,"a");
    }
    fprintf(userb,ircbuf);
    fclose(userb);
    return 1;
}

int pong(int usern)
{
    char buf[400];
    pcontext;
    if (user(usern)->outstate != STD_CONN) return 0x0;
    /* we try to regain nick on ping, antiidle, rejoin channels, reop us and save actual channel stats */
    if (strlen(irccontent)>0) { /* some servers need ponged content of ping */
	snprintf(buf,sizeof(buf),"PONG :%s\r\n",irccontent);
    } else {
	snprintf(buf,sizeof(buf),"PONG :%s\r\n",user(usern)->server);
    }
    writesock_URGENT(user(usern)->outsock,buf);
    user(usern)->autopongreply=0;
    if (user(usern)->instate != STD_CONN) {
       if (strlen(user(usern)->lastwhois)) {
          rejoinwhois(usern);
       }
       snprintf(buf,sizeof(buf),"PRIVMSG %s :away\r\n",user(usern)->nick);
       writesock(user(usern)->outsock,buf);
       snprintf(buf,sizeof(buf),"WHOIS %s\r\n",user(usern)->nick);
       writesock(user(usern)->outsock,buf);
       if(*user(usern)->awaynick!=0)
           snprintf(buf,sizeof(buf),"NICK %s\r\n",user(usern)->awaynick);
       else	
           snprintf(buf,sizeof(buf),"NICK %s\r\n",user(usern)->wantnick);
       writesock(user(usern)->outsock,buf);
    }
    user(usern)->kicks = 0;        
}

int nickused(int usern)
{
    char buf[400];
    char nnick[64];
    int cnt;
    pcontext;
    if (user(usern)->instate == STD_CONN && user(usern)->parent==0) {
	writesock(user(usern)->insock,ircbuf);
	return -1; /* if we are the master user and he is connected,
		      his client should care for nick problems. */
    }
    if (user(usern)->welcome == 1 && user(usern)->acollide ==0) {
	return -1; /* we fuck the jupe, it happened after we tried to change the nick */
		   /* i am going to drink a coke now *g* */
    }
    cnt=1;
    snprintf(nnick,sizeof(nnick),"%s",randstring(9));
    while((cnt<5) && (user(usern)->wantnick[cnt]))
    {
        nnick[cnt]=user(usern)->wantnick[cnt];
	cnt++;
    }
    cnt=cnt+4;
    if (cnt<9) nnick[cnt]=0x0;
    snprintf(buf,sizeof(buf),"NICK %s\r\n",nnick);
    writesock(user(usern)->outsock,buf);
    return 0x0;
}

int gotnick(int usern)
{
    pcontext;
    if (strlen(ircnick) == strlen(user(usern)->nick)) {
       if (strstr(ircnick,user(usern)->nick)) {
          snprintf(user(usern)->nick,sizeof(user(usern)->nick),ircto);
	  /* removed the wanted nick set to get by server nick, jupe done in nickused */
       }
    }
}

int rejoinwhois(int usern)
{
    int req;
    char buf[8192];
    char chan[255];
    char ebuf[8192];
    char *p1,*p2;
    int op, vt;
    int stlen;
    pcontext;
    snprintf(buf,sizeof(buf),"%s",user(usern)->lastwhois);
    req = 1;
    while(req==1)
    {
        p1=strchr(buf,' ');
	if (p1 != NULL) {
	    stlen = p1-buf;
	    if (stlen<=1) return 0x0; /* this is important, some responses have " " at end */
	    stlen++;
	    snprintf(chan,stlen,"%s",buf);
	    p1++;
	    snprintf(ebuf,sizeof(ebuf),"%s",p1);
	    snprintf(buf,sizeof(buf),"%s",ebuf);
	} else {
	    req = 0;
	    snprintf(chan,sizeof(chan),"%s",buf);
	}
	p1 = chan ; op= 0;
	if (*p1 == '@') p1++;
	if (*p1 == '+') p1++;
	p2=getchankey(usern,p1);
	if(p2!=NULL)
	    snprintf(ebuf,sizeof(ebuf),"JOIN %s :%s\r\n",p1,p2);
	else
	    snprintf(ebuf,sizeof(ebuf),"JOIN %s\r\n",p1);
	writesock(user(usern)->outsock,ebuf);
	if (strlen(buf)<=1) return 0x0;
    }
    return 0x0;
}

int checkopstate(int usern)
{
    int req;
    char buf[8192];
    char chan[255];
    char ebuf[8192];
    char *p1;
    int op, vt;
    int stlen;
    pcontext;
    snprintf(buf,sizeof(buf),"%s",user(usern)->lastwhois);
    req = 1;
    while(req==1)
    {
        p1=strchr(buf,' ');
	if (p1 != NULL) {
	    stlen = p1-buf;
	    if (stlen<=1) goto endchk; /* this is important, some responses have " " at end */
	    stlen++;
	    snprintf(chan,stlen,"%s",buf);
	    p1++;
	    snprintf(ebuf,sizeof(ebuf),"%s",p1);
	    snprintf(buf,sizeof(buf),"%s",ebuf);
	} else {
	    req = 0;
	    snprintf(chan,sizeof(chan),"%s",buf);
	}
	p1 = chan ; op= 1;
	if (*p1 == '@') { p1++; op = 0; }
	if (*p1 == '+') p1++;
	if (op == 1) {
 	   snprintf(ebuf,sizeof(ebuf),"WHO %s\r\n",p1);
	   writesock(user(usern)->outsock,ebuf);
	}   
	if (user(usern)->doaway) {
 	   snprintf(ebuf,sizeof(ebuf),"PRIVMSG %s :%cACTION is away (%s)%c\r\n",p1,1,user(usern)->leavemsg,1);
	   writesock_DELAY(user(usern)->outsock,ebuf,3);
	}
	if (strlen(buf)<=1) goto endchk;
    }
endchk:
    user(usern)->doaway=0;
    return 0x0;
}

int whois(int usern)
{
    int req;
    char buf[8192];
    char chan[255];
    char ebuf[8192];
    char netc[15];
    char *p1;
    char mynick[64];
    int op, vt;
    int stlen;
    pcontext;
    snprintf(buf,sizeof(buf),"%s",irccontent);
    snprintf(user(usern)->lastwhois,1023,"%s",buf);
    user(usern)->afterquit=0;
    if (user(usern)->parent != 0)
    {
	snprintf(netc,sizeof(netc),"#%s~",user(usern)->network);
	snprintf(mynick,sizeof(mynick),"%s",user(user(usern)->parent)->nick);
    } else {
	memset(netc,0x0,sizeof(netc));
	snprintf(mynick,sizeof(mynick),"%s",user(usern)->nick);
    }
    req = 1;
    while(req==1)
    {
        p1=strchr(buf,' ');
	if (p1 != NULL) {
	    stlen = p1-buf;
	    if (stlen<=1) return 0x0; /* this is important, some responses have " " at end */
	    stlen++;
	    snprintf(chan,stlen,"%s",buf);
	    p1++;
	    snprintf(ebuf,sizeof(ebuf),"%s",p1);
	    snprintf(buf,sizeof(buf),"%s",ebuf);
	} else {
	    req = 0;
	    snprintf(chan,sizeof(chan),"%s",buf);
	}
	p1 = chan ; op= 0; vt=0;
	if (*p1 == '@') { op=1;p1++; }
	if (*p1 == '+') { vt=1;p1++; }
	snprintf(ebuf,sizeof(ebuf),":%s!%s@%s JOIN :%s%s\r\n",mynick,user(usern)->login,user(usern)->host,netc,p1);
	writesock(user(usern)->insock,ebuf);
	/* for bitchx -> we assume no users first */
	snprintf(ebuf,sizeof(ebuf),":%s 386 %s %s%s :End of NAMES list.\r\n",user(usern)->server,mynick,netc,p1);
	writesock(user(usern)->insock,ebuf);
	/* going on as always */
	if (op == 1) {
	    snprintf(ebuf,sizeof(ebuf),":irc.psychoid.net MODE %s%s +o %s\r\n",netc,p1,mynick);
	    writesock(user(usern)->insock,ebuf);
	}
	if (vt == 1) {
	    snprintf(ebuf,sizeof(ebuf),":irc.psychoid.net MODE %s%s +v %s\r\n",netc,p1,mynick);
	    writesock(user(usern)->insock,ebuf);
	}
	snprintf(ebuf,sizeof(ebuf),"NAMES %s\r\n",p1);
	writesock_DELAY(user(usern)->outsock,ebuf,1);
	snprintf(ebuf,sizeof(ebuf),"TOPIC %s\r\n",p1);
	writesock_DELAY(user(usern)->outsock,ebuf,1);
	if (strlen(buf)<=1) return 0x0;
    }
    user(usern)->instate = STD_CONN;
    return 0x0;
}

int checkbans(int usern)
{
    char file[40];
    char buf[4096];
    char bc=')';
    char cfile[40];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (user(usern)->kicks >= 10) return 0x0;
    if (checkstrings(user(usern)->bans)) {
        if (*ehost==bc) return 0x0;
	snprintf(buf,sizeof(buf),"MODE %s +b %s",ircto,ehost);
	writesock(user(usern)->outsock,buf);
	snprintf(buf,sizeof(buf),"KICK %s %s :banned: %s",ircto,ircnick,eparm);
	writesock(user(usern)->outsock,buf);
	user(usern)->kicks++;
	if (user(usern)->instate == STD_CONN) {
   	   snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s(%s) matches ban(%s), kickbanned on %s",user(userp)->nick,ircnick,ircfrom,ehost,ircto);
	   writesock(user(usern)->insock,buf);    
	}
    }
}

int checkautoop(int usern)
{
    char file[40];
    char buf[4096];
    char bc=')';
    char cfile[40];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (user(usern)->kicks >= 10) return 0x0;
    if (checkstrings(user(usern)->aops)) {
        if (*ehost==bc) return 0x0;
	snprintf(buf,sizeof(buf),"MODE %s +o %s",ircto,ircnick);
	writesock(user(usern)->outsock,buf);
	user(usern)->kicks++;
	if (user(usern)->instate == STD_CONN) {
   	   snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s(%s) matches autoop(%s), opped on %s",user(userp)->nick,ircnick,ircfrom,ehost,ircto);
	   writesock(user(usern)->insock,buf);    
	}
    }
}

int checkop(int usern)
{
    char file[40];
    char buf[4096];
    char cfile[40];
    char *pt;
    char *pt1;
    char bc='-';
    char *pt2;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    pt1 = irccontent +3;
    if (*pt1 == 0) return -1;
    pt = strchr(pt1,' '); /* the pass */
    pt2 = strchr(irccontent,'#'); /* the chan */
    if (pt == NULL) return -1;
    if (pt2 == NULL) return -1;
    *pt=0;pt=pt1;
    snprintf(ircto,sizeof(ircto),"%s",pt2);
    if (checkstrings(user(usern)->ops)) {
        if (*ehost==bc) return 0x0;
	if (strstr(pt,eparm)) {
	  if (strlen(pt)==strlen(eparm)) {
 	    snprintf(buf,sizeof(buf),"MODE %s +o %s",pt2,ircnick);
    	    writesock(user(usern)->outsock,buf);
	    if (user(usern)->instate == STD_CONN) {
   	       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s(%s) matches op (%s), opped on %s",user(userp)->nick,ircnick,ircfrom,ehost,pt2);
	       writesock(user(usern)->insock,buf);    
  	       return 0x0;
	    }
	  }    
	}
    }
    return -1;
}

int getops(int usern)
{
    struct datalinkt *dccbot;
    char file[40];
    char buf[4096];
    char bc='-',bc1=')';
    char cfile[40];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strstr(irccontent,"@") == NULL) return 0x0;
    if (checkstrings(user(usern)->askops)) {
        if (*ehost==bc || *ehost==bc1) {
	    dccbot=checkdcc(usern,ehost+1);
	    if (dccbot !=NULL)
	    {
		if (dccbot->outstate==STD_CONN)
		{
		    snprintf(buf,sizeof(buf),".op %s %s\r\n",user(usern)->nick,echan);
		    writesock_DELAY(dccbot->outsock,buf,3);
		    user(usern)->gotop=1; /* no multiple asks */
		    return 0x0;
		}
	    }
	    return 0x0;
	}
	user(usern)->gotop=1; /* no multiple asks */
	snprintf(buf,sizeof(buf),"PRIVMSG %s :op %s %s",ircnick,eparm,ircto);
	writesock_DELAY(user(usern)->outsock,buf,3);
	if (user(usern)->instate == STD_CONN) {
   	   snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Asked %s(%s) for op on %s",user(userp)->nick,ircnick,ircfrom,ircto);
	   writesock(user(usern)->insock,buf);    
	}
    }
}

int sendwho(int usern)
{
    char buf[1024];
    pcontext;
    snprintf(buf,sizeof(buf),"WHO %s",ircto);
    writesock(user(usern)->outsock,buf);
}

int performwho(int usern)
{
    char hnick[64];
    char hident[64];
    char hhost[1024];
    char hchan[1024];
    char hbuf[8192];
    char flags[10];
    char *p1;
    char *p2;
    pcontext;
    snprintf(hbuf,sizeof(hbuf),ircbuf);
    p1 = strchr(hbuf,' ');
    if (p1 == NULL) return 0x0;
    p1++;
    p1 = strchr(p1,' ');
    if (p1 == NULL) return 0x0;
    p1++;
    p1 = strchr(p1,' ');
    if (p1 == NULL) return 0x0;
    p1++;
    p2=p1;
    p1 = strchr(p1,' ');
    if (p1 == NULL) return 0x0;
    *p1=0;
    snprintf(hchan,sizeof(hchan),"%s",p2);
    p2=p1;
    p2++;
    p1 = strchr(p2,' ');
    if (p1 == NULL) return 0x0;
    *p1=0;
    snprintf(hident,sizeof(hident),"%s",p2);
    p1++;
    p2 = strchr(p1,' ');
    if (p2 == NULL) return 0x0;
    *p2=0;
    snprintf(hhost,sizeof(hhost),"%s",p1);
    p2++;
    p1 = strchr(p2,' ');
    if (p1 == NULL) return 0x0;
    p1++;
    p2 = strchr(p1,' ');
    if (p2 == NULL) return 0x0;
    *p2 = 0;
    snprintf(hnick,sizeof(hnick),"%s",p1);
    p2++;
    p1 = strchr(p2,' ');
    if (p1 == NULL) return 0x0;
    *p1 = 0;
    snprintf(flags,sizeof(flags),"%s",p2);
    /* here we finally got it all */
    snprintf(ircnick,sizeof(ircnick),"%s",hnick);
    snprintf(ircfrom,sizeof(ircfrom),"%s!%s@%s",hnick,hident,hhost);
    snprintf(ircto,sizeof(ircto),"%s",hchan);
    snprintf(irccontent,sizeof(irccontent),"%s",flags);
    return 0x0;
}

int gotjoin(int usern)
{
    pcontext;
    if (strlen(user(usern)->nick)==strlen(ircnick)) {
	if (strstr(user(usern)->nick,ircnick)) {
	    sendwho(usern);
	}
    } 	
    checkbans(usern);
    checkautoop(usern);
    return 0x0;
}

int msgERROR(int usern)
{
    char buf[400];
    struct socketnodes *lkm;
    pcontext;
    snprintf(buf,sizeof(buf),"User %s (%s) got disconnected (from %s) Reason: %s",user(usern)->login,user(usern)->network,user(usern)->server,irccontent);
    log(buf);
    lkm=getpsocketbysock(user(usern)->outsock);
    if(lkm!=NULL)
	lkm->sock->destructor=NULL;
    killsocket(user(usern)->outsock);
    memset(user(usern)->server,0x0,sizeof(user(usern)->server));
    user(usern)->outstate=STD_NOCON;
    user(usern)->outsock = 0;
    snprintf(buf,sizeof(buf),"USER%d.MOTD",usern);
    oldfile(buf);
    return -1;
}

int msg001(int usern)
{
    pcontext;
    user(usern)->srinit = 1;
    serverinit(usern,1);
    return -1;
}

int msg002to004(int usern)
{
    pcontext;
    if (serverinit(usern,2)) return 0;
    return 1;
}

int msg251to255(int usern)
{
    pcontext;
    if (serverinit(usern,3)) return 0;
    return 1;
}

int msg372to375(int usern)
{
    pcontext;
    if (serverinit(usern,4)) return 0;
    return 1;
}

int msg376(int usern)
{
    pcontext;
    serverinit(usern,4);
/*    if (user(usern)->instate == STD_CONN) {
	repeatserverinit(usern);
    } well, not really :) motd-bug, found by coke */
    user(usern)->srinit = 0;
    return -1;
}

int msg352(int usern)
{
    pcontext;
    if (user(usern)->triggered == 0) {
	if (user(usern)->gotop==0) {
	    performwho(usern);
	    getops(usern);
	}
	return 0;
    }
    return 1;
}

int msg315(int usern)
{
    pcontext;
    user(usern)->gotop=0;
    if (user(usern)->triggered == 0) {
	return 0;
    }
    user(usern)->triggered--;
    return 1;
}

int msg432to437(int usern)
{
    pcontext;
    if (nickused(usern)==0) return 0;
    return 1;
}

int msg319(int usern)
{
    char *pt,*pt2;
    pcontext;
    /* is it me ? since 2.1.1 (HERZ found this one) */
    pt=strchr(ircbuf,' ');
    if(pt==NULL) return 1;
    pt++;
    pt=strchr(pt,' ');
    if(pt==NULL) return 1;
    pt++;
    pt=strchr(pt,' ');
    if(pt==NULL) return 1;
    pt++;
    pt2=strchr(pt,' ');
    if(pt2==NULL) return 1;
    *pt2=0;
    if(strlen(pt)!=strlen(user(usern)->nick)) { *pt2=' '; return 1; }
    if(strstr(pt,user(usern)->nick)!=pt) { *pt2=' '; return 1; }
    *pt2=' ';
    if (user(usern)->instate == STD_WHOIS) {
        whois(usern);
        return 0;	 
    }
    if (user(usern)->instate == STD_NOCON) {
	snprintf(user(usern)->lastwhois,1023,"%s",irccontent);
	user(usern)->afterquit=0;
	checkopstate(usern);
	writeuser(usern);
    }	 
    return 1;
}

int msg311to317(int usern)
{
    pcontext;
    if (user(usern)->outstate == STD_WHOIS || user(usern)->instate == STD_WHOIS) {
	return 0;
    }
    return 1;
}

int msg318(int usern)
{
    pcontext;
    if (user(usern)->outstate == STD_WHOIS) {
	return 0;	 
    }
    if (user(usern)->instate == STD_WHOIS) {
	user(usern)->instate = STD_CONN;
	return 0;
    }	 
    return 1;
}

int msgprivmsg(int usern)
{
    char buf[400];
    char *po;
    pcontext;
#ifdef CRYPT
    checkcrypt(usern);
#endif
#ifdef TRANSLATE
    checktranslate(usern);
#endif
    snprintf(buf,sizeof(buf),"op ");
    po = strstr(irccontent,buf);
    if (po == irccontent) {
	if (checkop(usern) == 0x0) return 0;
    }
    if (strlen(ircto) == strlen(user(usern)->nick) && user(usern)->instate!=STD_CONN) {
	if (strstr(ircto,user(usern)->nick)) {
	    privatelog(usern);
	}
    }
    return 1;
}

int userconnected(int nuser)
{
    int nlink;
    char buf[400];
    struct sockaddr_in sin;
    struct hostent *he;
    pcontext;
    nlink=user(nuser)->vlink;
    if(user(nuser)->pport!=0)
    {
	nlink=0;
	if(user(nuser)->pport==1080) /* socks 4 */
	{
	    he=gethostbyname(user(nuser)->server);
	    if(!he)
	    {
		killsocket(user(nuser)->outsock);
		return 0x0;
	    }
	    memcpy(&sin.sin_addr,he->h_addr,he->h_length);
	    snprintf(buf,sizeof(buf),"\x04\x01%c%c%c%c%c%c",
		(user(nuser)->port>>8) & 0xff,user(nuser)->port & 0xff,
		(char) he->h_addr[0],
		(char) he->h_addr[1],
		(char) he->h_addr[2],
		(char) he->h_addr[3]);
	    send(user(nuser)->outsock,buf,8+1,0);
	    currentsocket->sock->nowfds=1;
	} else
	if(user(nuser)->pport==23) /* wingate */
	{
	    snprintf(ircbuf,sizeof(ircbuf),"%s %d\r\n",user(nuser)->server,user(nuser)->port);
    	    writesock(user(nuser)->outsock,ircbuf);
	    currentsocket->sock->nowfds=1;
	} else { /* any other port, we assume a web proxy */
    	    snprintf(ircbuf,sizeof(ircbuf),"CONNECT %s:%d HTTP/1.0\n\n",user(nuser)->server,user(nuser)->port);
	    send(user(nuser)->outsock,ircbuf,strlen(ircbuf)+1,0);
	    currentsocket->sock->nowfds=1;
	}
    } else
    if (nlink!=0)
    {
        if (datalink(nlink)->type !=1 && datalink(nlink)->type!=2)
    	    nlink=0;
        if (datalink(nlink)->outstate!=STD_CONN && datalink(nlink)->instate!=STD_CONN)
    	    nlink=0;
    }
    if (nlink!=0)
    {
        snprintf(ircbuf,sizeof(ircbuf),"RELAY %s :%d\r\n",datalink(nlink)->name,listenport);
        writesock(user(nuser)->outsock,ircbuf);
        snprintf(ircbuf,sizeof(ircbuf),"VHOST :%s\r\n",user(nuser)->vhost);
        writesock(user(nuser)->outsock,ircbuf);
        snprintf(ircbuf,sizeof(ircbuf),"CONNECT %s :%d\r\n",user(nuser)->server,user(nuser)->port);
        writesock(user(nuser)->outsock,ircbuf);
    }
    if(*user(nuser)->spass!=0)
    {
	snprintf(ircbuf,sizeof(ircbuf),"PASS %s\r\n",user(nuser)->spass);
	writesock(user(nuser)->outsock,ircbuf);
    }
    snprintf(ircbuf,sizeof(ircbuf),"USER %s %s 127.0.0.1 :%s\r\n",user(nuser)->login,user(nuser)->login,user(nuser)->user);
    writesock(user(nuser)->outsock,ircbuf);
    if(user(nuser)->instate!=STD_CONN && *user(nuser)->awaynick!=0)
        snprintf(ircbuf,sizeof(ircbuf),"NICK %s\r\n",user(nuser)->awaynick);
    else
        snprintf(ircbuf,sizeof(ircbuf),"NICK %s\r\n",user(nuser)->wantnick);
    writesock(user(nuser)->outsock,ircbuf);
    if (nlink!=0)
    {
        snprintf(ircbuf,sizeof(ircbuf),"PASS %s\r\n",datalink(nlink)->pass);
        writesock(user(nuser)->outsock,ircbuf);
    }
    if(user(nuser)->instate==STD_WHOIS) user(nuser)->instate=STD_CONN;
    snprintf(buf,sizeof(buf),"User %s (%s) connected to %s:%d (%s)",user(nuser)->login,user(nuser)->network,user(nuser)->server,user(nuser)->port,user(nuser)->vhost);
    user(nuser)->autopongreply=500;
    log(buf);
    if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);    
    return 0x0;
}

int usererror(int nuser,int errn)
{
    struct socketnodes *th;
    char buf[400];
    pcontext;
    if(user(nuser)->instate==STD_WHOIS) user(nuser)->instate=STD_CONN;
    snprintf(buf,sizeof(buf),"User %s: cant connect to %s port %d.",user(nuser)->login,user(nuser)->server,user(nuser)->port);
    log(buf);
    th=getpsocketbysock(user(nuser)->outsock);
    if(th!=NULL)
	th->sock->destructor=NULL;
    killsocket(user(nuser)->outsock);
    user(nuser)->outstate=STD_NOCON;
    if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);
    snprintf(buf,sizeof(buf),"USER%d.MOTD",nuser);
    oldfile(buf);
    memset(user(nuser)->server,0x0,sizeof(user(nuser)->server));
    return -1;
}

int userclosed(int nuser)
{
    struct socketnodes *th;
    char buf[400];
    pcontext;
    snprintf(buf,sizeof(buf),"User %s got disconnected from %s port %d.",user(nuser)->login,user(nuser)->server,user(nuser)->port);
    log(buf);
    if(user(nuser)->instate==STD_WHOIS) user(nuser)->instate=STD_CONN;
    th=getpsocketbysock(user(nuser)->outsock);
    if(th!=NULL)
    {
	th->sock->destructor=NULL;
    }
    killsocket(user(nuser)->outsock);
    user(nuser)->outstate=STD_NOCON;
    if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);
    snprintf(buf,sizeof(buf),"USER%d.MOTD",nuser);
    oldfile(buf);
    memset(user(nuser)->server,0x0,sizeof(user(nuser)->server));
    return -1;
}
/* check the clients for server connections */

int checkclients()
{
    struct usernodes *th;
    int usern;
    pcontext;
    th=usernode;
    while (th!=NULL) {
	usern=th->uid;
        if (connectuser(usern)==1) return 0x0;
	th=th->next;
    }
}


/* connect User #nuser */

int connectuser(int nuser)
{
   char buf[400];
   struct socketnodes *lkm;
   int nlink=0;    
   pcontext;
   if (user(nuser)->outstate == STD_NOCON)
   {
	if (user(nuser)->quitted ==1) return 0x0;
	if (user(nuser)->delayed) {
	    user(nuser)->delayed-=delayinc;
	    return 0x0;
	}
	if (getnextserver(nuser) != 0) {
	    user(nuser)->outstate = STD_NOCON;
	    snprintf(buf,sizeof(buf),"User %s (%s) has no server added",user(nuser)->login,user(nuser)->network);
	    log(buf);
	    if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);
	    memset(user(nuser)->server,0x0,sizeof(user(nuser)->server));
	    user(nuser)->delayed = 180;
	    return 0x0;
	}
	if (user(nuser)->port == 0) {
	    user(nuser)->outstate = STD_NOCON;
	    snprintf(buf,sizeof(buf),"User %s (%s) has no server added",user(nuser)->login,user(nuser)->network);
	    log(buf);
	    if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);    
	    memset(user(nuser)->server,0x0,sizeof(user(nuser)->server));
	    user(nuser)->delayed = 180;
	    return 0x0;
	}
	user(nuser)->delayed = 5;
	nlink=user(nuser)->vlink;
	if (nlink!=0)
	{
	    if (datalink(nlink)->type !=1 && datalink(nlink)->type!=2)
	    {
		nlink=0;
	    }
	    if (datalink(nlink)->outstate!=STD_CONN && datalink(nlink)->instate!=STD_CONN)
		nlink=0;
	}
	user(nuser)->triggered=0;
	user(nuser)->outsock=createsocket(0,ST_CONNECT,nuser,NULL,userconnected,usererror,useroutbound,userclosed);
	lkm=getpsocketbysock(user(nuser)->outsock);
	if (user(nuser)->pport!=0)
	{
	   snprintf(buf,sizeof(buf),"User %s (%s) trying proxy %s port %d to server %s port %d",user(nuser)->login,user(nuser)->network,user(nuser)->proxy,user(nuser)->pport,user(nuser)->server,user(nuser)->port);
	   log(buf);
	   if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);    
	   user(nuser)->outsock=connectto(user(nuser)->outsock,user(nuser)->proxy,user(nuser)->pport,NULL);
	} else
	if (nlink!=0)
	{
  	   snprintf(buf,sizeof(buf),"User %s (%s) trying %s port %d on link %s (%s:%d) (%s).",user(nuser)->login,user(nuser)->network,user(nuser)->server,user(nuser)->port,datalink(nlink)->name,datalink(nlink)->host,datalink(nlink)->port,user(nuser)->vhost);
	   log(buf);
	   if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);    
	   user(nuser)->outsock=connectto(user(nuser)->outsock,datalink(nlink)->host,datalink(nlink)->port,NULL);
	} else {
#ifdef CRYPT
	   if(lkm!=NULL)
	       lkm->sock->encryption=SE_REFUSE;
#endif
  	   snprintf(buf,sizeof(buf),"User %s (%s) trying %s port %d (%s).",user(nuser)->login,user(nuser)->network,user(nuser)->server,user(nuser)->port,user(nuser)->vhost);
	   log(buf);
	   if (user(nuser)->rights!=RI_ADMIN) systemnotice(nuser,buf);    
	   user(nuser)->outsock=connectto(user(nuser)->outsock,user(nuser)->server,user(nuser)->port,user(nuser)->vhost);
	}
	if (user(nuser)->outsock == 0) goto conrr;
        user(nuser)->outstate=STD_CONN;
        user(nuser)->welcome=0;
	return 0x1;
    }
    return 0x0;
conrr:
    snprintf(buf,sizeof(buf),"User %s: cant connect to %s port %d.",user(nuser)->login,user(nuser)->server,user(nuser)->port);
    log(buf);
    return 0x0;
}

