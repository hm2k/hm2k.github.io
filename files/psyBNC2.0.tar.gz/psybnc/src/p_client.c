/************************************************************************
 *   psybnc2.1.1, src/p_client.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_client.c, v 2.1.1 2000/01/17 19:30:00 psychoid Exp $";
#endif

#define P_CLIENT

#include <p_global.h>

/* the partychannel commands */

#ifdef PARTYCHANNEL

int ipartychan()
{	
    char *pt,*pt2;
    char sbuf[200];
    char ebuf[4096];
    snprintf(sbuf,sizeof(sbuf),"%s",PARTYCHAN);
    ucase(sbuf);
    pt=strstr(irccontent,PARTYCHAN);
    if(pt==NULL) pt=strstr(irccontent,sbuf);
    if(pt==NULL) return 0;
    pt2=pt+strlen(sbuf);
    *pt=0;
    if(*pt2==',')
    {
	pt2++;
	snprintf(ebuf,sizeof(ebuf),"%s%s",irccontent,pt2);
	snprintf(irccontent,sizeof(irccontent),"%s",ebuf);
	return 2;
    }
    if(pt!=irccontent) return 2;
    return 1;
}

int cmdjoin(int usern)
{
    int rc;
    char siccont[1024];
    rc=ipartychan();
    snprintf(siccont,sizeof(siccont),"%s",irccontent);
    if(rc>0)
    {
	if(user(usern)->sysmsg==0)
	{
	    user(usern)->sysmsg=1;
	    joinparty(usern);
	}
	snprintf(ircbuf,sizeof(ircbuf),"JOIN :%s\r\n",siccont);
	if(rc==1) return 0;
    }
    return 1;
}


/* the partychannel commands */

int cmdtopic(int usern)
{
    struct usernodes *th;
    int rc;
    if(strlen(ircto)==strlen(PARTYCHAN))
    {
	if(strstr(ircto,PARTYCHAN)==ircto)
	{
	    th=usernode;
	    while(th!=NULL)
	    {
		rc=th->uid;
		if(user(rc)->instate>STD_NOCON && user(rc)->sysmsg==1)
		{
		    snprintf(ircbuf,sizeof(ircbuf),":$%s*%s!%s@%s TOPIC " PARTYCHAN " :%s\r\n",
			    user(usern)->login,me,user(usern)->login,me,irccontent);
		    writesock(user(rc)->insock,ircbuf);
		}
		th=th->next;
	    }
	    snprintf(ircbuf,sizeof(ircbuf),":%s!*@%s TOPIC " PARTYCHAN " :%s\r\n",
		    user(usern)->login,me,irccontent);
	    snprintf(partytopic,sizeof(partytopic),"%s",irccontent);
	    broadcast(0);
	    return 0;
	}
    }
    return 1;
}

int cmdpart(int usern)
{
    char buf[200];
    char siccont[1024];
    int rc;
    rc=ipartychan();
    snprintf(siccont,sizeof(siccont),"%s",irccontent);
    if(rc>0)    
    {
	if(user(usern)->sysmsg==1)
	{
	    user(usern)->sysmsg=0;
	    snprintf(ircbuf,sizeof(ircbuf),":%s!%s@%s PART " PARTYCHAN " :%s\r\n",user(usern)->nick,user(usern)->login,user(usern)->host,user(usern)->nick);
	    writesock(user(usern)->insock,ircbuf);
	    snprintf(buf,sizeof(buf),"User %s logged off.",user(usern)->login);
	    sysparty(buf);
	}
	snprintf(ircbuf,sizeof(ircbuf),"PART :%s\r\n",siccont);
	if(rc==1) return 0;
    }
    return 1;
}

#endif

/* printing server banner */

int repeatserverinit(int usern)
{
    FILE *userb;
    struct linknodes *dcc;
    char fname[40];
    char buf[4096];
    char *zer;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(fname,sizeof(fname),"USER%d.MOTD",usern);
    if ((userb=fopen(fname,"r")) == NULL) {
	return -1;
    }
    while (fgets(buf,sizeof(buf),userb))
    {
	snprintf(ircbuf,sizeof(ircbuf),"%s",buf);
	/* replacing the initial IP for DCC sessions */
	zer=strstr(ircbuf," 001 ");
	if (zer!=NULL)
	{
	    zer=strchr(zer,'@');
	    if (zer!=NULL)
	    {
		zer++;
		*zer=0;
		if(strlen(ircbuf)+strlen(user(usern)->host)<sizeof(ircbuf))
		    strcat(ircbuf,user(usern)->host);
	    }
	}
	/* done */
	parentnick(usern);
	writesock(user(usern)->insock,ircbuf);
    }
    fclose(userb);
    if (checkforlog(usern)) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You have Messages. Type /QUOTE PLAYPRIVATELOG to read your messages.",user(userp)->firstnick);
       writesock(user(usern)->insock,buf);
    }
    if (strlen(user(usern)->away)>0) {
	snprintf(buf,sizeof(buf),"AWAY\r\n");
	writesock(user(usern)->outsock,buf);
	snprintf(buf,sizeof(buf),".AWAY\r\n");
	dcc=user(usern)->dcc;
	while(dcc!=NULL)
	{
	    if (dcc->link!=NULL)
	    {
		if (dcc->link->outstate==STD_CONN)
		    writesock(dcc->link->outsock,buf);
	    }
	    dcc=dcc->next;
	}
    }
    user(usern)->gotop=0;
}
/* who is on the bounce ? */

int cmdbwho(usern)
{
    struct usernodes *th;
    int userl;
    char buf[400];
    char i;
    int userp;
    int last;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    th=usernode;
    while (th!=NULL)
    {
	 userl=th->uid;
	 last=0;
         if (strlen(user(userl)->login)) {
	    if (user(userl)->parent != 0) i='^'; else i='*';
	    if (*user(userl)->host==0) { i=' ';last=1; }
	    if (user(userl)->parent != 0) last=0;
	    if (user(usern)->rights == RI_USER) {
	       if(last==1)
  	           snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :%c %s(%s) [%s:%s] :%s [last:%-20s]\r\n",user(userp)->nick,i,user(userl)->login,user(userl)->nick,user(userl)->network,user(userl)->server,user(userl)->user,user(userl)->last);
	       else
  	           snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :%c %s(%s) [%s:%s] :%s\r\n",user(userp)->nick,i,user(userl)->login,user(userl)->nick,user(userl)->network,user(userl)->server,user(userl)->user);
	    } else {
	       if(last==1)
  	           snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :%c %s(%s)@%s [%s:%s] :%s [last:%-20s]\r\n",user(userp)->nick,i,user(userl)->login,user(userl)->nick,user(userl)->host,user(userl)->network,user(userl)->server,user(userl)->user,user(userl)->last);
	       else
  	           snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :%c %s(%s)@%s [%s:%s] :%s\r\n",user(userp)->nick,i,user(userl)->login,user(userl)->nick,user(userl)->host,user(userl)->network,user(userl)->server,user(userl)->user);
	    }   
	    writesock(user(usern)->insock,buf);
	 }
	 th=th->next;
    }
    snprintf(ircbuf,sizeof(ircbuf),":%s!*@%s BWHO :\r\n",user(usern)->login,me);
    broadcast(0);
}

/* socket stats */

int cmdsockstat(int usern)
{
    char buf[40];
    snprintf(buf,sizeof(buf),"Logging current socketstats:");
    log(buf);
    usr1_error(31337);
    snprintf(buf,sizeof(buf),"End of stats.");
    log(buf);
}

/* printing out the welcome text */

int firstwelcome(void)
{
    char buf[400];
    pcontext;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Welcome %s !\r\n",user(0)->nick,user(0)->nick);
    writesock(user(0)->insock,buf);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You are the first to connect to this new proxy server.\r\n",user(0)->nick);
    writesock(user(0)->insock,buf);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You are the proxy-admin. Use ADDSERVER to add a server so the bouncer may connect.\r\n",user(0)->nick);
    writesock(user(0)->insock,buf);
    *buf=*ircto;
    *ircto=0;
    printhelp(0);
    *ircto=*buf;
}

/* first user connects */

int firstuser(npeer) {
    int linkto;
    pcontext;
    user(0)->rights = RI_ADMIN;
    snprintf(irccontent,sizeof(irccontent),"%s",newpeer(npeer)->user);
    snprintf(ircto,sizeof(ircto),"%s",newpeer(npeer)->login);
    snprintf(user(0)->nick,sizeof(user(0)->nick),"%s",newpeer(npeer)->nick);
    snprintf(user(0)->login,sizeof(user(0)->login),"%s",newpeer(npeer)->login);
    snprintf(user(0)->pass,sizeof(user(0)->pass),"%s",newpeer(npeer)->pass);
    user(0)->insock = newpeer(npeer)->insock;
    user(0)->instate = STD_CONN;    
    firstwelcome();
    linkto=cmdadduser(0);
    if(linkto==-1)
    {
	return -1;
    }
    user(linkto)->rights=RI_ADMIN;
    writeuser(linkto);
    return linkto;
}

/* adding a user by an admin */

int cmdadduser(int usern)
{
    char buf[400];
    int uind;
    int userp;
    char *pt;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(ircto) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Ident given. Syntax is ADDUSER ident :username\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Username given. Syntax is ADDUSER ident :username\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (checkuser(ircto) >0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s already existing.\r\n",user(userp)->nick,ircto);
       writesock(user(usern)->insock,buf);
       return -1;
    }    
    uind = 1;
    U_CREATE=1;
    while (uind<MAX_USER)
    {
	if (*user(uind)->login == 0) {
	    pt=strchr(ircto,' ');
	    if(pt!=NULL)
	    {
		*pt++=0;
		snprintf(user(uind)->crkey,sizeof(user(uind)->crkey),"%s",pt);
	    } else {
		*user(uind)->crkey=0;
	    }
	    snprintf(user(uind)->wantnick,sizeof(user(uind)->wantnick),"%s",ircto);
	    snprintf(user(uind)->nick,sizeof(user(uind)->nick),"%s",ircto);
	    snprintf(user(uind)->login,sizeof(user(uind)->login),"%s",ircto);
	    snprintf(user(uind)->user,sizeof(user(uind)->user),"%s",irccontent);
	    if (usern==0) {
  	       snprintf(user(uind)->pass,sizeof(user(uind)->pass),user(0)->pass);
	    } else {
  	       snprintf(user(uind)->pass,sizeof(user(uind)->pass),randstring(8));
	    }
	    user(uind)->outstate = STD_NOCON;
	    user(uind)->instate = STD_NOCON;
	    user(uind)->rights = 0;
	    user(uind)->sysmsg = 1;
	    snprintf(buf,sizeof(buf),"New User:%s (%s) added by %s",user(uind)->login,user(uind)->user,user(usern)->login);
	    log(buf);
            snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s added. Generated Password is %s.\r\n",user(userp)->nick,user(uind)->login,user(uind)->pass);
            writesock(user(usern)->insock,buf);
	    writeuser(uind);
	    clearuser(uind);
	    loaduser(uind);
	    return uind;    	
	}
	uind++;
    }
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Maximum Users exceeded.\r\n",user(userp)->nick);
    log(buf);
    return -1;
}

/* delete a user */

int cmddeluser(int usern)
{
    char buf[400];
    int uind;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Nick given. Syntax is DELUSER nick\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if ((uind = checkuser(irccontent)) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s not found.\r\n",user(userp)->nick,irccontent);
       writesock(user(usern)->insock,buf);
       return -1;
    }    
    if (uind==1)
    {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s is the Owner. He cant be deleted.\r\n",user(userp)->nick,irccontent);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    deluser(uind);
    snprintf(buf,sizeof(buf),"User %s deleted by %s. Saving USER%d.INI to USER%d.INI.old",user(uind)->nick,user(userp)->login,uind,uind);
    log(buf);
    loaduser(uind);
}

/* adding a network-user by an user */

int cmdaddnetwork(int usern)
{
    char buf[400];
    int uind;
    pcontext;
    if (user(usern)->parent!=0)
    {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You cant add a network to a network\r\n",user(user(usern)->parent)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Network given. Syntax is ADDNETWORK network\r\n",user(usern)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strlen(irccontent) > 10) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Network may be at max. 10 characters.\r\n",user(usern)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (checkusernetwork(usern) >0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Network %s already existing.\r\n",user(usern)->nick,irccontent);
       writesock(user(usern)->insock,buf);
       return -1;
    }    
    uind = 1;
    U_CREATE=1;
    while (uind<MAX_USER)
    {
	if (strlen(user(uind)->login) == 0) {
	    snprintf(user(uind)->wantnick,sizeof(user(uind)->wantnick),"%s",user(usern)->nick);
	    snprintf(user(uind)->nick,sizeof(user(uind)->nick),"%s",user(usern)->nick);
	    snprintf(user(uind)->login,sizeof(user(uind)->login),"%s",user(usern)->login);
	    snprintf(user(uind)->user,sizeof(user(uind)->user),"%s",user(usern)->user);
  	    snprintf(user(uind)->pass,sizeof(user(uind)->pass),user(usern)->pass);
	    user(uind)->outstate = STD_NOCON;
	    user(uind)->instate = user(usern)->instate;
	    user(uind)->insock = user(usern)->insock;
	    user(uind)->rights = user(usern)->rights;
	    user(uind)->parent = usern;
	    snprintf(user(uind)->network,sizeof(user(uind)->network),"%s",irccontent);
	    writeuser(uind);
	    clearuser(uind);
	    loaduser(uind);
	    snprintf(buf,sizeof(buf),"New Network %s added by %s",user(uind)->network,user(usern)->login);
	    log(buf);
            snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Network %s added.\r\n",user(usern)->nick,user(uind)->network);
            writesock(user(usern)->insock,buf);
	    return uind;    	
	}
	uind++;
    }
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Maximum Users exceeded.\r\n",user(usern)->nick);
    writesock(user(usern)->insock,buf);
    return -1;
}

/* delete a network */

int cmddelnetwork(int usern)
{
    char buf[400];
    int uind;
    pcontext;
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Network given. Syntax is DELNETWORK network\r\n",user(usern)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if ((uind = checkusernetwork(usern)) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Network %s not found.\r\n",user(usern)->nick,irccontent);
       writesock(user(usern)->insock,buf);
       return -1;
    }    
    deluser(uind);
    snprintf(buf,sizeof(buf),"Network %s deleted by %s. Saving USER%d.INI to USER%d.INI.old",user(uind)->network,user(uind)->login,uind,uind);
    log(buf);
    loaduser(uind);
}

/* change password */

int cmdpassword(int usern)
{
    char iset[8];
    char fname[20];
    char buf[400];
    int uind;
    pcontext;
    uind=usern;    
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Password given. Syntax is PASSWORD [user] :newpass\r\n",user(usern)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strlen(ircto)) {
       uind = checkuser(ircto);
       if (uind==0) {
           snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s not found\r\n",user(usern)->nick,ircto);
           writesock(user(usern)->insock,buf);
           return -1;
       }
    } else {
       snprintf(ircto,sizeof(ircto),"%s",user(usern)->login);
    }
    if(uind!=usern && user(usern)->rights!=RI_ADMIN)
    {
           snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You cant change other peoples passwords.\r\n",user(usern)->nick);
           writesock(user(usern)->insock,buf);
           return -1;
    }
    snprintf(user(uind)->pass,sizeof(user(uind)->pass),"%s",irccontent);
    snprintf(fname,sizeof(fname),"USER%d.INI",uind);
    snprintf(buf,sizeof(buf),"%s%s",slt1,slt2);
    snprintf(user(uind)->pass,sizeof(user(uind)->pass),"=%s",BLOW_stringencrypt(buf,irccontent));
    writeini("USER","PASS",fname,cryptit(user(uind)->pass));
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Password for %s changed to '%s'\r\n",user(usern)->nick,ircto,irccontent);
    writesock(user(usern)->insock,buf);
}

int cmdnick(int usern)
{
    pcontext;
    snprintf(user(usern)->wantnick,sizeof(user(usern)->wantnick),"%s",irccontent);
}

/* jumping servers */

int cmdjump(int usern)
{
    char buf[100];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (user(usern)->outstate == STD_CONN) {
	if(*irccontent!=0)
	{
	    if(atoi(irccontent)>0 && atoi(irccontent)<21)
	    {
		user(usern)->currentserver=atoi(irccontent)-1;
	    }
	}
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Hop requested, changing servers.\r\n",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	snprintf(buf,sizeof(buf),"Hop requested by %s. Quitting.",user(usern)->login);
	log(buf);
	user(usern)->instate = STD_WHOIS;
	user(usern)->afterquit=1;
	snprintf(buf,sizeof(buf),"WHOIS %s\r\n",user(usern)->nick);
	writesock(user(usern)->outsock,buf);
	snprintf(buf,sizeof(buf),"QUIT :changing servers\r\n");
	writesock(user(usern)->outsock,buf);
    } else {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You are not connected.\r\n",user(userp)->nick);
	writesock(user(usern)->insock,buf);
    }
}

/* setting vhost */

int cmdvhost(int usern)
{
    char fname[20];
    char buf[400];
    int vl;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    vl=atoi(ircto);
    if (vl!=0)
    {
	if (datalink(vl)->type!=1 && datalink(vl)->type!=2)
	{
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Link '%d' not found.\r\n",user(usern)->nick,vl);
	    writesock(user(usern)->insock,buf);
	    return 0x0;
	}
    }
    user(usern)->vlink=vl;
    snprintf(user(usern)->vhost,sizeof(user(usern)->vhost),"%s",irccontent);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","VHOST",fname,user(usern)->vhost);
    snprintf(buf,sizeof(buf),"%d",vl);
    writeini("USER","VLINK",fname,buf);
    if (vl!=0)
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :VHOST changed to '%s' on Link %d. Use JUMP to activate changed hostname.\r\n",user(userp)->nick,user(usern)->vhost,vl);
    else
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :VHOST changed to '%s'. Use JUMP to activate changed hostname.\r\n",user(userp)->nick,user(usern)->vhost);
    writesock(user(usern)->insock,buf);
}

#ifdef PROXYS

/* setting proxy */

int cmdproxy(int usern)
{
    char fname[20];
    char buf[400];
    int vl;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(user(usern)->proxy,sizeof(user(usern)->proxy),"%s",ircto);
    user(usern)->pport=atoi(irccontent);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","PROXY",fname,user(usern)->proxy);
    snprintf(buf,sizeof(buf),"%d",user(usern)->pport);
    writeini("USER","PPORT",fname,buf);
    if(user(usern)->pport==0)
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :PROXY removed. Use JUMP to activate changed proxyusage.\r\n",user(userp)->nick);
    else
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :PROXY set to '%s:%d'. Use JUMP to activate changed proxyusage. Use PROXY : to reset to non-proxy usage.\r\n",user(userp)->nick,user(usern)->proxy,user(usern)->pport);
    writesock(user(usern)->insock,buf);
}

#endif

/* setting acollide */

int cmdacollide(int usern)
{
    char fname[20];
    char buf[400];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (atoi(irccontent) != 0 && atoi(irccontent) != 1) {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Use ACOLLIDE 0 or ACOLLIDE 1.\r\n",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    user(usern)->acollide=atoi(irccontent);
    snprintf(buf,sizeof(buf),"%d",user(usern)->acollide);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","ACOLLIDE",fname,buf);
    if (user(usern)->acollide==1) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :ACOLLIDE enabled.\r\n",user(userp)->nick);
    } else {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :ACOLLIDE disabled.\r\n",user(userp)->nick);
    }
    writesock(user(usern)->insock,buf);
}

/* setting away parameter */

int cmdsetaway(int usern)
{
    char fname[20];
    char buf[400];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(user(usern)->away,sizeof(user(usern)->away),"%s",irccontent);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","AWAY",fname,user(usern)->away);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :AWAY changed to '%s'.\r\n",user(userp)->nick,user(usern)->away);
    writesock(user(usern)->insock,buf);
}

/* setting leavemsg parameter */

int cmdsetleavemsg(int usern)
{
    char fname[20];
    char buf[400];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(user(usern)->leavemsg,sizeof(user(usern)->leavemsg),"%s",irccontent);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","LEAVEMSG",fname,user(usern)->leavemsg);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :LEAVE Messages changed to '%s'. Message will be posted to channels when leaving.\r\n",user(userp)->nick,user(usern)->leavemsg);
    writesock(user(usern)->insock,buf);
}

/* setting away nick */

int cmdsetawaynick(int usern)
{
    char fname[20];
    char buf[400];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(user(usern)->awaynick,sizeof(user(usern)->awaynick),"%s",irccontent);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","AWAYNICK",fname,user(usern)->awaynick);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :AWAY-Nick changed to '%s'.\r\n",user(userp)->nick,user(usern)->awaynick);
    writesock(user(usern)->insock,buf);
}


/* setting username */

int cmdsetusername(int usern)
{
    char fname[20];
    char buf[400];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(user(usern)->user,sizeof(user(usern)->user),"%s",irccontent);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","USER",fname,user(usern)->user);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Username changed to '%s'. You need to use BJUMP to activate it.\r\n",user(userp)->nick,user(usern)->user);
    writesock(user(usern)->insock,buf);
}

int cmdaddserver(int usern)
{
    char fname[20];
    char buf[400];
    char gsrv[400];
    char *pw;
    char dpw[]="None";
    int prt;
    int nmsrv;
    int rc;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(ircto) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No server given. Syntax is ADDSERVER hostname :port\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    nmsrv=1;
    while (nmsrv < 10)
    {
          rc=getserver(nmsrv,usern);
	  if (rc<0) {
              pw=strchr(irccontent,' ');
	      if(pw!=NULL)
	      {
	          *pw=0;
		  pw++;
		  snprintf(buf,sizeof(buf),"SPASS%d",nmsrv);
		  writeini("SERVERS",buf,fname,pw);
	      } else {
	          pw=dpw;
	      }
	      if (strlen(irccontent)==0) {
	         snprintf(irccontent,sizeof(irccontent),"6667");
	      }
	      snprintf(buf,sizeof(buf),"PORT%d",nmsrv);
	      writeini("SERVERS",buf,fname,irccontent);
	      snprintf(buf,sizeof(buf),"SERVER%d",nmsrv);
	      writeini("SERVERS",buf,fname,ircto);
              snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Server %s port %s (password: %s) added.\r\n",user(userp)->nick,ircto,irccontent,pw);
              writesock(user(usern)->insock,buf);
	      user(usern)->delayed=0;	
	      return 0x0;
	  }
	  nmsrv++;
    }
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No server entry free.\r\n",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    return -1;
}

int cmddelserver(int usern)
{
    char fname[20];
    char buf[400];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No server given. Syntax is DELSERVER number\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    snprintf(buf,sizeof(buf),"SPASS%s",irccontent);
    writeini("SERVERS",buf,fname,NULL);
    snprintf(buf,sizeof(buf),"PORT%s",irccontent);
    writeini("SERVERS",buf,fname,NULL);
    snprintf(buf,sizeof(buf),"SERVER%s",irccontent);
    writeini("SERVERS",buf,fname,NULL);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Server %s deleted.\r\n",user(userp)->nick,irccontent);
    writesock(user(usern)->insock,buf);
    return -1;
}

int cmdlistservers(int usern)
{
    char fname[20];
    char buf[400];
    char gsrv[400];
    char sicsrv[400];
    int sicport;
    int prt;
    int nmsrv;
    int rc;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    sicport=user(usern)->port;
    snprintf(sicsrv,sizeof(sicsrv),"%s",user(usern)->server);
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    nmsrv=1;
    while (nmsrv < 10)
    {
          rc=getserver(nmsrv,usern);
	  if (rc==0) {
              snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Server #%d: %s port %d\r\n",user(userp)->nick,nmsrv,user(usern)->server,user(usern)->port);
              writesock(user(usern)->insock,buf);
	  }
	  nmsrv++;
    }
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of Servers.\r\n",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    snprintf(user(usern)->server,sizeof(user(usern)->server),"%s",sicsrv);
    user(usern)->port = sicport;
    return -1;
}

int cmdlinkfrom(int usern)
{
    cmdaddlink(usern,LI_ALLOW);
}

int cmdlinkto(int usern)
{
    cmdaddlink(usern,LI_LINK);
}

int cmdaddlink(int usern,int type)
{
    char iset[8];
    char fname[20];
    char buf[400];
    int newlink;
    char *pt;
    char fr[]="from";
    char tr[]="to";
    char *tp;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (*me==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You did not define the Name of this bouncer. Do NAMEBOUNCER name first.\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Host given. Use %s name :host:port.\r\n",user(userp)->nick,irccommand);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strlen(ircto) == 0 && type!=LI_LINK) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No name given. Use %s name :host:port.\r\n",user(userp)->nick,irccommand);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strchr(irccontent,':')==NULL) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Port given. Use %s name :host:port.\r\n",user(userp)->nick,irccommand);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    pt=strchr(irccontent,':');
    *pt=0;pt++;
    if (atoi(pt)==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Invalid Port. Use %s name :host:port.\r\n",user(userp)->nick,irccommand);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (type==LI_LINK)
    {
	snprintf(ircto,sizeof(ircto),"%s",me);
	snprintf(datalink(newlink)->pass,sizeof(datalink(newlink)->pass),"%s",randstring(15));
	tp=tr;
    } else
	tp=fr;
    newlink=getlinkbyname(ircto);
    if (newlink!=0 && type!=LI_LINK) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Link %s already existent.\r\n",user(userp)->nick,ircto);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    newlink=getnewlink();
    if (newlink==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No more free Link-Connections.\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    clearlink(newlink);
    snprintf(datalink(newlink)->host,sizeof(datalink(newlink)->host),"%s",irccontent);
    datalink(newlink)->port=atoi(pt);
    datalink(newlink)->allowrelay=0;
    snprintf(datalink(newlink)->name,sizeof(datalink(newlink)->name),"%s",ircto);
    datalink(newlink)->type=type;
    if (type==LI_ALLOW)
         snprintf(datalink(newlink)->iam,sizeof(datalink(newlink)->iam),"%s",ircto);
    writelink(newlink);
    snprintf(buf,sizeof(buf),"New Link '%s' %s %s:%d added by %s.",datalink(newlink)->name,tp,datalink(newlink)->host,datalink(newlink)->port,user(usern)->login);
    log(buf);
}

/* set / unset the relay flag */
int cmdrelaylink(int usern)
{
    char iset[8];
    char fname[20];
    char buf[400];
    char yo[]="enable";
    char nes[]="disable";
    int lnk;
    char *pt;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0 || (atoi(irccontent)!=0 && atoi(irccontent)!=1)) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No valid value given. Use RELAYLINK linknumber :0|1.\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (strlen(ircto)==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No linknumber given. Use RELAYLINK linknumber :0|1.\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    lnk=atoi(ircto);
    if (datalink(lnk)->type==0) lnk=0;
    if (lnk==0)
    {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Link %s unknown.\r\n",user(userp)->nick,ircto);
       writesock(user(usern)->insock,buf);
       return -1;
    }    
    datalink(lnk)->allowrelay=atoi(irccontent);
    writelink(lnk);
    if (datalink(lnk)->allowrelay==0)
	pt=nes;
    else
	pt=yo;
    snprintf(buf,sizeof(buf),"Relay linking for link '%s' %sd by %s",ircto,pt,user(usern)->login);
    log(buf);
}

int cmddellink(int usern)
{
    char iset[8];
    char fname[20];
    char buf[400];
    int lnk=0;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Link-Number defined.\r\n",user(userp)->nick);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    if (datalink(atoi(irccontent))->type!=0)
	lnk=atoi(irccontent);
    if (lnk==0)
    {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Link %s unknown.\r\n",user(userp)->nick,irccontent);
       writesock(user(usern)->insock,buf);
       return -1;
    }
    snprintf(buf,sizeof(buf),"Link %d removed by %s",lnk,user(usern)->login);
    if (datalink(lnk)->outstate==STD_CONN)
    {
	snprintf(buf,sizeof(buf),"Link to %s removed by %s",datalink(lnk)->iam,user(usern)->login);
	sysparty(buf);
	killsocket(datalink(lnk)->outsock);
    }    
    if (datalink(lnk)->instate==STD_CONN)
    {
	snprintf(buf,sizeof(buf),"Link from %s removed by %s",datalink(lnk)->iam,user(usern)->login);
	sysparty(buf);
	killsocket(datalink(lnk)->insock);
    }    
    log(buf);
    clearlink(lnk);
    eraselinkini(lnk);
}

int cmdlistlinks(int usern)
{
    struct linknodes *th;
    int linkn=1;
    char o[]="->";
    char i[]="<-";
    char r[]="R ";
    char l;
    char buf[600];
    char *pt;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    th=linknode;
    while (th!=NULL)
    {
	linkn=th->uid;
	l=' ';
	if (datalink(linkn)->type!=0)
	{
	    if (datalink(linkn)->type==LI_LINK) 
	    {
		pt=o;
		if (datalink(linkn)->outstate==STD_CONN) l='*';
	    }
	    if (datalink(linkn)->type==LI_ALLOW) 
	    {
		if (datalink(linkn)->instate==STD_CONN) l='*';
		pt=i;
	    }
	    if (datalink(linkn)->type==LI_RELAY) { pt=r; l='*';}
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :%c%d %s %s %s(%d)\r\n",user(userp)->nick,l,linkn,pt,datalink(linkn)->iam,datalink(linkn)->host,datalink(linkn)->port); 
	    writesock(user(usern)->insock,buf);
	}
	th=th->next;
    }
    snprintf(ircbuf,sizeof(ircbuf),":%s!*@%s LISTLINKS :",user(usern)->login,me);
    broadcast(0);
}

int cmdadddcc(int usern)
{
    char *npt;
    char *upt;
    char *ppt;
    char *hpt;
    char *spt;
    int port;
    char buf[400];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    npt=strchr(ircbuf,' ');
    if (npt!=NULL)
    {
	*npt=0;
	npt++;
	upt=strchr(npt,' ');
	if (upt!=NULL)
	{
	    *upt=0;
	    upt++;
	    ppt=strchr(upt,' ');
	    if (ppt!=NULL)
	    {
		*ppt=0;
		ppt++;
		hpt=strchr(ppt,':');
		if (hpt!=NULL)
		{
		    *hpt=0;
		    hpt++;
		    spt=strchr(hpt,':');
		    if (spt!=NULL)
		    {
			*spt=0;
			spt++;
			port=atoi(spt);
			if (port!=0)
			{
			    adddcc(usern,hpt,port,upt,ppt,npt,0);
			    return 0x0;
			}
		    }
		}
	    }
	}
    }
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Wrong Parameters. Use ADDDCC botname user pass :host:port\r\n",user(userp)->nick); 
    writesock(user(usern)->insock,buf);
    return 0x0;
}

int cmddeldcc(int usern)
{
    erasedcc(usern,atoi(irccontent));
}

int cmdlistdcc(int usern)
{
    listdccs(usern);
}

/* display a help to a topic or an overview */

int printhelp(int ausern)
{
    char buf[200];
    int usern;
    pcontext;
    if (user(usern)->parent!=0) usern=user(usern)->parent; else usern=ausern;
    
    if(*irccontent==0 || ausern==0)
    {
	snprintf(buf,sizeof(buf),":irc.psychoid.net NOTICE %s :psyBNC 2.1 Help (* = BounceAdmin only)\n",user(usern)->nick);
	writesock(user(usern)->insock,buf);
	snprintf(buf,sizeof(buf),":irc.psychoid.net NOTICE %s :--------------------------------------\n",user(usern)->nick);
	writesock(user(usern)->insock,buf);
	userhelp(usern,NULL);
	snprintf(buf,sizeof(buf),":irc.psychoid.net NOTICE %s :BHELP - End of help\n",user(usern)->nick);
    } else {
	userhelp(usern,irccontent);
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de PRIVMSG %s :BHELP - End of help\n",user(usern)->nick);
    }
    writesock(user(usern)->insock,buf);
}

/* add an op */

int cmdaddop(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Host given. Use ADDOP [#chan] password :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Password given. Use ADDOP [#chan] password :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in hostnames",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.OP",usern);
    user(usern)->ops=writelist(irccontent,cryptit(ircto),cfile,user(usern)->ops);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added op for hostmask %s (%s)",user(userp)->nick,irccontent,ircto);
    writesock(user(usern)->insock,buf);
}

/* add an autoop */

int cmdaddautoop(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Host given. Use ADDAUTOOP #chan :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Channel given. Use ADDAUTOOP #chan :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in hostnames",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.AOP",usern);
    user(usern)->aops=writelist(irccontent,cryptit(ircto),cfile,user(usern)->aops);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added auto-op for hostmask %s (%s)",user(userp)->nick,irccontent,ircto);
    writesock(user(usern)->insock,buf);
}

/* add an askop */

int cmdaddask(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Host given. Use ADDASK [#chan] password :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Password given. Use ADDASK [#chan] password :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in hostnames",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.ASK",usern);
    user(usern)->askops=writelist(irccontent,cryptit(ircto),cfile,user(usern)->askops);    
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added op from hostmask %s (%s)",user(userp)->nick,irccontent,ircto);
    writesock(user(usern)->insock,buf);
}

/* add a hostallow */

int cmdaddallow(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Host given. Use ADDALLOW :hostmask",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in hostnames",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"psbnc.hosts",usern);
    hostallows=writelist(irccontent,"*",cfile,hostallows);    
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added Host allow from hostmask %s",user(userp)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

/* add a ban */

int cmdaddban(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Host given. Use ADDBAN [#chan] reason :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Reason given. Use ADDBAN [#chan] reason :host",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in hostnames",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.BAN",usern);
    user(usern)->bans=writelist(irccontent,ircto,cfile,user(usern)->bans);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added ban for host %s (%s)",user(userp)->nick,irccontent,ircto);
    writesock(user(usern)->insock,buf);
}

/* add a key */

int cmdaddkey(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Key given. Use ADDKEY #chan :key",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Channel given. Use ADDKEY #chan :key",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in keys",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.KEY",usern);
    ucase(ircto);
    user(usern)->keys=writelist(irccontent,ircto,cfile,user(usern)->keys);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added key for channel %s (%s)",user(userp)->nick,ircto,irccontent);
    writesock(user(usern)->insock,buf);
}

/* add a logmask */

int cmdaddlog(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Log Filter given (Use * for all). Use ADDLOG [#chan/logdest.] :filter(included text to get logged)",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Destination given. Use ADDLOG [#chan/logdest.] :filter",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in filters",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.LGI",usern);
    user(usern)->logs=writelist(irccontent,ircto,cfile,user(usern)->logs);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added log for destination %s (filtering %s)",user(userp)->nick,ircto,irccontent);
    writesock(user(usern)->insock,buf);
}

int cmdrelink(int usern)
{
    char buf[400];
    int vl;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    vl=atoi(irccontent);
    if (vl!=0)
    {
	if (datalink(vl)->type!=1 && datalink(vl)->type!=2)
	{
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Link '%d' not found.\r\n",user(usern)->nick,vl);
	    writesock(user(usern)->insock,buf);
	    return 0x0;
	}
    }
    if(datalink(vl)->type==LI_LINK && datalink(vl)->outstate==STD_CONN)
	killsocket(datalink(vl)->outsock);
    if(datalink(vl)->type==LI_ALLOW && datalink(vl)->instate==STD_CONN)
	killsocket(datalink(vl)->insock);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Link '%d' resetted and disconnected.\r\n",user(usern)->nick,vl);
    writesock(user(usern)->insock,buf);
}

#ifdef CRYPT


int cmdsetlinkkey(int usern)
{
    char buf[400];
    int vl=0,ln;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    vl=atoi(ircto);
    if(vl==0)
    {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Wrong Syntax. Use SETLINKKEY (linknumber) :key.\r\n",user(usern)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (vl!=0)
    {
	if (datalink(vl)->type!=1 && datalink(vl)->type!=2)
	{
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Link '%d' not found.\r\n",user(usern)->nick,vl);
	    writesock(user(usern)->insock,buf);
	    return 0x0;
	}
    }
#ifdef BLOWFISH
    ln=15;
#else
    ln=54;
#endif
    if(strlen(irccontent)>ln)
    {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Key Phrase may not be longer than %d chars.\r\n",user(usern)->nick,ln);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(datalink(vl)->crkey,sizeof(datalink(vl)->crkey),"%s",irccontent);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Initial Key Phrase for link %d set to '%s'. The counterpart also needs to set this linkkey to your link. Trigger RELINK %d after counterpart set the password.\r\n",user(usern)->nick,vl,irccontent,vl);
    writesock(user(usern)->insock,buf);
    writelink(vl);
    return 0x0;
}

int cmdsetuserkey(int usern)
{
    char buf[400];
    int vl,ln;
    int userp,rc;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    rc=usern;
    if(strlen(ircto))
    {
	if(user(usern)->rights!=RI_ADMIN)
	{
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Only Admins may change other Users encryptionkeys.\r\n",user(usern)->nick);
	    writesock(user(usern)->insock,buf);
	    return 0x0;
	}
	rc = checkuser(ircto);
	if(rc==0)
	{
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No such user.\r\n",user(usern)->nick);
	    writesock(user(usern)->insock,buf);
	    return 0x0;
	}
    }
#ifdef BLOWFISH
    ln=15;
#else
    ln=54;
#endif
    if(strlen(irccontent)>ln)
    {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Key Phrase may not be longer than %d chars.\r\n",user(usern)->nick,ln);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(user(rc)->crkey,sizeof(user(rc)->crkey),"%s",irccontent);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Initial Key Phrase for User %s set to '%s'. The new setting occurs next time you connect.\r\n",user(usern)->nick,user(rc)->login,irccontent);
    writesock(user(usern)->insock,buf);
    writeuser(rc);
    return 0x0;
}

/* add an encryption */

int cmdencrypt(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No channel or nick given. Use ENCRYPT password :#channel or nick",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Password given. Use ENCRYPT password :#channel or nick",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in chan or nick",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.ENC",usern);
    ucase(irccontent);
    user(usern)->encrypt=writelist(irccontent,cryptit(ircto),cfile,user(usern)->encrypt);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added encryption for %s (%s)",user(userp)->nick,irccontent,ircto);
    writesock(user(usern)->insock,buf);
}

#endif

#ifdef TRANSLATE

/* add a translator */

int cmdtranslate(int usern) {
    char cfile[40];
    char *pt;
    char buf[200];
    int userp;
    char *langs[8];
    int ec;
    int isa=0,isb=0;
    langs[0]="en_de";
    langs[1]="en_fr";
    langs[2]="en_it";
    langs[3]="en_pt";
    langs[4]="de_en";
    langs[5]="fr_en";
    langs[6]="it_en";
    langs[7]="pt_en";
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No languages given. Use TRANSLATE #channel or nick :language-from language-to",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strlen(ircto) == 0 || *ircto=='+') {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No Channel or User given given. Use TRANSLATE #channel or nick :language-from language-to",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    if (strchr(irccontent,':')) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You may not use : in language specifications",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(buf,sizeof(buf),"%s",irccontent);
    pt=strchr(buf,' ');
    if(pt==NULL)
    {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Not enough parameters in language. Use two language specifications.",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    *pt++=0;
    if(strlen(pt)!=5 || strlen(buf)!=5) goto wrongpar;
    ec=0;
    while(ec<8)
    {
	if(strstr(langs[ec],pt)!=NULL) isa=1;
	if(strstr(langs[ec],buf)!=NULL) isb=1;
	ec++;
    }
    if(isa!=1 || isb!=1) goto wrongpar;
    snprintf(cfile,sizeof(cfile),"USER%d.TRA",usern);
    ucase(ircto);
    user(usern)->translates=writelist(irccontent,ircto,cfile,user(usern)->translates);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Added translator for %s (%s)",user(userp)->nick,ircto,irccontent);
    writesock(user(usern)->insock,buf);
    return 0x0;
wrongpar:
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Wrong languages given. Use en_de,en_fr,en_it,en_pt,de_en,fr_en,it_en or pt_en",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    return 0x0;
}

#endif

/* remove op entry */

int cmddelop(int usern) {
    char cfile[40];
    char buf[200];
    int userp;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELOP number",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.OP",usern);
    user(usern)->ops=eraselist(atoi(irccontent),cfile,user(usern)->ops);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Op Number %s removed",user(userp)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

/* remove autoop entry */

int cmddelautoop(int usern) {
    char cfile[40];
    char buf[200];
    int userp;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELOP number",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.AOP",usern);
    user(usern)->aops=eraselist(atoi(irccontent),cfile,user(usern)->aops);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Auto-Op Number %s removed",user(userp)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

/* delete askop */

int cmddelask(int usern) {
    char cfile[40];
    char buf[200];
    pcontext;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELASK number",user(usern)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.ASK",usern);
    user(usern)->askops=eraselist(atoi(irccontent),cfile,user(usern)->askops);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :AskOp Number %s removed",user(usern)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

/* delete askop */

int cmddelallow(int usern) {
    char cfile[40];
    char buf[200];
    pcontext;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELALLOW number",user(usern)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"psbnc.hosts",usern);
    hostallows=eraselist(atoi(irccontent),cfile,hostallows);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Host Allow Number %s removed",user(usern)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

/* delete a ban */

int cmddelban(int usern) {
    char cfile[40];
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELBAN number",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.BAN",usern);
    user(usern)->bans=eraselist(atoi(irccontent),cfile,user(usern)->bans);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Ban Number %s removed",user(userp)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

/* delete a ban */

int cmddelkey(int usern) {
    char cfile[40];
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELKEY number",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.KEY",usern);
    user(usern)->keys=eraselist(atoi(irccontent),cfile,user(usern)->keys);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Key Number %s removed",user(userp)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

/* delete a log entry */

int cmddellog(int usern) {
    char cfile[40];
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELLOG number",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.LGI",usern);
    user(usern)->logs=eraselist(atoi(irccontent),cfile,user(usern)->logs);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Log Entry Number %s removed",user(userp)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

#ifdef CRYPT

/* delete encryption */

int cmddelencrypt(int usern) {
    char cfile[40];
    char buf[200];
    pcontext;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELENCRYPT number",user(usern)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.ENC",usern);
    user(usern)->encrypt=eraselist(atoi(irccontent),cfile,user(usern)->encrypt);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Encryption Number %s removed",user(usern)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

#endif

#ifdef TRANSLATE

/* delete encryption */

int cmddeltranslate(int usern) {
    char cfile[40];
    char buf[200];
    pcontext;
    if (strlen(irccontent) == 0) {
        snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No number given. Use DELTRANSLATE number",user(usern)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    snprintf(cfile,sizeof(cfile),"USER%d.TRA",usern);
    user(usern)->translates=eraselist(atoi(irccontent),cfile,user(usern)->translates);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Translator Number %s removed",user(usern)->nick,irccontent);
    writesock(user(usern)->insock,buf);
}

#endif

/* list the ops */

int cmdlistops(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing OPs:",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    liststrings(user(usern)->ops,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

/* list the autoops */

int cmdlistautoops(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing Auto-OPs:",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    liststrings(user(usern)->aops,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

/* list the ops */

int cmdlistkey(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing KEYs:",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    liststrings(user(usern)->keys,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

/* list the askops */

int cmdlistask(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing AskOPs:",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    liststrings(user(usern)->askops,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

/* list the hostallows */

int cmdlistallow(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing Host Allows:",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    liststrings(hostallows,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

/* list all bans */

int cmdlistbans(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing Bans:",user(userp)->nick);
    writesock(user(usern)->insock,buf);

    liststrings(user(usern)->bans,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

#ifdef CRYPT

/* list all encryptions */

int cmdlistencrypt(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing Encryptions:",user(userp)->nick);
    writesock(user(usern)->insock,buf);

    liststrings(user(usern)->encrypt,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

#endif

#ifdef TRANSLATE

/* list all translators */

int cmdlisttranslate(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing Translators:",user(userp)->nick);
    writesock(user(usern)->insock,buf);

    liststrings(user(usern)->translates,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}


#endif

/* list all log-entrys */

int cmdlistlogs(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing Log-Entrys:",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    liststrings(user(usern)->logs,usern);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of List.",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}

/* rehash the proxy */

int cmdrehash(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :REHASHING !! All connections will be dropped:",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    snprintf(buf,sizeof(buf),"REHASHED by %s",user(usern)->login);
    log(buf);
    loadusers();
    loadlinks();
}

/* crown an admin */

int cmdadmin(int usern) {
    char buf[200];
    int rc;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent)==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No user given. Syntax is MADMIN user.",user(userp)->nick);
       writesock(user(usern)->insock,buf);
    }    
    rc=checkuser(irccontent);
    if (rc) {
       user(rc)->rights=RI_ADMIN;
       writeuser(rc);	
       snprintf(buf,sizeof(buf),"User %s declared User %s to admin",user(userp)->nick,irccontent);
       log(buf);
    
    } else {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s not found.",user(userp)->nick,irccontent);
       writesock(user(usern)->insock,buf);
    }
}

/* remove the crown */

int cmdunadmin(int usern) {
    char buf[200];
    int rc;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent)==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No user given. Syntax is UNADMIN user.",user(userp)->nick);
       writesock(user(usern)->insock,buf);
    }    
    rc=checkuser(irccontent);
    if (rc) {
       snprintf(buf,sizeof(buf),"User %s took admin rights from User %s",user(userp)->nick,irccontent);
       log(buf);
       user(rc)->rights=RI_ADMIN;
       writeuser(rc);	
    
    } else {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s not found.",user(userp)->nick,irccontent);
       writesock(user(usern)->insock,buf);
    }
}

/* kill a user on the bounce */

int cmdbkill(int usern) {
    char buf[200];
    int rc;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (strlen(irccontent)==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No user given. Syntax is BKILL user.",user(userp)->nick);
       writesock(user(usern)->insock,buf);
    }    
    rc=checkuser(irccontent);
    if (rc) {
       if (user(rc)->instate != STD_CONN) {
           snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :He isnt online. Why killing a dead?.",user(userp)->nick);
           writesock(user(usern)->insock,buf);
           return -1;
       }	
       snprintf(buf,sizeof(buf),"User %s killed User %s",user(userp)->nick,irccontent);
       log(buf);
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You have been killed by %s.",user(rc)->nick,user(usern)->login);
       writesock(user(rc)->insock,buf);
       killsocket(user(rc)->insock);
       memset(user(usern)->host,0x0,sizeof(user(usern)->host));
       user(rc)->instate=STD_NOCON;
       user(rc)->insock=0;	
    } else {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :User %s not found.",user(userp)->nick,irccontent);
       writesock(user(usern)->insock,buf);
    }
}

/* quit a connection */

int cmdbquit(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (user(usern)->quitted ==1) {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You are already quitted.\n",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    user(usern)->quitted = 1;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You have been marked as quitted.\n",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    writeuser(usern);
    if (user(usern)->outstate == STD_CONN) {
       snprintf(buf,sizeof(buf),"QUIT :\n");
       writesock(user(usern)->outsock,buf);
       user(usern)->outstate = STD_NOCON;
       user(usern)->outsock = 0;
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You have been disconnected from %s.\n",user(userp)->nick,user(usern)->server);
       writesock(user(usern)->insock,buf);
       user(usern)->instate=STD_CONN;
       killsocket(user(usern)->outsock);
       memset(user(usern)->server,0x0,sizeof(user(usern)->server));
    }
}

int cmdbconnect(int usern) {
    char buf[200];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    if (user(usern)->quitted==0) {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :You are not marked as quit.\n",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;
    }
    user(usern)->quitted = 0;
    user(usern)->delayed = 0;
    writeuser(usern);
}

int cmdname(int usern)
{
    char *pt;
    char buf[200];
    pcontext;
    if (strlen(me)==0) {
	pt=strchr(irccontent,' '); /* filtering space */
	if (pt!=NULL) *pt=0;
	snprintf(me,sizeof(me),"%s",irccontent);
	writeini("SYSTEM","ME",INIFILE,me);
	snprintf(buf,sizeof(buf),"Name of the bouncer set to '%s'.",me);
	log(buf);
	return -1;
    }
}

int cmdquit(int usern)
{
    char buf[400];
    pcontext;
    if (user(usern)->parent !=0) usern=user(usern)->parent;
    snprintf(buf,sizeof(buf),"User %s quitted (from %s)",user(usern)->login,user(usern)->host);
    log(buf);
    snprintf(buf,sizeof(buf),":%s!%s@%s QUIT :good bye\r\n",user(usern)->nick,user(usern)->login,user(usern)->host);
    writesock(user(usern)->insock,buf);
    quitclient(usern);
    return -1;
}

#ifdef CRYPT

int checkcrypt(int usern)
{
    struct stringarray *lkm;
    int match=0;
    int decr=0,valid=0;
    char buf[800],buf1[200];
    char *tomatch;
    char *prefx;
    char *pt,*pt1,*pt2,*er;
    char *b[3];
    char act[]="\x01" "ACTION";
    char nt[]="\x00";
#ifdef BLOWFISH
    char bx[]="[B]";
#endif
#ifdef IDEA
    char bx[]="[I]";
#endif
    b[0]="[B]";
    b[1]="[I]";
    b[2]="[N]";
    prefx=nt;
    lkm=user(usern)->encrypt;
    if(strstr(irccontent,b[2])==irccontent) return 0x0;
    if(*ircbuf==':')
    {
        decr=1;
        if(*ircto=='#' || *ircto=='&' || *ircto=='+')
        {
    	    tomatch=ircto;
	} else {
	    tomatch=ircnick;
	}
    } else {
	decr=0;
	tomatch=ircto;
    }
    snprintf(buf,sizeof(buf),"%s",tomatch);
    ucase(buf);
    while(lkm!=NULL)
    {
	snprintf(buf1,sizeof(buf1),"%s",lkm->entry);
	pt=buf1;
	pt2=strchr(buf1,':');
	if(pt2==NULL) return 0x0;
	*pt2++=0;
	ucase(pt);
	if(strlen(pt)==strlen(buf))
	{
	    if(strstr(pt,buf)==pt)
	    {
		pt1=decryptit(pt2);
		if(decr==1)
		{
		    pt2=NULL;
		    if(*irccontent==1) /* actions, dccs, ctcps */
		    {
			if(strstr(irccontent,act)==irccontent)
			{
			    pt+=strlen(act);
			    prefx=act;
			    valid=1;
			} else {
			    /* we got another control msg, which will be ignored */
			}	
		    } else {
		        pt=irccontent;
			valid=1;
		    }
		    if(valid)
		    {
			pt2=NULL;
			if(strstr(pt,b[0])==pt)
			    pt2=BLOW_stringdecrypt(pt+3,pt1);
			else if(strstr(pt,b[1])==pt)
			    pt2=IDEA_stringdecrypt(pt+3,pt1);
			if(pt2==NULL) return 0x0;
			pt=strstr(ircbuf,irccontent);
			if(pt==NULL) return 0x0;
			pt+=3;
			*pt=0;
			snprintf(buf,sizeof(buf),"%s",ircbuf);
			snprintf(ircbuf,sizeof(ircbuf),"%s%s%s\r\n",buf,prefx,pt2);
			free(pt2);
			parse();
		    }
		    return 0x0;
		} else {
		    if(*irccontent==1)
		    {
			if(strstr(irccontent,act)==irccontent)
			{
			    valid=1;
			} else {
			    return 0x0; /* ignoring others */
			}
		    }
		    pt=strstr(ircbuf,irccontent);
		    if(pt==NULL) return 0x0;
		    if(valid==1) pt+=strlen(act);
		    *pt=0;
		    snprintf(buf,sizeof(buf),"%s",ircbuf);
#ifdef BLOWFISH
		    pt=BLOW_stringencrypt(irccontent,pt1);		    
#endif
#ifdef IDEA
		    pt=IDEA_stringencrypt(irccontent,pt1);
#endif	    		    
		    if(pt==NULL) return 0x0;
		    snprintf(ircbuf,sizeof(ircbuf),"%s%s%s\r\n",buf,bx,pt);
		    parse();
		    return 0x0;		    
		}
	    }
	}
	lkm=lkm->next;
    }
}

#endif

#ifdef TRANSLATE

int checktranslate(int usern)
{
    struct stringarray *lkm;
    int rc=0;
    int dest=0;
    char buf[200],buf1[200];
    char *tomatch;
    char *pt,*pt1,*pt2,*er;
    lkm=user(usern)->translates;

    if(*ircbuf==':')
    {
        dest=TR_FROM;
        if(*ircto=='#' || *ircto=='&' || *ircto=='+' || *ircto=='!')
        {
    	    tomatch=ircto;
	} else {
	    tomatch=ircnick;
	}
    } else {
	dest=TR_TO;
	tomatch=ircto;
    }
    snprintf(buf,sizeof(buf),"%s",tomatch);
    ucase(buf);
    while(lkm!=NULL)
    {
	snprintf(buf1,sizeof(buf1),"%s",lkm->entry);
	pt=buf1;
	pt2=strchr(buf1,':');
	if(pt2==NULL) return 0x1;
	*pt2++=0;
	ucase(pt2);
	if(strlen(pt2)==strlen(buf))
	{
	    if(strstr(pt2,buf)==pt2)
	    {
		pt1=strchr(pt,' ');
		if(pt1==NULL) return 0x1;
		*pt1++=0;
		if(dest==TR_TO)
		{
		    pt1=pt;
		}
		rc=addtranslate(usern,irccontent,ircfrom,ircto,dest,pt1,irccommand);
		return 0x0;
	    }
	}
	lkm=lkm->next;
    }
    return 0x1;
}

#endif


int cmdprivmsg(int usern)
{
    char bc=')';
    int rc;
    pcontext;
#ifdef PARTYCHANNEL
    if (strstr(ircto,PARTYCHAN)==ircto && strlen(ircto)==strlen(PARTYCHAN))
    {
	strcpy(ircto,"$$"); /* ... old clients, compatibility */
    }
#endif
    if (*ircto == '$') {
         querybounce(usern);
	 return 0;
    }
    if (*ircto == bc) {
         querybot(usern);
	 return 0;
    }
    rc=1;
#ifdef TRANSLATE
    rc=checktranslate(usern);
#endif
#ifdef CRYPT
    checkcrypt(usern);
#endif
    return rc;
}

int cmdwho(int usern)
{
    pcontext;
    user(usern)->triggered++;
    return -1;
}

int cmduser(int usern)
{
    return -1;
}

int quitclient(int usern)
{
    struct linknodes *dcc;
    struct usernodes *th;
    struct socketnodes *thn;
    char buf[100];
    time_t tm;
#ifdef PARTYCHANNEL
    if(user(usern)->sysmsg==1)
    {
	strcpy(irccontent,PARTYCHAN);
	cmdpart(usern);
	user(usern)->sysmsg=1;
    }
#else
    snprintf(buf,sizeof(buf),"User %s logged off.",user(usern)->login);
    sysparty(buf);
#endif
    pcontext;
    time( &tm );
    snprintf(user(usern)->last,sizeof(user(usern)->last),"%s",ctime( &tm ));
    th=usernode;
    while (th!=NULL)
    {
	if (th->user!=NULL)
	{
	    if (th->uid==usern || th->user->parent==usern)
	    {
	        user(th->uid)->instate = STD_NOCON;
	        if (user(th->uid)->parent!=0) user(th->uid)->insock = 0;
	    	if (*user(th->uid)->leavemsg!=0) user(th->uid)->doaway=1;
	        if (strlen(user(th->uid)->away) >0) {
	            snprintf(buf,sizeof(buf),"AWAY :%s\r\n",user(th->uid)->away);
	            writesock(user(usern)->outsock,buf);
	            snprintf(buf,sizeof(buf),".AWAY %s\r\n",user(th->uid)->away);
	    	    dcc=user(th->uid)->dcc;
	    	    while(dcc!=NULL)
	    	    {
	    		if (dcc->link!=NULL)
	    		{
	    		    if (dcc->link->outstate==STD_CONN)
	    			writesock(dcc->link->outsock,buf);
	    		}
	    		dcc=dcc->next;
	    	    }
	        }    
		user(th->uid)->triggered=0;
		user(th->uid)->afterquit=1;
	        memset(user(th->uid)->host,0x0,sizeof(user(th->uid)->host));
	        snprintf(buf,sizeof(buf),"WHOIS %s\r\n",user(th->uid)->nick);
	        writesock(user(th->uid)->outsock,buf);
		if(*user(th->uid)->awaynick!=0)
	    	    snprintf(buf,sizeof(buf),"NICK %s\r\n",user(th->uid)->awaynick);
		else 
	    	    snprintf(buf,sizeof(buf),"NICK %s\r\n",user(th->uid)->wantnick);
	        writesock(user(th->uid)->outsock,buf);
	    }
	}
	th=th->next;
    }
    thn=getpsocketbysock(user(usern)->insock);
    if (thn!=NULL)
	thn->sock->destructor=NULL;
    killsocket(user(usern)->insock);
    user(usern)->insock=0;
}

int userinerror(int usern,int errn)
{
    char buf[400];
    pcontext;
    snprintf(buf,sizeof(buf),"User %s: cant get connected User (%s)",user(usern)->login,user(usern)->host);
    log(buf);
    if (user(usern)->rights!=RI_ADMIN) systemnotice(usern,buf);    
    quitclient(usern);    
    return -1;
}

int userinkill(int usern)
{
    char buf[400];
    pcontext;
    snprintf(buf,sizeof(buf),"User %s disconnected (from %s)",user(usern)->login,user(usern)->host);
    log(buf);
    if (user(usern)->rights!=RI_ADMIN) systemnotice(usern,buf);    
    quitclient(usern);    
    return -1;
}

