/*
moo.dll component file 
[myras.cpp - makes use of dllload.cpp to provide dynamic access to rasapi32.dll]
Copyright (C) 2000 Mark Hutton - mailto:mark@influenced.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "myras.h"
#include "assert.h"

TRasModule::TRasModule():TDllModule("rasapi32.dll")
{
	initAll();
}

TRasModule::~TRasModule()
{
}

void TRasModule::initAll(void)
{
	FRasEnumConnections98 = NULL;
	FRasEnumConnections2K = NULL;
	FRasGetConnectionStatistics = NULL;
}

BOOL TRasModule::Create(void)
{
	if (TDllModule::Create()) {
		// DLL handle is valid (DLL is loaded)
		FRasEnumConnections98 = (TFRasEnumConnections98)::GetProcAddress(m_hHandle,"RasEnumConnectionsA");
		FRasEnumConnections2K = (TFRasEnumConnections2K)::GetProcAddress(m_hHandle,"RasEnumConnectionsA");
		FRasGetConnectionStatistics = (TFRasGetConnectionStatistics)::GetProcAddress(m_hHandle,"RasGetConnectionStatistics");
		// Load all other needed functions    ...    // Can also check if all pointers to functions are different from NULL.
		return TRUE;
	}
	return FALSE;
}

void TRasModule::Destroy(void)
{
	TDllModule::Destroy();
	initAll();
}

DWORD TRasModule::RasEnumConnections98(LPRASCONN98 lprasconn, LPDWORD lpcb, LPDWORD lpcConnections)
{
	assert(FRasEnumConnections98 != NULL);
	if (FRasEnumConnections98) return FRasEnumConnections98(lprasconn, lpcb, lpcConnections);
	return FALSE;
}

DWORD TRasModule::RasEnumConnections2K(LPRASCONN2K lprasconn, LPDWORD lpcb, LPDWORD lpcConnections)
{
	assert(FRasEnumConnections2K != NULL);
	if (FRasEnumConnections2K) return FRasEnumConnections2K(lprasconn, lpcb, lpcConnections);
	return FALSE;
}

DWORD TRasModule::RasGetConnectionStatistics(HRASCONN hRasConn, PRAS_STATS lpStatistics)
{
	assert(FRasGetConnectionStatistics != NULL);
	if (FRasGetConnectionStatistics) return FRasGetConnectionStatistics(hRasConn,lpStatistics);
	return FALSE;
}

