#!/bin/sh
nohup ./wrapper.sh &
