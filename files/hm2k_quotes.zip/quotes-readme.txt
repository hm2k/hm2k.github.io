.o0{ Quotes v2.31 by HM2K }0o. - IRC@HM2K.ORG
based on scripts by mutilator and tonix
thanks to L-n and the rest of nemesisforce for helping me beta test it

Description:
Do you ever find that while your on mIRC, that there are just quotes that you should log,
or should store somewhere, maybe because they are funny, or embarrassing or similar, well now you can,
with this quotes script, you can either add/find/remove/total quotes remotely, or locally, without any hassle.
Never miss a quote again!

Installation: Make sure quotes.mrc is in your $mircdir then type: /load -rs quotes.mrc

Useage: Use the "Quotes" menu to control the script,
the main function is the triggers and the timer.
Remember to turn these on from the menu if you want others to beable to use it
Channel triggers are: !quote !findquote !addquote !totalquotes !removequotes

Quotes v2.31 - local alias' and other small fixes
Fixed the apparent "Make aliases the end user does not use local" problem (changed 'alias' to 'alias -l')

Quotes v2.3 - Official Release
Fixed a few bugs, changed a few things, completed the 'todo' of the previous version.

Quotes v2.2 - More Fixes and Adjustments
The outputs no longer evaluate the line read and treat it as plain text.
Therefore you're quotes.txt is no longer changed on the input.

Quotes v2.1 - Minor Bug Fixes
Most scripts have bugs in their initail releases, so did mine, fixed in this version

Quotes v2.0 - Rewritten
Added made the script smaller and quicker, added more features, and popups
Features now include: Timer: on/off Triggers: on/off Total Quotes, Add Quote, Remove Quote and Find Quote

Quotes v1.0 - Initial Public Release - Simple Code