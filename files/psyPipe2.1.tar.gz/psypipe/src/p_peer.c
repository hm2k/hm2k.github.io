/************************************************************************
 *   psypipe, src/p_peer.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_peer.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_PEER

#include <p_global.h>

char bnchost[200];
int sport=0;
int errn;

/* error & closed */


int killconnect(int socket)
{
    struct socketnodes *th;
    int sck1,sck2;
    th=getpsocketbysock(socket);
    if(th!=NULL)
    {
	th->sock->destructor=NULL;
	th->sock->errorhandler=NULL;
	sck1=th->sock->relaysock;
	sck2=th->sock->syssock;
	th=getpsocketbysock(sck1);
	if(th!=NULL)
	{
	    th->sock->destructor=NULL;
	    th->sock->errorhandler=NULL;
	}
	if(getpsocketbysock(sck1)!=NULL)
	    killsocket(sck1);
	if(getpsocketbysock(sck2)!=NULL)
	    killsocket(sck1);
    }
}

int errorconnect(int socket,int errn)
{
    killconnect(socket);
}

/* check a connected peer structure */

int checknewlistener(int i)
{
    fd_set rfds;
    int ret;
    struct timeval tv;
    int asocket,bsocket=77;
    int npeer;
    char buf[300];
    char hostname[200];
    struct socketnodes *lkm;
    pcontext;

    asocket = bncaccept( listensocket );
    pcontext;
    if(asocket<=0) return;    
    asocket=createsocket(asocket,ST_LISTEN,0,NULL,NULL,errorconnect,bound,killconnect);
    bsocket=createsocket(0,ST_CONNECT,0,NULL,NULL,errorconnect,bound,killconnect);
    bsocket=connectto(bsocket,tohost,toport,NULL);
    lkm=getpsocketbysock(listensocket);
    if(lkm!=NULL)
    {
	lkm->sock->flag=SOC_SYN; /* resetting the listener to listen again */
    }
    pcontext;
    if (asocket==-1) return -1;
    lkm=getpsocketbysock(asocket);
    pcontext;
    if(lkm!=NULL)
    {
	lkm->sock->param=asocket;
	lkm->sock->relaysock=bsocket;
	lkm->sock->flag=SOC_CONN;
	lkm->sock->encryption=SE_NOENC;
    }
    lkm=getpsocketbysock(bsocket);
    pcontext;
    if(lkm!=NULL)
    {
	lkm->sock->param=bsocket;
	lkm->sock->relaysock=asocket;
	lkm->sock->flag=SOC_SYN;
    }
    return;
}
/* create listening sock */

void killed ()
{
   exit(0x0);
}

/* error routine */

void errored ()
{
   errn = 1;
   return;
}

/* creating listening port for demon */

int createlistener (int listenport)
{
  struct sockaddr_in listen_sa;
  int sopts = 1;
  struct sigaction sv;
  struct sigaction sx;
  struct socketnodes *lkm;
  int opt;
  sigemptyset(&sv.sa_mask);
  sv.sa_handler = killed;
  sigemptyset(&sx.sa_mask);
  sx.sa_handler = errored;
  sigaction( SIGTERM, &sv, NULL);
  sigaction( SIGINT, &sx, NULL);
  sigaction( SIGKILL, &sv, NULL);
  sigaction( SIGHUP, &sx, NULL);
  sigaction( SIGUSR1, &sx, NULL);
  sigaction( SIGPIPE, &sx, NULL);
  umask( ~S_IRUSR & ~S_IWUSR );
  srand( time( NULL) );
  
  listensocket = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
  listensocket = createsocket(listensocket,ST_LISTEN,0,NULL,checknewlistener,NULL,NULL,NULL);
  lkm=getpsocketbysock(listensocket);
  if(lkm==NULL || listensocket==0)
  {
      return -1;
  }
  lkm->sock->flag=SOC_SYN; /* we are open */

  opt=sizeof(int);
  setsockopt (listensocket, SOL_SOCKET, SO_REUSEADDR, &sopts, opt);

  memset (&listen_sa, 0, sizeof (struct sockaddr_in));

  listen_sa.sin_port = htons (listenport);
  listen_sa.sin_addr.s_addr = htonl (INADDR_ANY);

  if ((bind (listensocket, (struct sockaddr *) &listen_sa, sizeof (struct sockaddr_in))) == -1)
  {
     return -1; /* cannot create socket */
  }
  if ((listen (listensocket, 1)) == -1)
  {
      return -1; /* cannot create socket */
  }
  return listensocket; /* success */
}


/* accept incoming call on listener */

int bncaccept( int lsock)
{
   struct sockaddr_in addr;
   struct hostent *hostinfo;
   struct socketnodes *lkm;
   int tm;
   int str;
   pcontext;
   memset(bnchost,0x0,sizeof(bnchost));
   tm = sizeof( struct sockaddr_in);
   str = accept(lsock, ( struct sockaddr * )&addr, &tm);
   if (str==-1) return -1;
   hostinfo = gethostbyaddr( ( char * )&addr.sin_addr.s_addr, sizeof( struct in_addr), AF_INET);
   if (hostinfo) snprintf(bnchost,sizeof(bnchost),"%s", hostinfo->h_name);
   else snprintf( bnchost,sizeof(bnchost),"%s", inet_ntoa( addr.sin_addr ));
   return str;
}
