/************************************************************************
 *   psybnc2.1, src/p_network.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_network.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_NETWORK

#include <p_global.h>

/* check parent users */

int checkparents(int usernum)
{
   int uparent;    
   pcontext;
   if (user(usernum)->parent != 0)
   {
       uparent=user(usernum)->parent;
       if (user(uparent)->instate == STD_NOUSE)
       {
           deluser(usernum);
	   loaduser(usernum);
       } else {
           snprintf(user(usernum)->login,sizeof(user(usernum)->login),"%s",user(uparent)->login);
           snprintf(user(usernum)->user,sizeof(user(usernum)->login),"%s",user(uparent)->user);
           snprintf(user(usernum)->pass,sizeof(user(usernum)->login),"%s",user(uparent)->pass);
	   user(usernum)->insock=user(uparent)->insock;
	   user(usernum)->instate=user(uparent)->instate;    
	   user(usernum)->rights=user(uparent)->rights;
       }
   }    
}

/* converting a outbounded input string to the nick of the parent */

int parentnick(int usern)
{
    char *pt;
    char *pt1;
    char *pt2;
    int uparent;
    char tmpbuf[8192];
    char nicktmp[70];
    pcontext;
    if (user(usern)->parent==0) return 0x0;
    uparent=user(usern)->parent;
    if (strlen(user(usern)->nick)==strlen(user(uparent)->nick)) {
	if (strstr(user(usern)->nick,user(uparent)->nick)!=NULL) {
	    return 0x0;
	}
    }
    if (ircbuf[0]==':')
    {
	snprintf(nicktmp,sizeof(nicktmp),":%s!",user(usern)->nick);
	if (strstr(ircbuf,nicktmp)==ircbuf) {
	    pt=ircbuf+strlen(nicktmp);
	    snprintf(tmpbuf,sizeof(tmpbuf),":%s!%s",user(uparent)->nick,pt);
	    snprintf(ircbuf,sizeof(ircbuf),"%s",tmpbuf);
	}
    }
    snprintf(nicktmp,sizeof(nicktmp)," %s ",user(usern)->nick);
    if (strlen(ircbuf)<1) return 0x0;
    pt=ircbuf;
    pt2=strchr(pt+1,':');
    while (1)
    {
	pt=strstr(pt+1,nicktmp);
	if (pt==NULL) break;
	if (pt>pt2 && pt2 != NULL) break;
	/* its the nick */
	pt1=pt+strlen(nicktmp);
	pt1--;
	*pt1=0;
	pt1++;
	*pt=0;
	snprintf(tmpbuf,sizeof(tmpbuf),"%s %s %s",ircbuf,user(uparent)->nick,pt1);
	snprintf(ircbuf,sizeof(ircbuf),"%s",tmpbuf);
    }
}

/* this routine checks for a network token - phew */

int checknetwork(int usern)
{
    struct usernodes *th;
    char tmpircbuf[8192];
    int i;
    char *pt;
    char *pt1;
    char *pt2;
    pcontext;
    th=usernode;
    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s",ircbuf);
    pt=strchr(tmpircbuf,'~');
    if (pt!=NULL) {
	pt1=pt;
	pt1--;
	if (*pt1=='*') { /* if its a userflag, try next item */
	    pt1=pt;pt1++;
	    pt=strchr(pt1,'~');
	    if (pt==NULL)
		goto notfound;
	}
	pt1=tmpircbuf+1;
	pt1=strchr(pt1,':');
	if (pt1 != NULL && pt>pt1) /* if network specified in content, bye */
	    goto notfound;
	pt1=pt;
	while (pt1!=tmpircbuf && *pt1!=' ') pt1--;
	if (pt1==tmpircbuf) goto notfound; /* at start of the buffer ? nah */
	/* in pt1 = start of networktoken, in pt = end of network token */
	*pt1=0; /* buffer part 1 */
	*pt=0; /* buffer part 2 */
	pt2=pt;pt2++;pt1++;
	if (*pt1=='#') pt1++; /* filtering the channels */
	while (th!=NULL)
	{
	    i=th->uid;
	    if (user(i)->parent==usern)
	    {
		if (strlen(user(i)->network)==strlen(pt1)) {
		    if (strstr(user(i)->network,pt1)!=NULL) {
			goto found;
		    }
		}
	    }
	    th=th->next;
	}
	/* interesting network token, but not existent, telling the user its unknown */
	snprintf(tmpircbuf,sizeof(tmpircbuf),"%s - Unknown Network\n",pt1);
	writesock(user(usern)->insock,tmpircbuf);
	/* clearing ircbuf */
	memset (ircbuf,0x0,sizeof(ircbuf));
	goto notfound;
    } else
	goto notfound;
found:
    /* ok, we got it. its a valid network. Network user is in i
       pt2 has the second part of the buffer, tmpircbuf is terminated
       before start of network token. Lets craft the untokened ircbuf now */
    snprintf(ircbuf,sizeof(ircbuf),"%s %s",tmpircbuf,pt2);    
    /* setting parents inbound flags to child */
    user(i)->insock=user(usern)->insock;
    if (user(i)->instate!=STD_WHOIS) user(i)->instate=user(usern)->instate;
    /* returning the network uid */
    return i;
notfound:
    return usern;
}

/* this is a bitch -> adding the network token to the currents network-Users-
   Inbound 									*/

int addtoken(int usern)
{
    char *pt;
    char *pt1;
    char *pt2;
    char tmpircbuf[8192];
    char tmpircbuf2[8192];
    char nameline[200];
    char l;
    int broken;
    int eflg;
    pcontext;
    eflg=0;
    /* parsing channels */
    pt1=strstr(ircbuf,ircto);
    if (pt1==NULL) goto nochan;
    pt2=strchr(ircbuf+1,':');
    if (ifcommand("JOIN") || ifcommand("PART") || ifcommand("NICK")) pt2=NULL;
    pt=strchr(pt1,'#');
    if (pt==NULL) pt=strchr(pt1,'+');
    if (pt==NULL) pt=strchr(pt1,'&');
    pcontext;
    if (pt!=NULL)
    {
	if (pt>pt2 && pt2 !=NULL) goto nochan;
	pt=strstr(ircbuf,pt);
	/* a channel. We preceed the 'to' parameter */
	if (pt!= NULL)
	{
	    pt--;
	    l=*pt;
	    *pt=0;
	    pt++;
	    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s%c#%s~%s",ircbuf,l,user(usern)->network,pt);
	    snprintf(ircbuf,sizeof(ircbuf),"%s",tmpircbuf);
        }
	goto skipuser;
    } 
nochan:
    /* no, its a user ! */
    /* checking, if we are the dest */
    pcontext;
    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s",user(usern)->nick);
    if (strlen(tmpircbuf)==strlen(ircto)) {
        if (strstr(tmpircbuf,ircto)!=NULL) {
    	    goto skipuser; /* we are not tokened */
	}
    }
    /* that is restricted to the following commands */
    if (ifcommand("NICK"))
    {
	pt=strstr(ircbuf,ircto);
	if (pt!= NULL)
	{
	    pt--;
	    l=*pt;
	    *pt=0;
	    pt++;
	    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s%c%s~%s",ircbuf,l,user(usern)->network,pt);
	    snprintf(ircbuf,sizeof(ircbuf),"%s",tmpircbuf);
    	}
    }
skipuser:
    pcontext;
    /* parsing Users */
    if (strchr(ircfrom,'@') != NULL) { /* if theres a @ in the from, its a user */
	if (strlen(ircnick)==strlen(user(usern)->nick)) {
	    if (strstr(ircnick,user(usern)->nick)!=NULL) goto nouser;
	}
	snprintf(tmpircbuf,sizeof(tmpircbuf),"%c%s~%s",*ircbuf,user(usern)->network,ircbuf+1);
	snprintf(ircbuf,sizeof(ircbuf),"%s",tmpircbuf);
    }
nouser:
    pcontext;
    parentnick(usern);
    /* special content parsing has to be done on NAMES and WHO */
    broken=0;
    if (ifcommand("353"))
    { /* names */
	pt=ircbuf;
	pt++;
	pt=strchr(pt,':');
	if (pt!=NULL) 
	{
	    pt++;
	    l=*pt;
	    *pt=0;
	    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s",ircbuf);
	    snprintf(nameline,sizeof(nameline),"%s",ircbuf);
	    *pt=l;
	    /* now the hard stuff.. we precede every Nick */
	    while(eflg==0)
	    {
		pt1=strchr(pt,' ');
		if (pt1!=NULL) {
		    *pt1=0;l=32;
		} else {
		    eflg=1;l=0;
		}
		/* the modes */
		if (*pt=='@' || *pt=='+') {
		    snprintf(tmpircbuf2,sizeof(tmpircbuf2),"%s%c",tmpircbuf,*pt);
		    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s",tmpircbuf2);
		    pt++;
		}
		/* if its us, we dont parse */
		if (strstr(pt,user(usern)->nick) && strlen(pt)==strlen(user(usern)->nick))
		{
		    snprintf(tmpircbuf2,sizeof(tmpircbuf2),"%s%s%c",tmpircbuf,user(user(usern)->parent)->nick,l);
		} else {
		    if (l==0)
 			snprintf(tmpircbuf2,sizeof(tmpircbuf2),"%s%s%c",tmpircbuf,pt,l);
		    else
 			snprintf(tmpircbuf2,sizeof(tmpircbuf2),"%s%s~%s%c",tmpircbuf,user(usern)->network,pt,l);
		}
		snprintf(tmpircbuf,sizeof(tmpircbuf),"%s",tmpircbuf2);
		/* avoiding the limit exceed */
		if (strlen(tmpircbuf)>500)
		{
		    /* sending the result up to here */
		    writesock(user(usern)->insock,tmpircbuf);
		    /* building new names line */
		    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s",nameline);
		}
		pt=pt1+1;
	    }
	    snprintf(ircbuf,sizeof(ircbuf),"%s",tmpircbuf);
	}
    }
    pcontext;
    if (ifcommand("352"))
    { /* who */
	pt=ircbuf;
	for (eflg=0;eflg<7;eflg++)
	{
	   pt=strchr(pt+1,' ');if (pt==NULL) goto nowho;
	}
	*pt=0;
	pt++;
	pt2=strchr(pt,' ');
	if (pt2==NULL) goto nowho;
	*pt2=0;
	pt2++;
	/* here also, we skip us */
	if (strstr(user(usern)->nick,pt) && strlen(pt)==strlen(user(usern)->nick)) {
	   snprintf(tmpircbuf,sizeof(tmpircbuf),"%s %s %s",ircbuf,user(user(usern)->parent)->nick,pt2);
	} else {
	   snprintf(tmpircbuf,sizeof(tmpircbuf),"%s %s~%s %s",ircbuf,user(usern)->network,pt,pt2);
	}
	snprintf(ircbuf,sizeof(ircbuf),"%s",tmpircbuf);
    }
nowho:
    pcontext;
    if (ifcommand("MODE"))
    { /* this is funny. we have to decide, that a parameter is no hostmask and preceed it */
	pt=strchr(ircbuf,' ');
	if (pt==NULL) goto nomode;
	pt=strchr(pt+1,' ');
	if (pt==NULL) goto nomode;
	pt++;
	if (*pt == '#' || *pt == '&' || *pt == '+')
	{ /* a channel, ok, check the parameters */
	    pt=strchr(pt,' ');
	    if (pt==NULL) goto nomode;
	    /* million of ircds, thousands of networks.. we cant parse the modes
	       we parse the parameters */
	    pt++;
	    pt=strchr(pt,' ');
	    if (pt==NULL) goto nomode;
	    /* now the parameters. Its no nick, if: @ is in, no user.
	       if first character is numeric, no user. Problem is:
	       Channel Key. Events Client side on NickBan.              */
	    *pt=0;
	    snprintf(tmpircbuf,sizeof(tmpircbuf),"%s ",ircbuf);
	    pt++;
	    eflg=0;
	    while (eflg==0)
	    {
		pt2=strchr(pt,' ');
		if (pt2!=NULL) 
		{
		    l=*pt2;
		    *pt2=0;
		    pt2++;
		} else {
		    l=0;eflg=1;
		}
		if (strchr("0123456789",*pt) == NULL && strchr(pt,'@')==NULL && strlen(pt)>2)
		{
		    snprintf(tmpircbuf2,sizeof(tmpircbuf2),"%s%s~%s%c",tmpircbuf,user(usern)->network,pt,l);
		} else {
		    snprintf(tmpircbuf2,sizeof(tmpircbuf2),"%s%s%c",tmpircbuf,pt,l);
		}
		snprintf(tmpircbuf,sizeof(tmpircbuf),"%s",tmpircbuf2);
		pt=pt2;
	    }
	    snprintf(ircbuf,sizeof(ircbuf),"%s",tmpircbuf);
	}	
    }
nomode:
    pcontext;
    if (ifcommand("KICK"))
    { /* a kick. we need to preceed the victim */
	pt=strchr(ircbuf,' ');
	if (pt==NULL) goto nokick;
	pt++;
	pt=strchr(pt,' ');
	if (pt==NULL) goto nokick;
	pt++;
	pt=strchr(pt,' ');
	if (pt==NULL) goto nokick;
	*pt=0;
	pt++;
	/* the victim */
	pt2=strchr(pt,' ');
	if (pt2==NULL) goto nokick;
	*pt2=0;
	pt2++;
	if (strlen(user(user(usern)->parent)->nick)==strlen(pt) && strstr(user(user(usern)->parent)->nick,pt)!=NULL)
	{
	   snprintf(tmpircbuf,sizeof(tmpircbuf),"%s %s %s",ircbuf,pt,pt2);
	} else {
	   snprintf(tmpircbuf,sizeof(tmpircbuf),"%s %s~%s %s",ircbuf,user(usern)->network,pt,pt2);
	}
	snprintf(ircbuf,sizeof(ircbuf),"%s",tmpircbuf);
    }
nokick:
}

/* checking, if network exists for a user */
int checkusernetwork(int usern)
{
    struct usernodes *th;
    int uind;
    pcontext;
    th=usernode;
    while(th!=NULL)
    {
	uind=th->uid;
	if (user(uind)->parent==usern) {
	    if (strlen(user(uind)->network)==strlen(irccontent)) {
	       if (strstr(user(uind)->network,irccontent) != NULL) {
	           return uind;
	       }
	    }
	}
	th=th->next;
    }
    return 0;
}
