/***************************************************************************
 *   copyright           : (C) 2002 by Hendrik Sattler                     *
 *   mail                : post@hendrik-sattler.de                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

/*
 * this function expect as input a 7bit-GSM unencoded string as
 *    produced from convert_to_gsm and outputs a char* that must be
 *    freed and is suitable as text for phonebook upload
 */
char* pb_mask_chars (unsigned char* input);
