/*
Module : DYNDATA.H
Purpose: Defines the interface for a class to access the performance data 
         as stored under the HKEY_DYN_DATA registry key on Windows 95/98.
         Please note that this class is not designed to be used on NT.
Created: PJN / 31-01-1999
History: None
Copyright (c) 1999 by PJ Naughter.  
All rights reserved.

*/


/* TO DO
1. Test functions accessing a networked machine
2. Develop a web page describing code
3. Update whats new page
4. Update link page
*/

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <stdio.h>
#include <conio.h>


#ifndef __DYNDATA_H__
#define __DYNDATA_H__


//Forward declaration
class CDynDataObject;                      

typedef BOOL (*ENUMERATE_DYNDATA_OBJECT_COUNTERS)(DWORD dwItemData, CDynDataObject& object, const CString& sRegistryName, 
                                                  const CString& sCommonName, const CString& sDescription, BOOL bDifferentiate);

//Class which represents a single performance object
class CDynDataObject
{
public:
//Constructors / Destructors
  CDynDataObject(LPCTSTR pszObjName, HKEY hObjectKey);
  CDynDataObject(LPCTSTR pszObjName, LPCTSTR pszComputerName);
  
//Methods
  BOOL EnumCounters(ENUMERATE_DYNDATA_OBJECT_COUNTERS lpEnumFunc, DWORD dwItemData = 0);
  CString GetName() const { return m_sName; };
  CString GetDescription() const { return m_sDescription; };

protected:
//Methods
  BOOL _EnumCounters(ENUMERATE_DYNDATA_OBJECT_COUNTERS lpEnumFunc, DWORD dwItemData, HKEY hObjectKey);

//Data
  CString m_sName;
  CString m_sDescription;
  HKEY    m_hObjectKey;
  CString m_sComputerName;
};


typedef BOOL (*ENUMERATE_DYNDATA_OBJECTS)(DWORD dwItemData, CDynDataObject& object);

//Class which allows enumeration of a performance objects on a specifed computer
class CDynDataEnumerator
{
public:
//Methods
  BOOL EnumObjects(ENUMERATE_DYNDATA_OBJECTS lpEnumFunc, DWORD dwItemData = 0, LPCTSTR pszComputerName = NULL);
};

//Class which represents a specific usage of a performace counter
class CDynDataCounter
{
public:
//Constructors / Destructors
  CDynDataCounter();
  virtual ~CDynDataCounter();

//Methods
  BOOL Start(LPCTSTR pszObjName, LPCTSTR pszCounterName, LPCTSTR pszComputerName = NULL);
  BOOL Collect(DWORD& dwData);
  BOOL Stop();
  CString GetCounterName() const { return m_sCounterName; };

protected:
  CString m_sCounterName;   
  CString m_sComputerName;
};


#endif //__DYNDATA_H__