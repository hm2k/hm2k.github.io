/************************************************************************
 *   psybnc2.1, src/p_userfile.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_userfile.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_USERFILE

#include <p_global.h>

/* loading a specific user */

int loaduser (int usernum) {
   char fnmuser[100];
   char buf[100];
   char *pt;
   int rc;
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.INI",usernum);
   if (user(usernum)->outstate > 1) {
      snprintf(buf,sizeof(buf),"QUIT :simon says: rehashing\n");
      writesock(user(usernum)->outsock,buf);
      killsocket(user(usernum)->outsock);
      memset(user(usernum)->server,0x0,sizeof(user(usernum)->server));
      user(usernum)->outstate=0;
      user(usernum)->outsock=0;
   }
   if (user(usernum)->instate > 1 && user(usernum)->parent==0) {
       snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %n :rehashing\n",user(usernum)->nick);
       writesock(user(usernum)->insock,buf);
       killsocket(user(usernum)->insock);
       memset(user(usernum)->host,0x0,sizeof(user(usernum)->host));
       user(usernum)->instate=0;
       user(usernum)->insock=0;
   }
   clearuser(usernum);
   rc = getini("USER","LOGIN",fnmuser);
   if (rc != 0) {
      return -1;
   }
   U_CREATE=1; /* if not existing, make new */
   nousers=0;
   snprintf(user(usernum)->login,sizeof(user(usernum)->login),"%s",value);
   rc = getini("USER","PARENT",fnmuser);
   if (rc==0)    
      user(usernum)->parent=atoi(value);
   else
      user(usernum)->parent=0;
   rc = getini("USER","USER",fnmuser);
   snprintf(user(usernum)->user,sizeof(user(usernum)->user),"%s",value);
   rc = getini("USER","NICK",fnmuser);
   if (rc != 0) {
      snprintf(value,sizeof(value),"psy%d",usernum);
   }
   snprintf(user(usernum)->nick,sizeof(user(usernum)->nick),"%s",value);
   snprintf(user(usernum)->wantnick,sizeof(user(usernum)->wantnick),"%s",value);
   rc = getini("USER","PASS",fnmuser);
   if (rc != 0) {
      snprintf(buf,sizeof(buf),"Warning ! User %s has no password set.",user(usernum)->login);
      log(buf);
      snprintf(value,sizeof(value),randstring(16));
   }
   snprintf(buf,sizeof(buf),"%s%s",slt1,slt2);
   if (*value!='=')
   {
       if(*value=='+')
       {
           snprintf(value,sizeof(value),"%s",decryptit(value));
       } else {
           snprintf(value,sizeof(value),randstring(16));
       }
       pt=BLOW_stringencrypt(buf,value);
       snprintf(value,sizeof(value),"=%s",pt);
       free(pt);
       writeini("USER","PASS",fnmuser,value);
   }
   snprintf(user(usernum)->pass,sizeof(user(usernum)->pass),"%s",value);
   rc = getini("USER","VHOST",fnmuser);
   snprintf(user(usernum)->vhost,sizeof(user(usernum)->vhost),"%s",value);
   rc = getini("USER","PROXY",fnmuser);
   snprintf(user(usernum)->proxy,sizeof(user(usernum)->proxy),"%s",value);
   rc = getini("USER","AWAY",fnmuser);
   snprintf(user(usernum)->away,sizeof(user(usernum)->away),"%s",value);
   rc = getini("USER","AWAYNICK",fnmuser);
   snprintf(user(usernum)->awaynick,sizeof(user(usernum)->awaynick),"%s",value);
   rc = getini("USER","LEAVEMSG",fnmuser);
   snprintf(user(usernum)->leavemsg,sizeof(user(usernum)->leavemsg),"%s",value);
   rc = getini("USER","LASTWHOIS",fnmuser);
   snprintf(user(usernum)->lastwhois,sizeof(user(usernum)->lastwhois),"%s",value);
   rc = getini("USER","NETWORK",fnmuser);
   snprintf(user(usernum)->network,sizeof(user(usernum)->network),"%s",value);
   rc = getini("USER","CRKEY",fnmuser);
   snprintf(user(usernum)->crkey,sizeof(user(usernum)->crkey),"%s",decryptit(value));
   if(rc!=0)
   {
       *user(usernum)->crkey=0;
   }
   rc = getini("USER","RIGHTS",fnmuser);
   if (rc != 0) {
      user(usernum)->rights=RI_USER;
   } else {
      user(usernum)->rights = atoi(value);
   }
   rc = getini("USER","QUITTED",fnmuser);
   if (rc != 0) {
      user(usernum)->quitted=0;
   } else {
      user(usernum)->quitted = atoi(value);
   }
   rc = getini("USER","VLINK",fnmuser);
   if (rc != 0) {
      user(usernum)->vlink=0;
   } else {
      user(usernum)->vlink = atoi(value);
   }
   rc = getini("USER","PPORT",fnmuser);
   if (rc != 0) {
      user(usernum)->pport=0;
   } else {
      user(usernum)->pport = atoi(value);
   }
   rc = getini("USER","ACOLLIDE",fnmuser);
   if (rc != 0) {
      user(usernum)->acollide=1;
   } else {
      user(usernum)->acollide = atoi(value);
   }
   rc = getini("USER","SYSMSG",fnmuser);
   if (rc != 0) {
      user(usernum)->sysmsg=1;
   } else {
      user(usernum)->sysmsg = atoi(value);
   }
   rc = getini("USER","LASTLOG",fnmuser);
   if (rc != 0) {
      user(usernum)->lastlog=0;
   } else {
      user(usernum)->lastlog = atol(value);
   }
   user(usernum)->insock = 0;
   user(usernum)->outsock = 0;
   user(usernum)->instate = STD_NOCON;
   user(usernum)->outstate = STD_NOCON;
   user(usernum)->dcc=(struct linknodes *)pmalloc(sizeof(struct linknodes));
   loaddccs(usernum);
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.BAN",usernum);
   user(usernum)->bans=loadlist(fnmuser,user(usernum)->bans);
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.OP",usernum);
   user(usernum)->ops=loadlist(fnmuser,user(usernum)->ops);
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.AOP",usernum);
   user(usernum)->aops=loadlist(fnmuser,user(usernum)->aops);
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.ASK",usernum);
   user(usernum)->askops=loadlist(fnmuser,user(usernum)->askops);
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.LGI",usernum);
   user(usernum)->logs=loadlist(fnmuser,user(usernum)->logs);
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.KEY",usernum);
   user(usernum)->keys=loadlist(fnmuser,user(usernum)->keys);
#ifdef CRYPT
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.ENC",usernum);
   user(usernum)->encrypt=loadlist(fnmuser,user(usernum)->encrypt);
#endif
#ifdef TRANSLATE
   snprintf(fnmuser,sizeof(fnmuser),"USER%d.TRA",usernum);
   user(usernum)->translates=loadlist(fnmuser,user(usernum)->translates);
#endif
#ifdef TRAFFICLOG
   snprintf(buf,sizeof(buf),"USER%d.TRL",usernum);
   user(usernum)->trafficlog=fopen(buf,"a");
#endif
   return;
}


/* this writes a user info to the bounce inifile */

int writeuser(int usern)
{
    char iset[8];
    char fname[20];
    char buf[100];
    snprintf(fname,sizeof(fname),"USER%d.INI",usern);
    writeini("USER","NICK",fname,user(usern)->nick);
    writeini("USER","LOGIN",fname,user(usern)->login);
    writeini("USER","USER",fname,user(usern)->user);
    if(*user(usern)->pass!='=')
    {
	snprintf(buf,sizeof(buf),"%s%s",slt1,slt2);
	snprintf(user(usern)->pass,sizeof(user(usern)->pass),"=%s",BLOW_stringencrypt(buf,user(usern)->pass));
    }
    writeini("USER","PASS",fname,user(usern)->pass);
    writeini("USER","VHOST",fname,user(usern)->vhost);
    writeini("USER","PROXY",fname,user(usern)->proxy);
    writeini("USER","AWAY",fname,user(usern)->away);
    writeini("USER","LEAVEMSG",fname,user(usern)->leavemsg);
    writeini("USER","AWAYNICK",fname,user(usern)->awaynick);
    writeini("USER","NETWORK",fname,user(usern)->network);
    if(*user(usern)->crkey!=0)
	writeini("USER","CRKEY",fname,cryptit(user(usern)->crkey));
    snprintf(iset,sizeof(iset),"%d",user(usern)->rights);
    writeini("USER","RIGHTS",fname,iset);
    snprintf(iset,sizeof(iset),"%d",user(usern)->vlink);
    writeini("USER","VLINK",fname,iset);
    snprintf(iset,sizeof(iset),"%d",user(usern)->pport);
    writeini("USER","PPORT",fname,iset);
    snprintf(iset,sizeof(iset),"%d",user(usern)->parent);
    writeini("USER","PARENT",fname,iset);
    snprintf(iset,sizeof(iset),"%d",user(usern)->quitted);
    writeini("USER","QUITTED",fname,iset);
    snprintf(iset,sizeof(iset),"%d",user(usern)->acollide);
    writeini("USER","ACOLLIDE",fname,iset);
    snprintf(iset,sizeof(iset),"%d",user(usern)->sysmsg);
    writeini("USER","SYSMSG",fname,iset);
    snprintf(iset,sizeof(iset),"%d",user(usern)->lastlog);
    writeini("USER","LASTLOG",fname,iset);
    writeini("USER","LASTWHOIS",fname,user(usern)->lastwhois);
}

/* this writes a link info to the link inifile */

int writelink(int linkn)
{
    char iset[8];
    char fname[20];
    char lname[20];
    snprintf(fname,sizeof(fname),"%s","LINKS.INI");
    snprintf(lname,sizeof(lname),"LINK%d",linkn);
    snprintf(iset,sizeof(iset),"%d",datalink(linkn)->type);
    writeini(lname,"TYPE",fname,iset);
    snprintf(iset,sizeof(iset),"%d",datalink(linkn)->port);
    writeini(lname,"PORT",fname,iset);
    writeini(lname,"NAME",fname,datalink(linkn)->name);
    writeini(lname,"IAM",fname,datalink(linkn)->iam);
    writeini(lname,"HOST",fname,datalink(linkn)->host);
    writeini(lname,"PASS",fname,cryptit(datalink(linkn)->pass));
    if(*datalink(linkn)->crkey!=0)
	writeini(lname,"CRKEY",fname,cryptit(datalink(linkn)->crkey));
    snprintf(iset,sizeof(iset),"%d",datalink(linkn)->allowrelay);
    writeini(lname,"ALLOWRELAY",fname,iset);
}

/* erase a link entry */

int eraselinkini(int linkn)
{
    char iset[8];
    char fname[20];
    char lname[20];
    snprintf(fname,sizeof(fname),"%s","LINKS.INI");
    snprintf(lname,sizeof(lname),"LINK%d",linkn);
    writeini(lname,"TYPE",fname,NULL);
    writeini(lname,"PORT",fname,NULL);
    writeini(lname,"NAME",fname,NULL);
    writeini(lname,"IAM",fname,NULL);
    writeini(lname,"HOST",fname,NULL);
    writeini(lname,"PASS",fname,NULL);
    writeini(lname,"CRKEY",fname,NULL);
    writeini(lname,"ALLOWRELAY",fname,NULL);
}

/* load all user structures */

int loadusers(void)
{
   struct usernodes *th;    
   int curuser;
   pcontext;
   curuser = 1;
   log("Loading all Users..");
   while (curuser < MAX_USER) 
   {
       loaduser(curuser);
       curuser++;
   }
   if (nousers) log("No Users found.");
   th=usernode;
   while (th!=NULL) 
   {
       curuser=th->uid;
       checkparents(curuser);
       th=th->next;
   }
   return 0x0;
}

/* load a special link */

int loadlink(int linkn)
{
    int rc;
    char lname[20];
    char buf[400];
    char lfile[20];
    if (datalink(linkn)->type==LI_RELAY) return 0x0; /* not resetting dynamic links */
    if (datalink(linkn)->outstate==STD_CONN) {
        snprintf(buf,sizeof(buf),"LINK: -> %s (%d) closing\n",datalink(linkn)->host,datalink(linkn)->port);
	log(buf);
	killsocket(datalink(linkn)->outsock);
    }
    if (datalink(linkn)->instate==STD_CONN) {
        snprintf(buf,sizeof(buf),"LINK: <- %s (%d) closing\n",datalink(linkn)->host,datalink(linkn)->port);
	log(buf);
	killsocket(datalink(linkn)->insock);
    }
    snprintf(lfile,sizeof(lfile),"LINKS.INI");
    snprintf(lname,sizeof(lname),"LINK%d",linkn);
    rc=getini(lname,"TYPE",lfile);
    clearlink(linkn);
    if (rc!=0) 
	return 0x0;
    D_CREATE=1;
    datalink(linkn)->type=atoi(value);
    rc=getini(lname,"HOST",lfile);
    if (rc!=0) memset(value,0x0,sizeof(value));
    snprintf(datalink(linkn)->host,sizeof(datalink(linkn)->host),"%s",value);
    rc=getini(lname,"PORT",lfile);
    if (rc!=0)
	datalink(linkn)->port=0;
    else
	datalink(linkn)->port=atoi(value);
    rc=getini(lname,"ALLOWRELAY",lfile);
    if (rc!=0)
	datalink(linkn)->allowrelay=0;
    else
	datalink(linkn)->allowrelay=atoi(value);
    rc=getini(lname,"PASS",lfile);
    snprintf(datalink(linkn)->pass,sizeof(datalink(linkn)->pass),"%s",decryptit(value));
    rc=getini(lname,"CRKEY",lfile);
    snprintf(datalink(linkn)->crkey,sizeof(datalink(linkn)->crkey),"%s",decryptit(value));
    if(rc!=0)
    {
	*datalink(linkn)->crkey=0;
    }
    rc=getini(lname,"NAME",lfile);
    if (rc!=0) memset(value,0x0,sizeof(value));
    snprintf(datalink(linkn)->name,sizeof(datalink(linkn)->name),"%s",value);
    rc=getini(lname,"IAM",lfile);
    if (rc!=0) memset(value,0x0,sizeof(value));
    snprintf(datalink(linkn)->iam,sizeof(datalink(linkn)->iam),"%s",value);
    datalink(linkn)->instate=STD_NOCON;
    datalink(linkn)->outstate=STD_NOCON;
    datalink(linkn)->delayed=linkn;
}

/* load all links */

int loadlinks()
{
    int i=1;
    pcontext;
    while (i<MAX_USER)
    {
	loadlink(i);
	i++;
    }
}

/* check if user exists, returns number of userrecord or 0 if not existant */

int checkuser(char *nick)
{
    struct usernodes *th;
    int uind;
    char *pt;
    th=usernode;
    while (th!=NULL)
    {
	uind=th->uid;
	if (strlen(user(uind)->login) == strlen(nick)) {
	    pt=strstr(user(uind)->login,nick);
	    if (pt != NULL) {
	       if (user(uind)->parent!=0) uind=user(uind)->parent;	
	       return uind;
	    }
	}
	th=th->next;
    }
    return 0x0;
}

