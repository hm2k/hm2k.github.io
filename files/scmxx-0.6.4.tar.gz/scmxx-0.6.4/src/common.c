/***************************************************************************
 *   copyright           : (C) 2002 by Hendrik Sattler                     *
 *   mail                : post@hendrik-sattler.de                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "common.h"

void add_at_command(char *at_command_p, char *addon_p,...){
  va_list arg_list;
  va_start(arg_list,addon_p);
  vsprintf(&at_command_p[strlen(at_command_p)],addon_p,arg_list);
  va_end(arg_list);
}

void new_at_command(char *at_command_p, char *addon_p){
  memcpy(&at_command_p[0],AT_PREFIX,sizeof(AT_PREFIX));
  add_at_command(at_command_p,addon_p);
}
