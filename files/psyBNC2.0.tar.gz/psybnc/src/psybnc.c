/************************************************************************
 *   psybnc2.1, src/psybnc.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *		    	      th3 Co0l laMeRz
 *		 .--------..-----.  .---.---. .--. .-.----.
 *		 ||.____  |   ___| ||   |__  ||   \||   __/
 *		 |||__//  |  / \\ Y/   / LL| ||    Y|  /
 *		 ||  .___/\  \  \\    /|   ./|| |\  | | II
 *		 ||  |    ||  |  ||  ||| __ \|| ||| | | 
 *		 ||  |___//  /   ||  ||| LL| || ||| |  \___
 *		 |L_/ \_____/    |L__||L___./|L_||L_|\____/
 *		 |	  written by psychoid/tCl	 |
 *		 !	psychoid bouncer Version 2.1.1	 !	
 *		 :         for personal use only	 :
 *		 .	  dont use it commercial 	 .
 *		                                         .
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: psybnc.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif


#define P_MAIN

#include <p_global.h>
#include <p_data.h>

int slice=0;

/* main bounce-loop */

int bncmain(void) {
   while(1)
   {
       socketdriver();	
       if(delayinc==1) /* processor usage decreasing */
       {
           slice++;
	   if(slice==1)
               checkclients();
	   if(slice==2)
               checklinks();
	   if(slice==3)
	   {
               checkdccs();
	   }
	   if(slice==4)
	   {
#ifdef TRANSLATE
               cleartranslates();
#endif
	       if(mainlog!=NULL) fflush(mainlog);
	       slice=0;
	   }
       }
   }
   return 0x0; /* i wonder how often we get here */
}

/* printing the banner */

int printbanner(void)
{
   fprintf(stdout,"    	        th3 co0l laMeRz\n");
   fprintf(stdout," .--------..-----.  .---.---. .--. .-.----.\n");
   fprintf(stdout," ||.____  |   ___| ||   |__  ||   \\||   __/\n");
   fprintf(stdout," |||__//  |  / \\\\ Y/   / LL| ||    Y|  /\n");
   fprintf(stdout," ||  .___/\\  \\  \\\\    /|   ./|| |\\  | | II\n");
   fprintf(stdout," ||  |    ||  |  ||  ||| __ \\|| ||| | | \n");
   fprintf(stdout," ||  |___//  /   ||  ||| LL| || ||| |  \\___\n");
   fprintf(stdout," |L_/ \\_____/    |L__||L___./|L_||L_|\\____/\n");
   fprintf(stdout," |         written by psychoid/tCl       |\n");
   fprintf(stdout," !     psychoid bouncer Version " APPVER "    !\n");	
   fprintf(stdout," :          for personal use only        :\n");
   fprintf(stdout," .          dont use it commercial       .\n");
   fprintf(stdout,"                                         .\n");
   return 0x0;
}

/* installation loop */

int
main (int argc, char **argv)
{
  int rc;
  char buf[200];
  FILE *pidfile;
  printbanner();
  snprintf(logfile,sizeof(logfile),"psbnc.log");
  rc = getini("SYSTEM","PORT",INIFILE);
  if (rc == -1) {
     printf("Configuration File psbnc.ini not found, aborting ..\n");
     exit (0x0);
  } else
  if (rc == -2) {
     printf("No Listenport defined in psbnc.ini.\nInsert PORT=xxxx to the section SYSTEM\n");
     exit (0x0);
  }
  listenport = atoi(value);
  rc = getini("SYSTEM","ME",INIFILE);
  if (rc < 0) {
     memset(value,0x0,sizeof(value));       
  }
  snprintf(me,sizeof(me),"%s",value);
  rc = getini("SYSTEM","LOGFILE",INIFILE);
  if (rc < 0) {
     printf("No logfile specified, logging to psbnc.log\n");
     snprintf(value,sizeof(value),"psbnc.log");
  }
  snprintf(logfile,sizeof(logfile),"%s",value);
  oldfile(logfile);
  /* creating the socket-root */
  socketnode=(struct socketnodes *) pmalloc(sizeof(struct usernodes));
  socketnode->sock=NULL;
  socketnode->next=NULL;
  /* creating the demon socket */
  rc = createlistener(listenport);
  if (rc == -1) {
    printf("Cannot create listening port .. aborting\n");
    exit (0x0);
  }
  /* creating background */
  pid = fork();
  if (pid < 0) {
  
  }
  if (pid == 0) {
     rc= errorhandling();
     makesalt();
     U_CREATE=0;
#ifdef PARTYCHANNEL
     /* partychannel setup */
     strcpy(partytopic,"psyBNC-Partyline Channel");
     partyusers=NULL;
#endif
     /* creating the usernode-root */
     usernode=(struct usernodes *) pmalloc(sizeof(struct usernodes));
     usernode->uid=0;
     usernode->user=NULL;
     usernode->next=NULL;
     /* creating the newpeer-root */
     peernode=(struct peernodes *) pmalloc(sizeof(struct peernodes));
     peernode->uid=0;
     peernode->peer=NULL;
     peernode->next=NULL;
     /* creating the datalink-root */
     linknode=(struct linknodes *) pmalloc(sizeof(struct linknodes));
     linknode->uid=0;
     linknode->link=NULL;
     linknode->next=NULL;
     /* loading the users */
     loadusers();
     loadlinks();
     /* loading the hostallows */
     hostallows=loadlist("psbnc.hosts",hostallows);
  }
  if (pid) {
     pidfile = fopen("psbnc.pid","w");
     printf("Forked to the background (PID %d)\n",pid);
     snprintf(buf,sizeof(buf),"psyBNC started (PID :%d)",pid);
     log(buf);
     fprintf( pidfile,"%d\n",pid);
     exit (0x0);
  }  
  bncmain();
}

