/***************************************************************************
 *   copyright           : (C) 2002 by Hendrik Sattler                     *
 *   mail                : post@hendrik-sattler.de                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef CHARSETS_H
#define CHARSETS_H

#include "depincludes.h"

wchar_t* convert_to_internal (char* from_code, char* input, size_t insize);
char* convert_from_internal (char* to_code, wchar_t* input, int replacement_mode);

unsigned char* convert_to_gsm (wchar_t* input);
wchar_t* convert_from_gsm (unsigned char* input);

unsigned char* convert_to_ucs2 (wchar_t* input);
wchar_t* convert_from_ucs2 (unsigned char* input);

#endif
