/************************************************************************
 *   psypipe, src/p_global.h
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <signal.h>
#include <errno.h>
#ifdef HAVE_CONFIG
#include <config.h>
#endif

#define INIFILE "psbnc.ini"
/* change this to support more users */

#define MAX_USER 1000 /* only the REAL used useramount uses memory and clock */

/* socket types */
#define ST_CONNECT	0x0000 /* SOCKET CONNECTS */
#define ST_LISTEN	0x0001 /* SOCKET LISTENS */

/* socket flags */
#define SOC_NOUSE	0x0000 /* SOCKET NOT IN USE */
/* we build a connection */
#define SOC_SYN		0x0001 /* SYN SENT - CONNECTION REQUESTED */
#define SOC_CONN	0x0002 /* CONNECTED */
/* we get a connection */
#define SOC_GOTREQ	0x0001 /* CONN REQUEST */
#define SOC_CONN	0x0002 /* CONNECTED */
/* close needed */
#define SOC_ERROR	0x0003 /* ERROR DISCOVERED */

/* socket encryption */
#define SE_NOENC	0x0000 /* NO ENCRYPTION ON THE SOCKET */
#define SE_ENCREC	0x0001 /* ENCRYPTION RECEIVED */
#define SE_KCE		0x0002 /* WAITS FOR KCE ANSWER */
#define SE_ENC		0x0003 /* SOCKET IS ENCRYPTED */
#define SE_REFUSE	0x0004 /* REFUSE ENCRYPTION AFTER FIRST DATA */

/* socket error flags */
#define SERR_OK		0x0000 /* OK */
#define SERR_REFUSED	0x0002 /* CONNECTION REFUSED */
#define SERR_TIMEOUT	0x0003 /* CONNECTION TIMED OUT */
#define SERR_TERMINATED 0x0004 /* CONNECTION TERMINATED */
#define SERR_UNKNOWN	0x0005 /* HOST UNKNOWN */

/* queue definitions */

#define Q_NEXT		0x0000 /* flush next entry */
#define Q_FORCED	0x0001 /* flush next entry, dont care about timers */

#define SOC_TIMEOUT	20     /* 20 seconds to a timeouted connecting socket */

/* psypipe sendq description */

struct sendqt {
    struct sendqt *next;
    char *data;
    int delay;
};

/* psypipe socket description */

struct psockett {
  int type;
  int flag;
  int nowfds;
  int syssock; /* number of the system socket */
  int relaysock; /* number of the to socket */    
  int encryption;
  char incrkey[64];
  char outcrkey[64];
  char userline[1024];
  char nickline[1024];
  char passline[1024];
  char source[16];
  int keydelay;
  int sport;
  int adone;
  char dest[16];
  int dport;
  char since[20];
  char *publickey; /* Pointer to the versa peers public key */
  int (*constructor)(int); /* when socket needs to be setup -> NOUSE */
  int (*constructed)(int); /* when socket was constructed */
  int (*errorhandler)(int,int); /* when an error was encountered */
  int (*handler)(int); /* the handler when socket receives data */
  int (*destructor)(int); /* the handler when the socket is closed */    
  char *commbuf; /* communication buffer */
  int bytesread; /* current number of bytes stored */
  unsigned long bytesin;
  unsigned long bytesout;
  int param; /* the parameter */
  unsigned long delay;    
  struct sendqt *sendq;
  int entrys; /* number of entrys in the sendq .. we flush, if more than 40 are entered */
};

/* The socket Nodes */

struct socketnodes {
  struct psockett *sock;
  struct socketnodes *next;
};

#ifndef P_MAIN

/* The mother of all sockets */

extern struct socketnodes *socketnode;

/* The current socket */

extern struct socketnodes *currentsocket;

extern int listenport;
extern int listensocket;

/* main communication buffer */

extern char ircbuf[8192]; 

extern char tohost[200];
extern int toport;

extern int delayinc;

#endif

#ifndef P_HASH
int bound(int sockit);
#endif

#ifndef P_PEER
int checknewlistener(int dummy);
void killed();
void errored();
int createlistener(int listenport);
#endif

#ifndef P_SOCKET
extern struct socketnodes *previous;
struct socketnodes *getpsocketbysock(int syssock);
int createsocket(int syssock,int type, int index,int(*constructor)(int),int(*constructed)(int),int(*errorhandler)(int,int),int(*handler)(int),int(*destructor)(int));
int killsocket(int syssock);
int connectto(int socket,char *host, int port, char *vhost);
int flushsendq(int socket, int forced);
int addq(int socket, char *data, int sqdelay);
extern int urgent;
int writesock(int socket, char *data);
int writesock_URGENT(int socket, char *data);
int writesock_DELAY(int socket, char *data, int delay);
int receivesock(struct psockett *sock);
int socketdriver();
#endif

#ifdef SUN
int xsnprintf(char *buf,int n,char *format,...);
#define snprintf xsnprintf
#endif

/* idea definitions */

extern char * IDEA_stringencrypt(unsigned char *input, unsigned char *key);
extern char * IDEA_stringdecrypt(unsigned char *input, unsigned char *key);

/* blowfish definitions */

extern char * BLOW_stringencrypt(unsigned char *input, unsigned char *key);


extern char * BLOW_stringdecrypt(unsigned char *input, unsigned char *key);

#define pcontext

unsigned long *pmalloc(unsigned long size);