/************************************************************************
 *   psybnc2.1, src/p_parse.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_parse.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_PARSE

#include <p_global.h>

/* parsing irc to different buffers */

int generalparse ()
{
   char *p1;
   char *p2;
   int stleng;
   char secbuf[8191];
   ircserver = 0;
   snprintf(secbuf,sizeof(secbuf),"%s\n",ircbuf);
   memset(irchost,0x0,sizeof(irchost));
   memset(ircnick,0x0,sizeof(ircnick));
   memset(ircfrom,0x0,sizeof(ircfrom));
   memset(ircto,0x0,sizeof(ircto));
   memset(irccommand,0x0,sizeof(irccommand));
   memset(irccontent,0x0,sizeof(irccontent));
   p1 = secbuf;
   if (p1 == NULL) { return; }
   if (secbuf[0] == ':') { /* from server */
      ircserver = 1;
      p1++;
      p2=strchr(secbuf, ' ');
      if (p2 == NULL) {return;}
      stleng = p2 - p1;
      secbuf[stleng+1] = 0;
      snprintf(ircfrom,sizeof(ircfrom),"%s",nobreak(p1));
      p2++;
      snprintf(secbuf,sizeof(secbuf),"%s",p2);
      p1 = secbuf;
      p2=strchr(p1,' ');
      if (p2 == NULL) { return; }
      stleng = p2 - p1;
      secbuf[stleng]=0;
      snprintf(irccommand,sizeof(irccommand),"%s",nobreak(p1));
      p2++;
      snprintf(secbuf,sizeof(secbuf),"%s",p2);
      p1 = secbuf;
      if (*p1 == ':') p1++;
      p2=strchr(secbuf,' ');
      if (p2 == NULL) { snprintf(ircto,sizeof(ircto),"%s",nobreak(p1)); return;}
      stleng = p2 - p1;
      secbuf[stleng] = 0;
      snprintf(ircto,sizeof(ircto),"%s",nobreak(p1));
      p2++;
      if (*p2 == ':') { 
         p2++;
      } else {
         p1 = strchr(p2,':');
         if (p1 != NULL) { p1++; p2=p1; }	
      }
      snprintf(irccontent,sizeof(irccontent),"%s",nobreak(p2));
   } else { /* from client */
      p2=strchr(secbuf,' ');
      if (p2 == NULL) {snprintf(irccommand,sizeof(irccommand),"%s",nobreak(secbuf));return;}
      stleng = p2 - p1;
      secbuf[stleng] = 0;
      snprintf(irccommand,sizeof(irccommand),"%s",nobreak(p1));
      p2++;
      snprintf(secbuf,sizeof(secbuf),"%s",p2);
      p1 = secbuf;
      p2=strchr(p1,':');
      if (p2 == NULL) {snprintf(irccontent,sizeof(irccontent),"%s",nobreak(p1)); return; }
      stleng = p2 - p1;
      p2--;
      secbuf[stleng]=0;
      snprintf(ircto,sizeof(ircto),"%s",nobreak(p1));
      p2++;
      if (*p2 = ':') { p2++;}
      snprintf(irccontent,sizeof(irccontent),"%s",nobreak(p2));
   }
   return 0x0;
}

/* final parse of from user/host/nick */

int parse ()
{
    char *p1;
    char *p2;
    char buf[400];
    int stlen;
    generalparse();
    if (strlen(ircfrom) > 0) {
       p1 = ircfrom;
       p2 = strchr(ircfrom,'!');
       if (p2 != NULL) {
	  stlen = p2 - p1;
	  stlen++;
	  if(stlen>sizeof(ircnick)) stlen=sizeof(ircnick);
	  snprintf(ircnick,stlen,"%s",p1);
       }
       p1 = ircfrom;
       p2 = strchr(ircfrom,'@');
       if (p2 != NULL) {
          stlen = p2 - p1;
	  stlen = strlen(ircfrom) - stlen;
	  p2++;
	  if(stlen>sizeof(irchost)) stlen=sizeof(irchost);
	  snprintf(irchost,stlen,"%s",p2);
       }
    }
    ucase(irccommand);
    return 0x0;
}

/* boolean result, if ircommand is equal to given param, will be removed */

int ifcommand(char *cmd)
{
    if (*irccommand==0) return 0x0;
    if (cmd==NULL) return 0x0;
    if (strlen(cmd) == strlen(irccommand)) {
       if (strstr(irccommand,cmd)) {
          return 0x1;
       }
    }
    return 0x0;
}

