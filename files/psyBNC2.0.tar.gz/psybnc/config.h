/* the psybnc-configuration file */

/* support encryption */

#define CRYPT

/* encryption type: blowfish */

#define BLOWFISH

/* support translation */

#define TRANSLATE

/* use the partychannel instead of $$ */

#define PARTYCHANNEL

/* support proxys (wingates, socks, webproxys) */

#define PROXYS

/* allow trafficlogging */

#define TRAFFICLOG

