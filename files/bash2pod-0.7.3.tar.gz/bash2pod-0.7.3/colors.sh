#!/bin/bash

colors () {
 normal="[0m"
 bold="[1m"
 underline="[4m"
 blink="[5m"
 reverse="[7m"
 invisible="[8m"

 black="[0;30m"
 red="[0;31m"
 green="[0;32m"
 yellow="[0;33m"
 blue="[0;34m"
 magenta="[0;35m"
 cyan="[0;36m"
 white="[0;37m"

 highblack="[1;30m"
 highred="[1;31m"
 highgreen="[1;32m"
 highyellow="[1;33m"
 highblue="[1;34m"
 highmagenta="[1;35m"
 highcyan="[1;36m"
 highwhite="[1;37m"

 bgblack="[40m"
 bgred="[41m"
 bggreen="[42m"
 bgyellow="[43m"
 bgblue="[44m"
 bgmagenta="[45m"
 bgcyan="[46m"
 bgwhite="[47m"
}

text="col"

for atrib in 0 1 4 7; do
  for highlow in 0 1; do
    for fgcolor in 0 30 31 32 33 34 35 36 37; do
      echo -ne "\033[${atrib};${highlow};${fgcolor}m${text}\033[0m "
	for bgcolor in 0 40 41 42 43 44 45 46 47; do
	 echo -ne "\033[${atrib};${bgcolor}m${text}\033[0m "
	done
    done
  done
done
