// blah blah black sheep

#ifndef __SI_H_
#define __SI_H_

#define FAKEMSG "Don't fuck with meh DLL plz thx admin!"
#define VERSION "0.0.2.13"

#define INTEL_P2_NORMAL "Pentium II"
#define INTEL_P2_CELERON "Celeron"
#define INTEL_P2_XEON "Pentium II Xeon"
#define INTEL_P3_NORMAL "Pentium III"
#define INTEL_P3_CELERON "Celeron"
#define INTEL_P3_XEON "Pentium III Xeon"
#define INTEL_P1_NORMAL "Pentium"
#define INTEL_P1_PRO "Pentium Pro"
#define AMD_K5 "K5"
#define AMD_K6 "K6"
#define AMD_K6_2 "K6/2"
#define AMD_K6_3 "K6/3"
#define AMD_K6_3PLUS "K6/3+"
#define AMD_K7 "Athlon K7"

class CSysInfo
{
	public:
	// Functions
	CSysInfo();
	~CSysInfo();
	void UpdateUptime();
	void UpdateCPU();
	void UpdateOSInfo();
	void UpdateMemInfo();
	void UpdateVersion();
	// Variables
	char pstrUptime[100];
	char pstrCPU[100];
	char pstrOSInfo[100];
	char pstrMemInfo[100];
	char pstrVersion[100];
};

// *************************************************
//                Other functions
// *************************************************

inline unsigned __int64 theCycleCount(void)
{  
    _asm    _emit 0x0F
    _asm    _emit 0x31
}

class CTimer
{
    unsigned __int64  m_start;
public:
    unsigned __int64  m_overhead;

    CTimer(void)
    {
        m_overhead = 0;
        Start();              /// we get the start cycle
        m_overhead = Stop();  // then we get the stop cycle catching the overhead time
    }

    void Start(void)
    {
        m_start = theCycleCount();
    }

    unsigned __int64 Stop(void)
    {
	/// with the stop cycle we remove the overhead's time
        return theCycleCount()-m_start-m_overhead;
    }
};

void GetProcessorType(char *proctext);
void GetProcessorVendor(char *vid);
int GetProcessorExtra(void);

#endif