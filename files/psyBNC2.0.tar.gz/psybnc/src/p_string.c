/************************************************************************
 *   psybnc2.1, src/p_string.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_string.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_STRING

#include <p_global.h>

/* ucase */

int ucase (char *inc)
{
   char *po;
   for (po = inc;*po;po++) *po = toupper( *po );
   return 0x0;
}

/* right trimming (no spaces on the right side) */

char *rtrim(char *totrim)
{
    int smlen;
    char *pnt;
    pnt = totrim;
    smlen = strlen(totrim);
    if (smlen>4095) smlen = 4095;
    pnt=pnt+smlen;
    while (*pnt == ' ' || *pnt== 0x0) { *pnt=0x0; pnt--; }
    return totrim;
}

/* replaces given character with another character */

int replace(char *rps,char whatc, char toc)
{
   char *p1;    
   p1=strchr(rps,whatc);
   while (p1) {
      *p1=toc;
      p1++;
      p1=strchr(p1,whatc);
   }
}

char nbr[8192];

/* this routine filters breaks out of a ircstring */

char *nobreak(char *tobreak)
{
    int smlen;
    char *pnt;
    pnt=strchr(tobreak,'\r');
    if(pnt==NULL) pnt=strchr(tobreak,'\n');
    if (pnt != NULL) {
       smlen = pnt-tobreak;
       smlen++;
       if (smlen > 8191) {smlen=8191;}
       snprintf(nbr,smlen,"%s",tobreak);
       pnt = nbr;
    } else {
      pnt = tobreak;
    }
    return rtrim(pnt);
}


/* random string */

const char *randstring(int length)
{
    char *po;
    int i;
    po=rbuf;
    if (length >100) length = 100;
    for(i=0;i<length;i++) { *po=(char)(0x61+(rand()&15)); po++; }
    *po=0x0;
    po=rbuf;
    return po;
}

/* string add with memory mapping */

char *strmcat(char *first,char *second)
{
    char *n;
    pcontext;
    n=(char *)pmalloc(strlen(first)+strlen(second)+2);
    strcpy(n,first);
    strcat(n,second);
    pcontext;
    free(first);
    pcontext;
    return n;
}

/* stringarray - support 
 * added for saving the lists to memory */

struct stringarray *addstring(char *toadd, struct stringarray *ltm)
{
    struct stringarray *th;
    if (ltm==NULL) {
	ltm=(struct stringarray *) pmalloc(sizeof(struct stringarray));
	ltm->next=NULL;
	ltm->entry=NULL;
    }
    th=ltm;
    first=th;
    while (th->entry!=NULL) 
    {
	if (th->next==NULL) {
	    th->next=(struct stringarray *) pmalloc(sizeof(struct stringarray));
	    th->next->entry=NULL;
	    th->next->next=NULL;
	}
        th=th->next;
    }
    th->entry=(char *) pmalloc(strlen(toadd)+3);
    snprintf(th->entry,strlen(toadd)+1,"%s%c",toadd,0);
    return first; /* returning parent node */
}

char vbuf[650];

char *getstring(int entry, struct stringarray *ltm)
{
    int cnt;
    struct stringarray *th;
    char *tt;
    th=ltm;
    cnt=0;
    while (1)
    {
	if (th==NULL) return NULL;
	if (cnt==entry) {
	    if (th->entry==NULL) return NULL;
	    memset(vbuf,0x0,sizeof(vbuf));
	    snprintf(vbuf,sizeof(vbuf),"%s",th->entry);
	    tt=vbuf;
	    return tt;
	}
	th=th->next;
	cnt++;	
    }    
}

struct stringarray *removestring(int entry, struct stringarray *ltm)
{
    int cnt;
    struct stringarray *th;
    struct stringarray *lastth;
    th=ltm;
    lastth=NULL;
    cnt=0;
    while (th!=NULL)
    {
	if (cnt==entry) {
	    if (th==ltm) {
		first=th->next;
		if (th->entry!=NULL) free(th->entry);
		th->entry=NULL;
		free(th);
		return first;
	    } else {
		lastth->next=th->next;
		if(th->entry!=NULL) free(th->entry);
		th->entry=NULL;
		free(th);
		first=ltm;
		return first;
	    }
	} 
	lastth=th;
	th=th->next;
	cnt++;	
    }
    first=ltm;
    return first;
}
/* read all lines from a file to a stringarray */

struct stringarray *loadlist(char *afile,struct stringarray *th)
{
    FILE *handle;
    char buf[4096];
    char buf2[4096];
    if ((handle=fopen(afile,"r"))==NULL) return 0x0;
    first=th;
    while(fgets(buf,sizeof(buf),handle)) {
	snprintf(buf2,sizeof(buf2),"%s",nobreak(buf));
	first=addstring(buf2,first);
    }
    fclose(handle);
    return first;
}


/* write a line, maybe also dupes to a filelist */

struct stringarray *writelist(char *host, char *param, char *afile,struct stringarray *th)
{
    FILE *handle;
    char buf[8192];
    handle = fopen(afile,"a");
    snprintf(buf,sizeof(buf),"%s:%s\n",host,param);
    fprintf(handle,buf);
    fclose(handle);
    snprintf(buf,sizeof(buf),"%s:%s",host,param);
    first=addstring(buf,th);
    return first;
}

/* erase a matching entry from a file */

struct stringarray *eraselist(int entry, char *afile,struct stringarray *th)
{
    FILE *infile;
    FILE *tmp;
    struct stringarray *ith;
    char fbuf[40];
    char buf[8192];
    int counter;
    counter=0;
    first=removestring(entry,th);
    snprintf(fbuf,sizeof(fbuf),"%s.tmp",afile);
    if ((infile = fopen(afile,"r")) == NULL) {
	return first;
    }
    if ((tmp = fopen(fbuf,"w")) == NULL) {
	fclose(infile);
	return first;
    }
    while (fgets(buf,sizeof(buf),infile))
    {
	if (counter != entry) {
	   fprintf(tmp,buf);
	}
	counter++;
    }
    fclose(infile);
    fclose(tmp);
    rename(fbuf,afile);
    return first;
}

/* list the file */

int liststrings(struct stringarray *th, int usern)
{
    char buf[650];
    char ebuf[650];
    char sbuf[650];
    char gbuf[650];
    char *pt;
    char *pt2;
    int counter;
    int userp;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    counter=0;
    while (1)
    {
	pt=getstring(counter,th);
	if (pt==NULL) return 0x0;
	pt2=strchr(pt,':');
	if (pt2!=NULL)
	{
	    *pt2=0;
	    pt2++;
	    if (*pt2=='+')
		pt2=decryptit(pt2);
	    snprintf(buf,sizeof(buf),"%s:%s",pt,pt2);
	} else
	    snprintf(buf,sizeof(buf),"%s",pt);	
dop:
	snprintf(ebuf,sizeof(ebuf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Entry #%d: %s",user(userp)->nick,counter,buf);
	counter++;
	writesock(user(usern)->insock,ebuf);
    }
}

char ibuf[650];

/* check an entry */

int checkstrings(struct stringarray *th)
{
    char *po;
    char *pt;
    char *pc;
    int sze;
    char bc='-';
    char bca=')';
    int counter;
    int match;
    memset(ehost,0x0,sizeof(ehost));
    memset(eparm,0x0,sizeof(eparm));
    memset(echan,0x0,sizeof(echan));
    counter=0;
    while (1)
    {
	pt=getstring(counter,th);
	if (pt==NULL) return 0;
	po=strchr(pt,':');
	if (po != NULL) {
	    *po=0;
	    po++;pc=NULL;
	    if (*po=='+') {
		po=decryptit(po);
	    }
	    if (*po=='#') {
	       pc=strchr(po,' ');
	       if (pc != NULL) {
		  *pc=0;
		  ucase(po);
		  snprintf(echan,sizeof(echan),"%s",nobreak(po));
	          po=pc;
		  po++;
	       } else {
		  ucase(po);
		  pc=po;
		  snprintf(echan,sizeof(echan),"%s",nobreak(po));
		  po=NULL;
	       }
	    }
	    if (pc==NULL) memset(echan,0x0,sizeof(echan));
	    if (po==NULL) {
	       memset(eparm,0x0,sizeof(eparm));
	    } else {
	       snprintf(eparm,sizeof(eparm),"%s",nobreak(po));
	    }
	    snprintf(ehost,sizeof(ehost),"%s",nobreak(pt));
	    match=1;
	    if (pc) {
	       ucase(ircto);
	       if (strlen(ircto)!=strlen(echan)) {
	           match =0;
	       } else
	       if (strstr(ircto,echan)==NULL) {
	           match =0;
	       }	
	    }
	    if (match==1) {
	       if (*ehost==bc || *ehost==bca) return 1; /* bot */
 	       if (wild_match(ehost,ircfrom)) {
		   return 1;
	       }
	    }
	}
	counter++;
    }
    return 0;
}

char *getchankey(int usern, char *chan)
{
    struct stringarray *lkm;
    char buf[200];
    char *pt;
    lkm=user(usern)->keys;
    while(lkm!=NULL)
    {
	snprintf(buf,sizeof(buf),":%s",rtrim(chan));
	ucase(buf);
	pt=strstr(lkm->entry,buf);
	if(pt!=NULL)
	{
	    *pt=0;
	    snprintf(ibuf,sizeof(ibuf),"%s",lkm->entry);
	    *pt=':';
	    pt=ibuf;
	    return pt;
	}
	lkm=lkm->next;
    }
    return NULL;
}
