/************************************************************************
 *   psypipe, src/psypipe.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *	part of	    	      th3 Co0l laMeRz
 *		 .--------..-----.  .---.---. .--. .-.----.
 *		 ||.____  |   ___| ||   |__  ||   \||   __/
 *		 |||__//  |  / \\ Y/   / LL| ||    Y|  /
 *		 ||  .___/\  \  \\    /|   ./|| |\  | | II
 *		 ||  |    ||  |  ||  ||| __ \|| ||| | | 
 *		 ||  |___//  /   ||  ||| LL| || ||| |  \___
 *		 |L_/ \_____/    |L__||L___./|L_||L_|\____/
 *		 |	  written by psychoid/tCl	 |
 *		 !	psychoid bouncer Version 2.1	 !	
 *		 :         				 :
 *		 .	  			 	 .
 *		                                         .
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: psypipe.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif


#define P_MAIN

#include <p_global.h>
#include <p_data.h>

int slice=0;

/* main bounce-loop */

int bncmain(void) {
   while(1)
   {
       socketdriver();	
   }
   return 0x0; /* i wonder how often we get here */
}

/* printing the banner */

int printbanner(void)
{
   fprintf(stdout,"psypipe 2.1.\n");
   return 0x0;
}

/* installation loop */

int
main (int argc, char **argv)
{
  int rc,pid;
  char buf[200];
  FILE *pidfile;
  printbanner();
  if(argc<4)
  {
      printf("Usage: %s <localport> <dest.host> <dest.port>\n",argv[0]);
      exit(0x0);
  }    
  listenport = atoi(argv[1]);
  snprintf(tohost,sizeof(tohost),"%s",argv[2]);
  toport = atoi(argv[3]);
  /* creating the socket-root */
  socketnode=(struct socketnodes *) pmalloc(sizeof(struct socketnodes));
  socketnode->sock=NULL;
  socketnode->next=NULL;
  srand(time(NULL));
  /* creating the demon socket */
  rc = createlistener(listenport);
  if (rc == -1) {
    printf("Cannot create listening port .. aborting\n");
    exit (0x0);
  }
  /* creating background */
  pid = fork();
  if (pid < 0) {
      srand(time(NULL));
  }
  if (pid != 0) {
     pidfile = fopen("psbnc.pid","w");
     printf("Forked to the background (PID %d)\n",pid);
     snprintf(buf,sizeof(buf),"psypipe started (PID :%d)",pid);
     fprintf( pidfile,"%d\n",pid);
     exit (0x0);
  }  
  bncmain();
}

