/*
moo.dll component file 
[myras.h - header for system information class]
Copyright (C) 2000 Mark Hutton - mailto:mark@influenced.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "DllLoad.h"

#define RAS_MaxDeviceType     16
#define RAS_MaxPhoneNumber    128
#define RAS_MaxIpAddress      15
#define RAS_MaxIpxAddress     21
#define RAS_MaxEntryName      256
#define RAS_MaxDeviceName     128
#define RAS_MaxCallbackNumber RAS_MaxPhoneNumber
#define RAS_MaxAreaCode       10
#define RAS_MaxPadType        32
#define RAS_MaxX25Address     200
#define RAS_MaxFacilities     200
#define RAS_MaxUserData       200
#define RAS_MaxReplyMessage   1024

DECLARE_HANDLE( HRASCONN );
#define LPHRASCONN HRASCONN*

typedef struct _RAS_STATS
{
    DWORD   dwSize;
    DWORD   dwBytesXmited;
    DWORD   dwBytesRcved;
    DWORD   dwFramesXmited;
    DWORD   dwFramesRcved;
    DWORD   dwCrcErr;
    DWORD   dwTimeoutErr;
    DWORD   dwAlignmentErr;
    DWORD   dwHardwareOverrunErr;
    DWORD   dwFramingErr;
    DWORD   dwBufferOverrunErr;
    DWORD   dwCompressionRatioIn;
    DWORD   dwCompressionRatioOut;
    DWORD   dwBps;
    DWORD   dwConnectDuration;

} RAS_STATS, *PRAS_STATS;

#define RASCONN98 struct tagRASCONN98
RASCONN98
{
    DWORD    dwSize;
    HRASCONN hrasconn;
    CHAR     szEntryName[ RAS_MaxEntryName + 1 ];
    CHAR     szDeviceType[ RAS_MaxDeviceType + 1 ];
    CHAR     szDeviceName[ RAS_MaxDeviceName + 1 ];
};

#define RASCONN2K struct tagRASCONN2K
RASCONN2K
{
    DWORD    dwSize;
    HRASCONN hrasconn;
    CHAR     szEntryName[ RAS_MaxEntryName + 1 ];
    CHAR     szDeviceType[ RAS_MaxDeviceType + 1 ];
    CHAR     szDeviceName[ RAS_MaxDeviceName + 1 ];
    CHAR     szPhonebook [ MAX_PATH ];
    DWORD    dwSubEntry;
    GUID     guidEntry;
};

#define LPRASCONN98 RASCONN98*
#define LPRASCONN2K RASCONN2K*

typedef DWORD (APIENTRY *TFRasEnumConnections98)( LPRASCONN98, LPDWORD, LPDWORD );
typedef DWORD (APIENTRY *TFRasEnumConnections2K)( LPRASCONN2K, LPDWORD, LPDWORD );
typedef DWORD (APIENTRY *TFRasGetConnectionStatistics)( HRASCONN, PRAS_STATS );

class TRasModule : public TDllModule {
private:
    TFRasEnumConnections98 FRasEnumConnections98;
    TFRasEnumConnections2K FRasEnumConnections2K;
    TFRasGetConnectionStatistics FRasGetConnectionStatistics;

private:
    void initAll(void);

public:
    TRasModule();
    virtual ~TRasModule();

    virtual BOOL Create(void);
    virtual void Destroy(void);
    
	DWORD RasEnumConnections98( LPRASCONN98, LPDWORD, LPDWORD );
	DWORD RasEnumConnections2K( LPRASCONN2K, LPDWORD, LPDWORD );
	DWORD RasGetConnectionStatistics( HRASCONN, PRAS_STATS ); 
};