/***************************************************************************
 *   copyright           : (C) 2002 by Hendrik Sattler                     *
 *   mail                : post@hendrik-sattler.de                         *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "depincludes.h"
#include "common.h"
#include "charsets.h"
#include "helpers.h"
#include "pbmaskgsm.h"
#include <errno.h>
#include <string.h>
#include <stdlib.h>

void pbook_s35(int action, char* file, char* phonebook){
  char at_command[11];
  char* ack;
  char* temp;

  memset(at_command,0,sizeof(at_command));
	
  //selecting phonebook
  temp=get_vendor();
  if (temp!=NULL && !strcmp(temp,"SIEMENS")) {
    new_at_command(at_command,"^SPBS=");
  } else {
    new_at_command(at_command,"+CPBS=");
  }
  mem_realloc(temp,0);
  add_at_command(at_command,phonebook);
  ack=tty_write_read(at_command);
  if (strcmp(ack,"OK")) {
    errexit("%s, cannot select phonebook %s\n",ack,phonebook);
  }
  mem_realloc(ack,0);

  switch (action) {
  default:
    errexit("You must specify exactly one operation.\n");
    break;
		
  case 2: //deleting
    delete_pb_s35(phonebook);
    break;
	
  case 4: //sending
    send_pb_s35(file,phonebook);
    break;
		
  case 8: //getting
    get_pb_s35(file,phonebook);
    break;
  }
}

void delete_pb_s35 (char* phonebook) {
  char at_command[BUFSIZ];
  char* ausgabe;
  char* ack;
  int i,first_entry,last_entry;

  memset(at_command,0,sizeof(at_command));

  if ((!strcasecmp(phonebook,"DC"))
      || (!strcasecmp(phonebook,"MD"))
      || (!strcasecmp(phonebook,"LD"))) {
    new_at_command(at_command,"^SDLD");
    ack=tty_write_read(at_command);
    if (!strcmp(ack,"OK")) {
      myprintf(0,"%s deleted.\n",phonebook);
    } else {
      errexit("\n%s\nAn ERROR occured. Possible data corruption!\n",ack);
    }
    mem_realloc(ack,0);
  } else {
    new_at_command(at_command,"+CPBW=?");
    ausgabe=tty_write_read(at_command);
    if (!strncmp(ausgabe,"+CME ERROR: ",12)) {
      errexit("Error deleting phonebook %s: %s\n",phonebook,ausgabe+12);
    } else {
      mem_realloc(tty_read(at_command),0);
    }
    first_entry=atoi((char *)strtok(ausgabe+7,"(-),"));
    last_entry=atoi((char *)strtok(NULL,"(-),"));
    mem_realloc(ausgabe,0);
    myprintf(0,"Preparing to delete %d entries\n",last_entry-first_entry+1);
    myprintf(0,"Deleting: ");
    for (i=first_entry;i<=last_entry;i++) {
      new_at_command(at_command,"+CPBW=");
      add_at_command(at_command,"%d",i);
      ack=tty_write_read(at_command);
      if (!strcmp(ack,"OK")) {
	myprintf(0,"%d ",i);
	mem_realloc(ack,0);
      } else {
	errexit("\n%s\nAn ERROR occured. Possible data corruption!\n",ack);
      }				
    }
    myprintf(0,"\n");
  }
}

void send_pb_s35 (char* file, char* phonebook) {
  char at_command[BUFSIZ];
  char* ausgabe;
  char temp[BUFSIZ];
  unsigned char *token=NULL;
  unsigned char buffer;
  int myfd;
  int i;
  int first_entry;
  int current_entry;
  int last_entry;
  int nr_length;
  int text_length;
  int bytecount;
  wchar_t* wide_str;
  char* buf_str;
  size_t entry_len;
  int  unicode=false;

  if (set_charset("UCS2")) {
    unicode=true;
  }

  memset(at_command,0,sizeof(at_command));
  memset(temp,0,sizeof(temp));

  new_at_command(at_command,"+CPBW=?");
  ausgabe=tty_write_read(at_command);
  if (!strncmp(ausgabe,"+CME ERROR: ",12)) {
    errexit("Error writing to phonebook %s: %s\n",phonebook,ausgabe+12);
  }
  mem_realloc(tty_read(at_command),0);
  first_entry=atoi((char *)strtok(ausgabe+7,"(-),"));
  last_entry=atoi((char *)strtok(NULL,"(-),"));
  nr_length=atoi((char *)strtok(NULL,"(-),"));
  strtok(NULL,","); //not needed (we know the type numbers)
  text_length=atoi((char *)strtok(NULL,"(-),"));
  mem_realloc(ausgabe,0);

  myfd=open_myFile_ro(file);

  myprintf(0,"Preparing to send %d entries\n",last_entry);
  myprintf(0,"Sending: ");
  for (i=first_entry;i<=last_entry;i++) {
    //reading the entries from the file
    memset(temp,0,sizeof(temp));
    bytecount=0;
    do {
      if (read(myfd,&buffer,1)!=1) {
	close(myfd);
	if (bytecount==0) {
	  myprintf(0,"\nIncomplete phonebook sent.\n");
	  return;
	} else {
	  errexit("\nError reading %s or unexpected end of file.\n",file);
	}
      }
      if (buffer!='\n') {
	temp[bytecount]=buffer;
      }
      if (bytecount+1<sizeof(temp)) {
	bytecount++;
      } else {
	close(myfd);
	errexit("\nBuffer overflow, aborting\n");
      }
    } while (buffer!='\n');
	
    //checking string
    ausgabe=str_dup(temp);
    if (atoi(ausgabe)==0 || atoi(ausgabe)>last_entry) {//the line must begin with a valid number
      close(myfd);
      errexit("\nError, invalid entry.\n");
    }
    if (strstr(ausgabe,",\"")==NULL) {
      close(myfd);
      errexit("\nError, invalid entry.\n");
    } else {
      token=strstr(ausgabe,",\"")+2;
    }
    if (strstr(ausgabe,"\",\"")==NULL) {
      close(myfd);
      errexit("\nError, invalid entry.\n");
    } else {
      token=strstr(ausgabe,"\",\"")+3;
    }
    buffer=token[strlen(token)-1];
    if (buffer!='"') {
      close(myfd);
      errexit("\nError, invalid entry.\n");
    }
    mem_realloc(ausgabe,0);
    //end of checking string
				
    new_at_command(at_command,"+CPBW=");
    current_entry=atoi(temp);
    strtok(temp,",");
    add_at_command(at_command,"%d",current_entry);
    //analyse token 2
    token=(char *)strtok(NULL,",");
    if (strlen(token)>nr_length+2) {
      close(myfd);
      errexit("\nError, number of entry %d is too long (max. %d)\nAlready sent entries are o.k.\n",i,nr_length);
    } else if (2<(strlen(token)) && (strlen(token)<=nr_length+2)) {
      //add token 2
      add_at_command(at_command,",");
      add_at_command(at_command,token);
      //add token 3
      buffer=token[1];
      if (buffer=='+') {
	add_at_command(at_command,",145,");
      } else {
	add_at_command(at_command,",129,");
      }
      //convert, test and add token 4
      token=(char *)strtok(NULL,"");
      if (*token=='"') {
	++token;
      }
      if (token[strlen(token)-1]=='"') {
	token[strlen(token)-1]=0;
      }
      entry_len=strlen(token);
      wide_str=convert_to_internal(nl_langinfo(CODESET),token,entry_len);
      if (unicode) {
        token=convert_to_ucs2(wide_str); 
	}
      else {
        token=convert_to_gsm(wide_str); 
	}
      mem_realloc(wide_str,0);
      if (entry_len>text_length+2) {
	close(myfd);
	errexit("\nError, text of entry %d is too long (max. %d)\nAlready sent entries are o.k.\n",i,text_length);
      }
      buf_str=pb_mask_chars(token);
      mem_realloc(token,0);
      add_at_command(at_command,"\"%s\"",buf_str);
      mem_realloc(buf_str,0);
    } else if(strlen(token)<=2) {
    }
    ausgabe=tty_write_read(at_command);
    if (!strcmp(ausgabe,"OK")) {
      mem_realloc(ausgabe,0);
      myprintf(0,"%d ",current_entry);
    } else {
      close(myfd);
      errexit("\n%s\nAn ERROR occured. Possible data corruption!\n",ausgabe);
    }
  }
  myprintf(0,"\n");
  set_charset("GSM");
  close(myfd);
}


void get_pb_index_list(char *pb, int *first_entry, int *last_entry)
{
  char *at_command;
  char *ausgabe;
  char *reply_prefix;
  int  reply_prefix_len;
  char *temp;

  if ((!strcasecmp(pb,"RD"))||(!strcasecmp(pb,"CS"))) {
  /* Get sorted pb index */
    at_command   = AT_TEST(AT_READ_SORTED_PHONE_BOOK_ENTRY);
    reply_prefix = AT_REPLY_PREFIX(AT_READ_SORTED_PHONE_BOOK_ENTRY);
  } else {
  /* Get pb index */
    at_command = AT_TEST(AT_READ_PHONE_BOOK_ENTRY);
    reply_prefix = AT_REPLY_PREFIX(AT_READ_PHONE_BOOK_ENTRY);
  }
  reply_prefix_len=strlen(reply_prefix);

  //reading available indexes
  ausgabe=tty_write_read(at_command);
  if (strstr(ausgabe,"ERROR")==NULL) {
    mem_realloc(tty_read(at_command),0);
  } else {
    errexit("Error: Could not get phonebook index list\n");
  }
  if (!strncmp(ausgabe,reply_prefix,reply_prefix_len)) {
    *first_entry=atoi((char *)strtok(ausgabe+reply_prefix_len+1,"-)"));
    if ((temp=strtok(NULL,")")) == NULL) {
      *last_entry=*first_entry;
    } else {
      *last_entry=atoi(temp);
    }
  } else {
    errexit("Error: Invalid phonebook index list\n");
  }
  mem_realloc(ausgabe,0);
}


void get_pb_s35 (char* file, char* phonebook) {
  char at_command[BUFSIZ];
  char* ausgabe;
  char temp[BUFSIZ];
  unsigned char *token=NULL;
  int myfd=-1,
    i,
    first_entry=-1,
    current_entry=-1,
    last_entry=-1,
    next_entry=-1;
  wchar_t* wide_str;
  int unicode=false;
  char *command;
  char *reply_prefix;
  int  reply_prefix_len;

  ausgabe = NULL;

  if (set_charset("UCS2")) {
    unicode=true;
  }

  memset(at_command,0,sizeof(at_command));
  memset(temp,0,sizeof(temp));

  //reading available indexes
  get_pb_index_list(phonebook, &first_entry, &last_entry);
  if (first_entry==0 && last_entry==0) {
    //emty phonebook
    myprintf(0,"Nothing to get.\n");
    return;
  }
					
  //accessing file
  if (strlen(file)) {
    myfd=open_myFile_rw(file);
  }
  //getting the data
  myprintf(0,"Receiving:");
  if (!strcmp(file,"-")) {
    myprintf(0,"\n");
  }

// number of requesting numbers
// higher means a little bit more speed
// lower helps slow phones/SIM-cards to not time out
#define delta	5

  for (next_entry=first_entry; next_entry<=last_entry; next_entry+=delta) {
    ausgabe=NULL;

    if ((!strcasecmp(phonebook,"RD"))||(!strcasecmp(phonebook,"CS"))) {
    /* Get sorted pb */
      command   = AT_WRITE(AT_READ_SORTED_PHONE_BOOK_ENTRY);
      reply_prefix = AT_REPLY_PREFIX(AT_READ_SORTED_PHONE_BOOK_ENTRY);
    } else {
    /* Get pb */
      command = AT_WRITE(AT_READ_PHONE_BOOK_ENTRY);
      reply_prefix = AT_REPLY_PREFIX(AT_READ_PHONE_BOOK_ENTRY);
    }
    reply_prefix_len=strlen(reply_prefix);

    strcpy(at_command, command);		// new_at_command
    sprintf(temp,"%d,%d",next_entry,min(next_entry+delta-1, last_entry));
    add_at_command(at_command,temp);
    ausgabe=tty_write_read(at_command);
    if (strstr(ausgabe,"ERROR")!=NULL) {
      errexit("Error on selecting phonebook\n");
    }
    current_entry=next_entry;
    //read until OK or ERROR or Invalid Index
    while (strcmp(ausgabe,"OK")
	   && strcmp(ausgabe,"ERROR")
	   && strncmp(ausgabe,"+CME ERROR",10)) {

      //use only token 1,2 and 4, write tokens 1 and 2 as-is
      //1st token
      token=(char *)strtok(ausgabe + reply_prefix_len,",");
      //anlysing token number and write all empty string to file, too
      if (atoi(token)!=current_entry) {
	for (i=current_entry;i<atoi(token);i++) {
	  sprintf(temp,"%d,\"\",\"\"\n",i);
	  if (strlen(file)) {
	    if (write(myfd,temp,strlen(temp)) == -1) {
	      close(myfd);
	      errexit("\nERROR on writing to %s: %s\n",file, strerror(errno));
	    }
	  }
	  if (strcmp(file,"-")) {
	    myprintf(0," (%d)",i);
	  }
	}
	current_entry=atoi(token);
      }
      if (strlen(file)) {
	if ((write(myfd,token,strlen(token)) == -1)
	    ||(write(myfd,",",1) == -1)){
	  close(myfd);
	  errexit("\nERROR on writing to %s: %s\n",file, strerror(errno));			
	}
      }
      if (strcmp(file,"-")) {
	myprintf(0," %s",token);
      }

      //2nd token
      token=(char *)strtok(NULL,",");
      if (strlen(file)) {
	if ((write(myfd,token,strlen(token)) == -1)
	    ||(write(myfd,",",1) == -1)){
	  close(myfd);
	  errexit("\nERROR on writing to %s: %s\n",file, strerror(errno));			
	}
      }

      //3rd token, not saved, has to be recontructed on writing to phone
      strtok(NULL,",");

      //4th token, the description string may contain , and " in GSM
      token=(char *)strtok(NULL,"\"");
      if (unicode) {
	wide_str=convert_from_ucs2(token);
      } else {
	wide_str=convert_from_gsm(token);
      }  
      //character conversion on token 4
      token=convert_from_internal(nl_langinfo(CODESET),wide_str,2);
      mem_realloc(wide_str,0);
      //write converted token 4, also write a newline to make the file readable
      if (strlen(file)) {
	if (write(myfd,"\"",1) == -1
	    || write(myfd,token,strlen(token)) == -1
	    || write(myfd,"\"\n",2) == -1) {
	  close(myfd);
	  errexit("\nERROR on writing to %s: %s\n",file, strerror(errno));
	}
      }
      mem_realloc(token,0);
				  
      //reading next entry
      mem_realloc(ausgabe,0);
      ausgabe=tty_read(at_command);
      current_entry++;
    }
    
    for (i=current_entry;i<=min(next_entry+delta-1, last_entry);i++) {
      sprintf(temp,"%d,\"\",\"\"\n",i);
      if (strlen(file)) {
	if (write(myfd,temp,strlen(temp)) == -1) {
	  close(myfd);
	  errexit("\nERROR on writing to %s: %s\n",file, strerror(errno));
	}
      }
      if (strcmp(file,"-")) {
	myprintf(0," (%d)",i);
      }
    } // while
  } // for
  myprintf(0,"\n");

  //be nice to other programs
  set_charset("GSM");

  if (ausgabe==NULL || !strcmp(ausgabe,"OK")
      /*||!strcasecmp(ausgabe,"+CME ERROR: INVALID INDEX")*/){
    myprintf(0,"Received all gettable entries\n");
  } else {
    errexit("An ERROR occured. Possible data corruption!\n");
  }
  mem_realloc(ausgabe,0);
}
