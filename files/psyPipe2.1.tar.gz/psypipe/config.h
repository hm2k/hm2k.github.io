#define CRYPT

#define BLOWFISH
