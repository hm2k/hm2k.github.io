/************************************************************************
 *   psybnc2.2.1, src/psybnc.c
 *   Copyright (C) 1999-2000 the most psychoid  and
 *                           the cool lam3rz IRC Group, IRCnet
 *			     http://www.psychoid.lam3rz.de
 *
 *            .-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-.
 *             ,----.,----.,-.  ,-.,---.,--. ,-.,----. 
 *             |  O ||  ,-' \ \/ / | o ||   \| || ,--' 
 *             |  _/ _\  \   \  /  | o< | |\   || |__  
 *             |_|  |____/   |__|  |___||_|  \_| \___| 
 *                    Version 2.2.1 (c) 1999-2000          
 *                            the most psychoid          
 *                    and  the cool lam3rz Group IRCnet  
 *                                         
 *             `-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=tCl=-'
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: psybnc.c, v 2.2.1 2000/10/02 02:02:00 psychoid Exp $";
#endif

#define P_MAIN

#include <p_global.h>
#include <p_data.h>

int slice=0;

/* alarm-loop */

int bncalarm(void)
{
    slice++;
    delayinc=1;
    if(slice==1)
	checkclients();
    else 
    if(slice==2)
        checklinks();
    else 
    if(slice==3)
    { 
	checkdccs();
#ifdef TRANSLATE
	cleartranslates();
#endif
	checkdcctimeouts();
	slice=0;
    }
    return;
}

/* main bounce-loop */

int bncmain(void) {
   unsigned long em=0;
   delayinc=1;
   while(1)
   {
       em+=socketdriver();
       if(em>=5)
       {
	   em=0;
           bncalarm();
       }
   }
   return 0x0; /* i wonder how often we get here */
}

/* printing the banner */

int printbanner(void)
{
   fprintf(stdout,".-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-.\n");
   fprintf(stdout," ,----.,----.,-.  ,-.,---.,--. ,-.,----. \n");
   fprintf(stdout," |  O ||  ,-' \\ \\/ / | o ||   \\| || ,--' \n");
   fprintf(stdout," |  _/ _\\  \\   \\  /  | o< | |\\   || |__  \n");
   fprintf(stdout," |_|  |____/   |__|  |___||_|  \\_| \\___| \n");
   fprintf(stdout,"      Version " APPVER " (c) 1999-2000\n");
   fprintf(stdout,"              the most psychoid          \n");
   fprintf(stdout,"      and  the cool lam3rz Group IRCnet  \n");
   fprintf(stdout,"                                         \n");
   fprintf(stdout,"`-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=tCl=-'\n");
   return 0x0;
}

/* installation loop */

int
main (int argc, char **argv)
{
  int rc;
  char buf[200];
  FILE *pidfile,*conffile;
  printbanner();
  if(argc==2)
  {
      snprintf(configfile,sizeof(configfile),"%s",argv[1]);
  } else {
      strcpy(configfile,"psybnc.conf");
  }
  conffile=fopen(configfile,"r");
  if(conffile==NULL)
  {
     printf("Configuration File %s not found, aborting\nRun 'make menuconfig' for creating a configuration or create the file manually.\n",conffile);
     exit (0x0);
  }
  fclose(conffile);
  printf("Configuration File: %s\n",configfile);
  readconfig();
  snprintf(logfile,sizeof(logfile),"log/psybnc.log");
  rc = getini("SYSTEM","PORT1",INIFILE);
  if (rc != 0) {
     printf("No Listenports/-hosts defined.\nRun either 'make menuconfig' to setup\nor add:\nPSYBNC.SYSTEM.PORT1=yourport\nand\nPSYBNC.SYSTEM.HOST1=*\nto the psybnc.conf\n");
     exit (0x0);
  }
  listenport = atoi(value);
  rc = getini("SYSTEM","ME",INIFILE);
  if (rc < 0) {
     memset(value,0x0,sizeof(value));       
  }
  snprintf(me,sizeof(me),"%s",value);
  rc = getini("SYSTEM","LOGFILE",INIFILE);
  if (rc < 0) {
     printf("No logfile specified, logging to log/psybnc.log\n");
     snprintf(value,sizeof(value),"log/psybnc.log");
  }
  snprintf(logfile,sizeof(logfile),"%s",value);
  oldfile(logfile);
  /* creating the socket-root */
  socketnode=(struct socketnodes *) pmalloc(sizeof(struct usernodes));
  socketnode->sock=NULL;
  socketnode->next=NULL;
  /* creating the demon socket */
  rc = createlisteners();
  if (rc == 0) {
    printf("Cannot create listening port .. aborting\n");
    exit (0x0);
  }
  /* creating background */
  pidfile = fopen("psybnc.pid","w");
  if(pidfile==NULL)
  {
      printf("Can't open pidfile. Aborting.\n");
      exit(0x0);
  }
  if(mainlog!=NULL)
  {
      fclose(mainlog);
      mainlog=NULL;
  }
  pid = fork();
  if (pid < 0) {
  
  }
  if (pid == 0) {
     rc= errorhandling();
     makesalt();
     U_CREATE=0;
#ifdef PARTYCHANNEL
     /* partychannel setup */
     strcpy(partytopic,"psyBNC-Partyline Channel");
     partyusers=NULL;
#endif
     /* creating the usernode-root */
     usernode=(struct usernodes *) pmalloc(sizeof(struct usernodes));
     usernode->uid=0;
     usernode->user=NULL;
     usernode->next=NULL;
     /* creating the newpeer-root */
     peernode=(struct peernodes *) pmalloc(sizeof(struct peernodes));
     peernode->uid=0;
     peernode->peer=NULL;
     peernode->next=NULL;
     /* creating the datalink-root */
     linknode=(struct linknodes *) pmalloc(sizeof(struct linknodes));
     linknode->uid=0;
     linknode->link=NULL;
     linknode->next=NULL;
     /* loading the users */
     loadusers();
     loadlinks();
     pcontext;
     /* loading the hostallows */
     hostallows=loadlist("PSYBNC.HOSTALLOWS",hostallows);
  }
    pcontext;
  if (pid) {
     printf("%s started (PID %d)\n",buildversion(),pid);
     log(LOG_INFO,-1,"%s started (PID :%d)",buildversion(),pid);
     fprintf( pidfile,"%d\r\n",pid);
     fclose(pidfile);
     exit (0x0);
  }  
  pcontext;
  bncmain();
}

