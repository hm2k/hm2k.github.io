#define APPNAME "psyBNC"
#define APPVER "2.1.1"
