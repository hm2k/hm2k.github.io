/************************************************************************
 *   psybnc2.1, src/p_peer.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_peer.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_PEER

#include <p_global.h>

/* check, if host is already connected */

int checkpeerhostname (char *hostname)
{
   int apeer;
   struct peernodes *th;
   pcontext;
   th=peernode;
   while (th!=NULL)
   {
       apeer=th->uid;
       if (newpeer(apeer)->state > STD_NOUSE) {
          if (strstr(newpeer(apeer)->host,hostname) != NULL ) {
	     return -1;
          }
       }
       th=th->next;
   }
   return 0;
}

/* get a free peer descriptor */

int getnewpeer ()
{
   int apeer;
   pcontext;
   apeer = 1;
   P_CREATE=1;
   while (apeer < MAX_USER) 
   {
       if (newpeer(apeer)->state == STD_NOUSE) {
	  clearpeer(apeer);    
          return apeer;
       }
       apeer++;
   }
   return -1;
}

/* erase a connected peer */

int erasepeer(int npeer)
{
    char buf[400];
    pcontext;
    snprintf(buf,sizeof(buf),"Breaking connection to host %s (%s)",newpeer(npeer)->host,newpeer(npeer)->user);
    log(buf);
    killsocket(newpeer(npeer)->insock);
    clearpeer(npeer);
    return 0x0;
}

/* linking a link (...) */

int linklink(int npeer)
{
    int lnk;
    char buf[200];
    struct socketnodes *lkm;
    pcontext;
    lnk=getlink(npeer);
    if (lnk==0) return -1;
    if (getlinkbyname(newpeer(npeer)->name)!=lnk && newpeer(npeer)->type!=NP_RELAY) return -1;
    /* hostname, name of the bouncer, and port are correct */
    pcontext;
    if (*datalink(lnk)->pass==0 && newpeer(npeer)->type!=NP_RELAY)
    {
	snprintf(datalink(lnk)->pass,sizeof(datalink(lnk)->pass),"%s",newpeer(npeer)->pass);
	writelink(lnk);
    }
    if (strlen(datalink(lnk)->pass)!=strlen(newpeer(npeer)->pass))
	return -1;
    if (strstr(datalink(lnk)->pass,newpeer(npeer)->pass)==NULL)
	return -1;
    /* password is correct */	
    if (newpeer(npeer)->type==NP_LINK) 
    {
	if (datalink(lnk)->type!=LI_ALLOW)
	{
	    return -1; /* invalid link type, only 'allowed' links get accepted */
	}
	snprintf(buf,sizeof(buf),":%s!*@%s IAM :\r\n",me,me);
	writesock(newpeer(npeer)->insock,buf);
	snprintf(buf,sizeof(buf),":*!*@* BWHO :\r\n"); /* getting the 'WHO' */
	writesock(newpeer(npeer)->insock,buf);
#ifdef PARTYCHANNEL
	snprintf(buf,sizeof(buf),":psyBNC@%s!*@%s TOPIC " PARTYCHAN " :%s\r\n",me,me,partytopic); /* getting the 'WHO' */
	writesock(newpeer(npeer)->insock,buf);
#endif
	datalink(lnk)->insock=newpeer(npeer)->insock;
	datalink(lnk)->instate=STD_CONN;
	datalink(lnk)->outsock=0;
	datalink(lnk)->outsock=0;
	clearpeer(npeer);
	lkm=getpsocketbysock(datalink(lnk)->insock);
        pcontext;
	if(lkm!=NULL)
	{
	    lkm->sock->param=lnk;
	    lkm->sock->handler=checklinkdata;
	    lkm->sock->errorhandler=checklinkerror;
	    lkm->sock->destructor=checklinkkill;
	}
	snprintf(buf,sizeof(buf),"Linked to %s",datalink(lnk)->name);
	log(buf);
	sysparty(buf);
	return 0x0; /* done, linked */
    }
    pcontext;
    if (newpeer(npeer)->type==NP_RELAY)
    {
	if(datalink(lnk)->allowrelay!=1)
	{
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE * :No Relays allowed. Good Bye.\r\n");
	    writesock(newpeer(npeer)->insock,buf);
	    return -1;
	}
	return linkrelay(npeer,lnk);
    }
}

/* linking the new peer */

int linkpeer(int npeer)
{
    int rc;
    int rc2;
    struct usernodes *th;
    struct socketnodes *lkm;
    int sck;
    char buf[200];
    char *pt;
    pcontext;
    if (nousers==1) {
       nousers = 0;
       rc = firstuser(npeer);
       pcontext;
       if(rc==-1) return -1;
       if (rc) {
	  snprintf(user(rc)->nick,sizeof(user(rc)->nick),"%s",newpeer(npeer)->nick);
	  snprintf(user(rc)->wantnick,sizeof(user(rc)->wantnick),"%s",newpeer(npeer)->nick);
	  snprintf(user(rc)->user,sizeof(user(rc)->user),"%s",newpeer(npeer)->user);
	  snprintf(user(rc)->host,sizeof(user(rc)->host),"%s",newpeer(npeer)->host);
          user(rc)->insock = newpeer(npeer)->insock;
	  user(rc)->instate = STD_CONN;
	  lkm=getpsocketbysock(user(rc)->insock);
	  pcontext;
	  if(lkm!=NULL)
	  {
	    lkm->sock->param=rc;
	    lkm->sock->handler=userinbound;
	    lkm->sock->errorhandler=userinerror;
	    lkm->sock->destructor=userinkill;
	  }
#ifdef PARTYCHANNEL
	  joinparty(rc);
#endif
	  writeuser(rc);
          clearpeer(npeer);
	  pcontext;
	  memset(nulluser,0x0,sizeof(struct usert));
	  memset(dummyuser,0x0,sizeof(struct usert));
          return 0x0;
       }
    }
    rc=checkuser(newpeer(npeer)->login);
    pcontext;
    if (rc==0x0) return -1;
    snprintf(buf,sizeof(buf),"%s%s",slt1,slt2);
    pt=BLOW_stringencrypt(buf,newpeer(npeer)->pass);
    pcontext;
    snprintf(newpeer(npeer)->pass,sizeof(newpeer(npeer)->pass),"=%s",pt);
    free(pt);
    if (strlen(newpeer(npeer)->pass) == strlen(user(rc)->pass)) {
	if (!strstr(newpeer(npeer)->pass,user(rc)->pass)) return -1;
    } else {
        return -1;
    }
    snprintf(buf,sizeof(buf),"User %s logged in.",newpeer(npeer)->login);
#ifndef PARTYCHANNEL
    sysparty(buf);	
#endif
    log(buf);	
    lkm=getpsocketbysock(newpeer(npeer)->insock);
    pcontext;
    if(lkm!=NULL)
    {
	lkm->sock->param=rc;
	lkm->sock->handler=userinbound;
	lkm->sock->errorhandler=userinerror;
	lkm->sock->destructor=userinkill;
    }
    /* authentification proceeded */
    if (user(rc)->insock > 0) {
       snprintf(buf,sizeof(buf),":psyBNC!psychiod@lam3rz.de NOTICE %s :New Connection from %s\n",user(rc)->nick,newpeer(npeer)->host);
       writesock(user(rc)->insock,buf);
       killsocket(user(rc)->insock);	
    }
#ifdef PARTYCHANNEL
    if(user(rc)->sysmsg==0)
	snprintf(buf,sizeof(buf),"User %s logged in (not on Partyline).",newpeer(npeer)->login);
#else
    if(user(rc)->sysmsg==0)
	snprintf(buf,sizeof(buf),"User %s logged in.",newpeer(npeer)->login);
#endif
    pcontext;
    th=usernode;
    while (th!=NULL)
    {
	if (th->user!=NULL)
	{
	    if (th->user->parent==rc || th->uid==rc)
	    {
		user(th->uid)->delayed=1; /* if a user is not connected, he will get an addserver message at login */
		user(th->uid)->insock = newpeer(npeer)->insock;
		snprintf(user(th->uid)->host,sizeof(user(th->uid)->host),"%s",newpeer(npeer)->host);
		snprintf(user(th->uid)->wantnick,sizeof(user(th->uid)->wantnick),"%s",newpeer(npeer)->nick);
		if (user(th->uid)->outstate == STD_CONN) {
		    user(th->uid)->instate = STD_WHOIS;
		    if (user(th->uid)->parent==0) repeatserverinit(rc);
		    if (user(th->uid)->parent == 0) {
			snprintf(buf,sizeof(buf),":%s!%s@%s NICK :%s\r\n",user(rc)->firstnick,user(rc)->login,user(rc)->host,user(rc)->nick);
		        writesock(user(rc)->insock,buf);
		    }
#ifdef PARTYCHANNEL
		    if(user(th->uid)->sysmsg==1 || th->user->parent==0)
		    {
			user(th->uid)->sysmsg=0;
			strcpy(irccontent,PARTYCHAN);
			cmdjoin(th->uid);
			user(th->uid)->sysmsg=1;
		    }
#endif
		    snprintf(buf,sizeof(buf),"WHOIS %s\r\n",user(th->uid)->nick);
		    writesock_URGENT(user(th->uid)->outsock,buf);
		    snprintf(buf,sizeof(buf),"NICK %s\r\n",user(th->uid)->wantnick);
		    writesock_URGENT(user(th->uid)->outsock,buf);
		} else {
		    user(th->uid)->instate = STD_CONN;
#ifdef PARTYCHANNEL
		    if(user(th->uid)->sysmsg==1 || th->user->parent==0)
		    {
			user(th->uid)->sysmsg=0;
			strcpy(irccontent,PARTYCHAN);
			cmdjoin(th->uid);
			user(th->uid)->sysmsg=1;
		    }
#endif
		}
	    }
	}
	th=th->next;
    }
    clearpeer(npeer);
    return 0x0;
}

/* if an new peer gets killed */

int killoldlistener(int npeer)
{
    char buf[200];
    pcontext;
    if(npeer==0) return 0x0;
    snprintf(buf,sizeof(buf),"Lost Connection from %s (%s)",newpeer(npeer)->host,newpeer(npeer)->nick);
    log(buf);
    erasepeer(npeer);
    return;	  
}

/* if an new peer gets killed */

int erroroldlistener(int npeer,int errn)
{
    char buf[200];
    pcontext;
    if(npeer==0) return 0x0;
    snprintf(buf,sizeof(buf),"Lost Connection from %s (%s)",newpeer(npeer)->host,newpeer(npeer)->nick);
    log(buf);
    erasepeer(npeer);
    return;	  
}

/* checking data coming on a peer */

int checkoldlistener(int npeer)
{
    int rc;
    int i;
    struct socketnodes *lkm;
    char buf[200];
    char *po;
    pcontext;
    if (newpeer(npeer)->state != STD_NOUSE) {
          newpeer(npeer)->delayed++;
	  if (newpeer(npeer)->delayed > 8) {
	     writesock(newpeer(npeer)->insock,"too many unknown input, disconnecting.\n");
	     erasepeer(npeer);
	     return;
	  }
	  parse();
	  if (ifcommand("USER")) {
	     snprintf(newpeer(npeer)->user,sizeof(newpeer(npeer)->user),"%s",irccontent);
	     po=ircto;
	     po=strchr(ircto,' ');
	     if (po==NULL) return 0x0;
	     *po=0;
	     snprintf(newpeer(npeer)->login,sizeof(newpeer(npeer)->login),"%s",ircto);
	     i=checkuser(newpeer(npeer)->login);
	     if(i!=0)
	     {
	         if(*user(i)->crkey!=0)
		 {
		     lkm=getpsocketbysock(newpeer(npeer)->insock);
		     if(lkm!=NULL)
		     {
		         snprintf(lkm->sock->incrkey,sizeof(lkm->sock->incrkey),"%s",user(i)->crkey);
		         snprintf(lkm->sock->outcrkey,sizeof(lkm->sock->outcrkey),"%s",user(i)->crkey);
			 lkm->sock->encryption=SE_ENC;
		     }
		 }
	     }
	  }
	  if (ifcommand("PSYBNC")) {
	     newpeer(npeer)->lnkport=atoi(irccontent);
	     snprintf(newpeer(npeer)->name,sizeof(newpeer(npeer)->name),"%s",ircto);
	     newpeer(npeer)->type=NP_LINK; /* this is a bouncer */
	     i=getlink(npeer);
	     if(i!=0)
	     {
		 if(*datalink(i)->crkey!=0)
		 {
	             lkm=getpsocketbysock(newpeer(npeer)->insock);
		     if(lkm!=NULL)
		     {
		         snprintf(lkm->sock->incrkey,sizeof(lkm->sock->incrkey),"%s",datalink(i)->crkey);
		         snprintf(lkm->sock->outcrkey,sizeof(lkm->sock->outcrkey),"%s",datalink(i)->crkey);
			 lkm->sock->encryption=SE_ENC;
		     }
		 }
	     }
	  }
	  if (ifcommand("VHOST")) {
	     snprintf(newpeer(npeer)->vhost,sizeof(newpeer(npeer)->vhost),"%s",irccontent);
	  }
	  if (ifcommand("CONNECT")) {
	     snprintf(newpeer(npeer)->server,sizeof(newpeer(npeer)->server),"%s",ircto);
	     newpeer(npeer)->port=atoi(irccontent);
	  }
	  if (ifcommand("RELAY")) {
	     newpeer(npeer)->lnkport=atoi(irccontent);
	     snprintf(newpeer(npeer)->name,sizeof(newpeer(npeer)->name),"%s",ircto);
	     newpeer(npeer)->type=NP_RELAY; /* this is a relay */
	  }
	  if (ifcommand("NICK")) {
	     snprintf(newpeer(npeer)->nick,sizeof(newpeer(npeer)->nick),"%s",irccontent);
	     if (strlen(newpeer(npeer)->pass)==0 && newpeer(npeer)->type==0) {
	         snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Your IRC Client did not support a password. Please type /QUOTE PASS yourpassword to connect.",newpeer(npeer)->nick);
		 writesock(newpeer(npeer)->insock,buf);
	     }
	  }
	  if (ifcommand("PASS")) {
	     if (*irccontent=='+') *irccontent='-'; /* yah yah yah */
	     snprintf(newpeer(npeer)->pass,sizeof(newpeer(npeer)->pass),"%s",irccontent);
	     if (newpeer(npeer)->type!=NP_USER)
	     {
	         if (linklink(npeer)==-1)
		 {
		     snprintf(buf,sizeof(buf),"Failed incoming Link %s (%s)",newpeer(npeer)->host,newpeer(npeer)->name);
		     log(buf);
	             erasepeer(npeer);
		     return 0x0;		     
		 }
		 return 0x0;
	     }
	  }
	  if (strlen(newpeer(npeer)->nick) != 0) {
  	    if (strlen(newpeer(npeer)->login) != 0) {
	      if (strlen(newpeer(npeer)->pass) != 0) {
	          if (linkpeer(npeer) ==-1) {
		     snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Wrong Password. Disconnecting.\n",newpeer(npeer)->nick);
	             writesock(newpeer(npeer)->insock,buf);
		     snprintf(buf,sizeof(buf),"Failed Authentification %s (%s)",newpeer(npeer)->host,newpeer(npeer)->nick);
		     log(buf);
	             erasepeer(npeer);
		  }
	      }
	    }  
	  }
    }
}

char ntoares[16];
int sport;

/* checking a hosts allow */

int checkhostallows(char *host)
{
    char buf[350];
    char buf2[350];
    struct stringarray *th;
    char *pt;
    snprintf(buf,sizeof(buf),"*!*@%s",host);
    th=hostallows;
    while(th!=NULL)
    {
	snprintf(buf2,sizeof(buf2),"*!*@%s",th->entry);
	pt=strchr(buf2,':');
	if(pt!=NULL) *pt=0;
	if(wild_match(buf2,buf)) return 1;
	th=th->next;
    }
    return -1;
}

/* check a connected peer structure */

int checknewlistener(int i)
{
    fd_set rfds;
    int ret;
    struct timeval tv;
    int asocket;
    int npeer;
    char buf[300];
    char hostname[200];
    struct socketnodes *lkm;
    pcontext;

    asocket = bncaccept( listensocket );
    pcontext;
    if(checkhostallows(bnchost)==-1)
    {
	snprintf(buf,sizeof(buf),"Illegit Connection from %s. Closing Connection.",bnchost);
	lkm=getpsocketbysock(listensocket);
	if(lkm!=NULL)
	{
	    lkm->sock->flag=SOC_SYN; /* resetting the listener to listen again */
	}
	log(buf);
	shutdown(asocket,2);
	close(asocket);
	return 0x0;
    }
    if(asocket<=0) return;    
    asocket=createsocket(asocket,ST_LISTEN,0,NULL,NULL,erroroldlistener,checkoldlistener,killoldlistener);
    
    lkm=getpsocketbysock(listensocket);
    if(lkm!=NULL)
    {
	lkm->sock->flag=SOC_SYN; /* resetting the listener to listen again */
    }
    pcontext;
    if (asocket==-1) return -1;
    if (checkpeerhostname(bnchost) == -1) {
	write(asocket,"Only one Connection per Host allowed !\n",39);
	killsocket(asocket);
	return;
    }
    npeer = getnewpeer();
    pcontext;
    if (npeer == -1) {
	snprintf(buf,sizeof(buf),"too many connections, removing connection from %s",bnchost);
	log(buf);
        write(asocket,"Too many host connctions !\n",28);
	killsocket(asocket);
	return;
    }
    lkm=getpsocketbysock(asocket);
    pcontext;
    if(lkm!=NULL)
    {
	lkm->sock->param=npeer;
	lkm->sock->flag=SOC_CONN;
	snprintf(lkm->sock->source,sizeof(lkm->sock->source),ntoares);
	snprintf(lkm->sock->dest,sizeof(lkm->sock->dest),"*");
	lkm->sock->sport=sport;
	if(socketnode->sock!=NULL)
	{
             lkm->sock->dport=socketnode->sock->sport;
	}
    }
    clearpeer(npeer);	
    pcontext;
    newpeer(npeer)->insock = asocket;
    snprintf(newpeer(npeer)->host,sizeof(newpeer(npeer)->host),"%s", bnchost);
    newpeer(npeer)->state = STD_NEWCON;
    newpeer(npeer)->delayed = 0;
    snprintf(buf,sizeof(buf),"connect from %s",bnchost);
    log(buf);	
    return;
}
/* create listening sock */

void killed ()
{
   log("killed by user abort");
   exit(0x0);
}

/* error routine */

void errored ()
{
   errn = 1;
   return;
}

/* creating listening port for demon */

int createlistener (int listenport)
{
  struct sockaddr_in listen_sa;
  int sopts = 1;
  struct sigaction sv;
  struct sigaction sx;
  struct socketnodes *lkm;
  int opt;
  sigemptyset(&sv.sa_mask);
  sv.sa_handler = killed;
  sigemptyset(&sx.sa_mask);
  sx.sa_handler = errored;
  sigaction( SIGTERM, &sv, NULL);
  sigaction( SIGINT, &sx, NULL);
  sigaction( SIGKILL, &sv, NULL);
  sigaction( SIGHUP, &sx, NULL);
  sigaction( SIGUSR1, &sx, NULL);
  sigaction( SIGPIPE, &sx, NULL);
  umask( ~S_IRUSR & ~S_IWUSR );
  srand( time( NULL) );
  
  listensocket = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
  listensocket = createsocket(listensocket,ST_LISTEN,0,NULL,checknewlistener,NULL,NULL,NULL);
  lkm=getpsocketbysock(listensocket);
  if(lkm==NULL || listensocket==0)
  {
      log("Can't create listening sock.. aborting");
      return -1;
  }
  snprintf(lkm->sock->source,sizeof(lkm->sock->source),"*");
  snprintf(lkm->sock->dest,sizeof(lkm->sock->dest),"*");
  lkm->sock->sport=listenport;
  lkm->sock->dport=0;
  lkm->sock->flag=SOC_SYN; /* we are open */
  highestsocket = listensocket;

  opt=sizeof(int);
  setsockopt (listensocket, SOL_SOCKET, SO_REUSEADDR, &sopts, opt);

  memset (&listen_sa, 0, sizeof (struct sockaddr_in));

  listen_sa.sin_port = htons (listenport);
  listen_sa.sin_addr.s_addr = htonl (INADDR_ANY);

  if ((bind (listensocket, (struct sockaddr *) &listen_sa, sizeof (struct sockaddr_in))) == -1)
  {
     return -1; /* cannot create socket */
  }
  if ((listen (listensocket, 1)) == -1)
  {
      return -1; /* cannot create socket */
  }
  return listensocket; /* success */
}


/* accept incoming call on listener */

int bncaccept( int lsock)
{
   struct sockaddr_in addr;
   struct socketnodes *lkm;
   int tm;
   int str;
   pcontext;
   memset(bnchost,0x0,sizeof(bnchost));
   tm = sizeof( struct sockaddr_in);
   str = accept(lsock, ( struct sockaddr * )&addr, &tm);
   if (str==-1) return -1;
   highestsocket = str;
   hostinfo = gethostbyaddr( ( char * )&addr.sin_addr.s_addr, sizeof( struct in_addr), AF_INET);
   if (hostinfo) snprintf(bnchost,sizeof(bnchost),"%s", hostinfo->h_name);
   else snprintf( bnchost,sizeof(bnchost),"%s", inet_ntoa( addr.sin_addr ));
   snprintf(ntoares,sizeof(ntoares),"%s",inet_ntoa(addr.sin_addr));
   sport=ntohs(addr.sin_port);
   return str;
}
