 ---------------------------------------------------------------
 mIRC32 Extension DLL [moo.dll]
 ---------------------------------------------------------------

 General:
 ========

 moo.dll is a penis extension for mIRC, originally developed in Object Pascal [Delphi 5] but is now
 living its life in C++ (and is 200K smaller) :D

 License:
 ========

 Copyright (C) 2000 Mark Hutton - mailto:mark@influenced.net

 This program is free software; you can redistribute it and/or
 modify it under the terms of the GNU General Public License
 as published by the Free Software Foundation; either version 2
 of the License, or (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 Usage:
 ======

 [in mIRC]
 $dll(moo.dll,<function>,_)

 Accompanying moodll.mrc should be used.

 Functions:
 ==========
 uptime - returns system uptime
 osinfo - returns operating system version
 cpuinfo - returns cpu information
 meminfo - returns memory usage information
 version - returns moo.dll version
 connection - returns dialup connection statistics

 Research:
 =========
 http://www.mircscripter.com/mirc_dll.html
 ... mIRC DLL coding
 http://developer.intel.com/software/idap/
 ... Intel CPUID informaton, see 24161815.pdf
 http://www.escape.ca/~rrrobins/Assembly/index.html
 ... Assembly language tutorial
 http://cplus.about.com/compute/cplus/
 ... Misc C/C++ articles
 http://web.inter.nl.net/hcc/J.Steunebrink/chkcpu.htm
 ... CPUID program (IIRC)
 http://developer.earthweb.com/dlink.resource-jhtml.72.1685.|repository||softwaredev|content|article|2000|06|28|SDNgocSysInfo|SDNgocSysInfo~xml.0.jhtml?cda=true
 ... More C/C++ Stuff
 http://www.jungo.com/faq.html
 ... No idea :)
 http://www.sandpile.org/ia32/cpuid.htm
 ... V.Useful CPUID stuff
 http://www.codetools.com/system/sysinfox.asp
 ... Very basic CPUID C/C++ code

 ---------------------------------------------------------------
    Copyright � Mark Hutton 2000 mailto: mark@influenced.net
 ---------------------------------------------------------------