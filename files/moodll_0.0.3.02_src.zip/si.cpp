/*
moo.dll component file 
[si.cpp - system information class procedures + misc]
Copyright (C) 2000 Mark Hutton - mailto:mark@influenced.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "windows.h"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
#include "si.h"
#include "myras.h"

CSysInfo::CSysInfo()
{
	// Constructor
	ZeroMemory(pstrUptime,100);
	ZeroMemory(pstrCPU,100);
	ZeroMemory(pstrOSInfo,100);
	ZeroMemory(pstrMemInfo,100);
	ZeroMemory(pstrVersion,100);
	blRasCompat = 1;
	blRas2K = 0;
	blRas9X = 0;
}

CSysInfo::~CSysInfo()
{
	// Destructor
}

void CSysInfo::UpdateUptime()
{
	// Updates Uptime var
	unsigned long lintTicks;
	lintTicks = GetTickCount();
	MSecToTime(lintTicks,pstrUptime,sizeof(pstrUptime));

}

void MSecToTime(unsigned long msectime, char* timestring, int timestrlen) {

	unsigned int intWeeks = 0;
	unsigned int intDays = 0;
	unsigned int intHours = 0;
	unsigned int intMinutes = 0;
	unsigned int intCurPos = 0;
	unsigned int intSeconds = 0;

	ZeroMemory(timestring, timestrlen);

	intSeconds = (msectime / 1000) % 60;
	intMinutes = ( (msectime / 1000) / 60) % 60;
	intHours = ( ( (msectime / 1000) / 60) / 60) % 24;
	intDays = ( ( ( (msectime / 1000) / 60) / 60) / 24) % 7;
    intWeeks = ( ( ( ( (msectime / 1000) / 60) / 60) / 24) / 7) % 52; // fuck months :)

	if (intWeeks > 0) {
		_ui64toa(intWeeks,timestring+intCurPos,10);
		intCurPos += 1;
		if (intWeeks > 9) { intCurPos += 1; }
		strcpy(timestring+intCurPos, "w ");
		intCurPos += 2;
	}

	if (intDays > 0) { 
		_ui64toa(intDays,timestring+intCurPos,10);
		intCurPos += 1;
		if (intDays > 9) { intCurPos += 1; }
		strcpy(timestring+intCurPos, "d ");
		intCurPos += 2;
	}

	if (intHours > 0) {
		_ui64toa(intHours,timestring+intCurPos,10);
		intCurPos += 1;
		if (intHours > 9) { intCurPos += 1; }
		strcpy(timestring+intCurPos, "h ");
		intCurPos += 2;
	}

	if (intMinutes > 0) {
		_ui64toa(intMinutes,timestring+intCurPos,10);
		intCurPos += 1;
		if (intMinutes > 9) { intCurPos += 1; }
		strcpy(timestring+intCurPos, "m ");
		intCurPos += 2;
	}

	if (intSeconds > 0) {
		_ui64toa(intSeconds,timestring+intCurPos,10);
		intCurPos += 1;
		if (intSeconds > 9) { intCurPos += 1; }
		strcpy(timestring+intCurPos, "s");
		intCurPos += 1;
	}

}

void CSysInfo::UpdateCPU()
{
	// Updates CPU var
    SYSTEM_INFO sysi;
	char strProcessor[50] = "";
	CTimer timer;

	long tickslong;
	long tickslongextra;
	timer.Start(); Sleep(1000); 
	unsigned cpuspeed100 = (unsigned)(timer.Stop()/10000);
	tickslong = cpuspeed100/100;
	tickslongextra = cpuspeed100-(tickslong*100);

	GetSystemInfo(&sysi);
	_ui64toa(sysi.dwNumberOfProcessors,pstrCPU,10);
    strcat(pstrCPU,"-");
    GetProcessorType(strProcessor);
    strcat(pstrCPU,strProcessor);
    strcat(pstrCPU,", ");
    _ui64toa(tickslong,pstrCPU+strlen(pstrCPU),10);
	//strcat(pstrCPU,".");
    //_ui64toa(tickslongextra,pstrCPU+strlen(pstrCPU),10);
    strcat(pstrCPU,"MHz");


}

void CSysInfo::UpdateOSInfo()
{
	// Updates OSInfo var
    // fills our char array with full os version
	// e.g. Windows 98 (4.10 - 1998)
	//		Windows 2000 Professional, Service Pack 1 (5.0 - 2195)
	ZeroMemory(pstrOSInfo,sizeof(pstrOSInfo));
	OSVERSIONINFO osvi;
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	GetVersionEx(&osvi);

	switch(osvi.dwPlatformId)
	{
		case VER_PLATFORM_WIN32s:
		{
			// Win32s on Win3.1
			strcpy(pstrOSInfo,"Win32s on Windows 3.1");
			break;
		}
		case VER_PLATFORM_WIN32_WINDOWS:
		{
			// Windows 95/98/ME
			blRas9X = 1;
			if (osvi.dwMajorVersion == 4) {
				if (osvi.dwMinorVersion == 0) {
					// Windows 95
                    strcpy(pstrOSInfo,"Windows 95");
				} else if (osvi.dwMajorVersion == 4 && (osvi.dwBuildNumber & 0xFFFF)<2250) {
					// Windows 98
                    strcpy(pstrOSInfo,"Windows 98");
				} else if (osvi.dwMajorVersion == 4 && (osvi.dwBuildNumber & 0xFFFF)>=2250) {
                    strcpy(pstrOSInfo,"Windows ME");
				}
			} else { strcpy(pstrOSInfo,"Unknown Windows 9X Kernel OS"); }
			// Format the version (major.minor - build)
			strcat(pstrOSInfo," (");
			_ui64toa((osvi.dwMajorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,".");
			_ui64toa((osvi.dwMinorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo," - ");
			_ui64toa((osvi.dwBuildNumber & 0xFFFF),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,")");
			break;
		}
		case VER_PLATFORM_WIN32_NT:
		{
			// Windows NT/2000
			if (osvi.dwMajorVersion <= 4) {
				// Windows NT
				if (osvi.dwMajorVersion == 3) { blRasCompat = 0; }
				HKEY hKey;
				char szProductType[80];
				DWORD dwBufLen;
				RegOpenKeyEx( HKEY_LOCAL_MACHINE,"SYSTEM\\CurrentControlSet\\Control\\ProductOptions",0, KEY_QUERY_VALUE, &hKey );
				RegQueryValueEx( hKey, "ProductType", NULL, NULL,(LPBYTE) szProductType, &dwBufLen);
				RegCloseKey( hKey );
				if ( lstrcmpi( "WINNT", szProductType) == 0 )
					strcpy(pstrOSInfo,"Windows NT Workstation");
				if ( lstrcmpi( "SERVERNT", szProductType) == 0 )
					strcpy(pstrOSInfo,"Windows NT Server");
				if ( strlen(osvi.szCSDVersion) > 0 ) {
					// Service Pack Installed
					strcat(pstrOSInfo,", ");
					strcat(pstrOSInfo,osvi.szCSDVersion);
				}
			} else if (osvi.dwMajorVersion == 5) {
				// Windows NT 5.X (2000)
				// Use new version info
				blRas2K = 1;
				OSVERSIONINFOEX osvi2k;
				ZeroMemory(&osvi2k, sizeof(OSVERSIONINFOEX));
				osvi2k.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
				GetVersionEx((OSVERSIONINFO *)&osvi2k);
				strcpy(pstrOSInfo,"Windows 2000");
				switch(osvi2k.wProductType) {
					case VER_NT_WORKSTATION:
					{
						// Windows 2000 Professional
						strcat(pstrOSInfo," Professional");
						break;
					}
					case VER_NT_DOMAIN_CONTROLLER:
					{
						// Windows 2000 Domain Controller
						strcat(pstrOSInfo," Domain Controller");
						break;
					}
					case VER_NT_SERVER:
					{
						// Windows 2000 Server
						strcat(pstrOSInfo," Server");
						break;
					}
				}
				if ( strlen(osvi2k.szCSDVersion) > 0 ) {
					// Service Pack Installed
					strcat(pstrOSInfo,", ");
					strcat(pstrOSInfo,osvi2k.szCSDVersion);
				}
			} else { strcpy(pstrOSInfo,"Unknown Windows NT Kernel OS"); }
			// Format the version (major.minor - build)
			strcat(pstrOSInfo," (");
			_ui64toa((osvi.dwMajorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,".");
			_ui64toa((osvi.dwMinorVersion),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo," - ");
			_ui64toa((osvi.dwBuildNumber & 0xFFFF),pstrOSInfo+strlen(pstrOSInfo),10);
			strcat(pstrOSInfo,")");
			break;
		}
		default:
		{
			// Fuck knows
			strcpy(pstrOSInfo,"Unknown");
			break;
		}
	}
}

void CSysInfo::UpdateMemInfo()
{
	// Updates MemInfo var
	MEMORYSTATUS memi;
	DWORD ramtotal;
	DWORD ramused;
	float pctused = 0;

	GlobalMemoryStatus(&memi);
	ramtotal = (((memi.dwTotalPhys / 1024) / 1024) + 1); // stops the peons whining :|
	ramused = ramtotal - (((memi.dwAvailPhys / 1024) / 1024) + 1);
	strcpy(pstrMemInfo,"Usage: ");
    _ui64toa(ramused,pstrMemInfo+strlen(pstrMemInfo),10);
    strcat(pstrMemInfo,"/");
    _ui64toa(ramtotal,pstrMemInfo+strlen(pstrMemInfo),10);
	strcat(pstrMemInfo,"MB (");
	pctused = (((float)ramused / (float)ramtotal)*100);
    sprintf(pstrMemInfo+strlen(pstrMemInfo),"%.2f",pctused);
	strcat(pstrMemInfo,"%)");
}

void CSysInfo::UpdateVersion()
{
	// Updates Version var
	strcpy(pstrVersion,VERSION);
}

void CSysInfo::UpdateScreenInfo()
{
	// Updates ScreenInfo var
	int intScreenX, intScreenY, intScreenBPP, intScreenRefresh;
	HDC hdcDesktop;
	HWND hwndDesktop;

	hwndDesktop = GetDesktopWindow();
	hdcDesktop = GetDC(hwndDesktop);
	intScreenX = GetDeviceCaps(hdcDesktop,HORZRES);
	intScreenY = GetDeviceCaps(hdcDesktop,VERTRES);
	intScreenBPP = GetDeviceCaps(hdcDesktop,BITSPIXEL);
	intScreenRefresh = GetDeviceCaps(hdcDesktop,VREFRESH);
	ReleaseDC(hwndDesktop,hdcDesktop);

	ZeroMemory(pstrScreenInfo,sizeof(pstrScreenInfo));
	_itoa(intScreenX,pstrScreenInfo,10);
	strcat(pstrScreenInfo,"x");
	_itoa(intScreenY,pstrScreenInfo+strlen(pstrScreenInfo),10);
	strcat(pstrScreenInfo," ");
	_itoa(intScreenBPP,pstrScreenInfo+strlen(pstrScreenInfo),10);
	strcat(pstrScreenInfo,"bit");
	if (intScreenRefresh!=0 && intScreenRefresh!=1) {
		strcat(pstrScreenInfo," ");
		_itoa(intScreenRefresh,pstrScreenInfo+strlen(pstrScreenInfo),10);
		strcat(pstrScreenInfo,"Hz");
	}

}

// Other functions used by this class

void GetProcessorType(char *proctext)

{
	DWORD regEAX = 0;
	DWORD regEBX = 0;

    char strVendorID[13];
	ZeroMemory(strVendorID,13);

    GetProcessorVendor((char*)&strVendorID);

	__try { 
		_asm {
			mov eax, 1		// set up CPUID to return processor version and features
						    //	0 = vendor string, 1 = version info, 2 = cache info
			CPUID			// code bytes = 0fh,  0a2h
			and eax, 03fffh		// type, family, model, stepping returned in eax
			mov regEAX, eax
			mov regEBX, ebx
		}
	} __except(EXCEPTION_EXECUTE_HANDLER) {regEAX = 0;}


	DWORD type, family, model, stepping, brand;
	int extra;

	type     = (regEAX>>12) & 0x3;
	family   = (regEAX>>8)  & 0xf;
	model    = (regEAX>>4)  & 0xf;
	stepping =  regEAX      & 0xf;
    brand    =  (regEBX>>12);
    extra = GetProcessorExtra();

	// strcpy(strVendorID,"TestTestTest");

	if ( strcmp(strVendorID,"GenuineIntel") == 0 )
	{
		strcpy(proctext,"Intel ");
		// Intel CPUs
		if (family == 5)
			strcat(proctext,INTEL_P1_NORMAL);
		else if (family == 6 && (model == 1 || model == 2))
			strcat(proctext,INTEL_P1_PRO);
		else if (family == 6 && model == 3)
			strcat(proctext,INTEL_P2_NORMAL);
		else if (family == 6 && model == 4)
			strcat(proctext,INTEL_P2_NORMAL);
		else if (family == 6 && model == 5 && extra == 1)
			strcat(proctext,INTEL_P2_NORMAL);
		else if (family == 6 && model == 5 && extra == 2)
			strcat(proctext,INTEL_P2_CELERON);
		else if (family == 6 && model == 5 && extra == 3)
			strcat(proctext,INTEL_P2_XEON);
		else if (family == 6 && model == 6)
			strcat(proctext,INTEL_P2_CELERON);
		else if (family == 6 && model == 7 && extra == 1)
			strcat(proctext,INTEL_P3_NORMAL);
		else if (family == 6 && model == 7 && extra == 2)
			strcat(proctext,INTEL_P3_CELERON);
		else if (family == 6 && model == 7 && extra == 3)
			strcat(proctext,INTEL_P3_XEON);
		else if (family == 6 && model == 8 && extra == 1)
			strcat(proctext,INTEL_P3_NORMAL);
		else if (family == 6 && model == 8 && extra == 2)
			strcat(proctext,INTEL_P3_CELERON);
		else if (family == 6 && model == 8 && extra == 3)
			strcat(proctext,INTEL_P3_XEON);
		else if (family == 6 && model == 0xA)
			strcat(proctext,INTEL_P3_XEON);
	}
	else if ( strcmp(strVendorID,"AuthenticAMD") == 0 )
	{
        strcpy(proctext,"AMD ");
	    // AMD CPUs
		if (family == 5 && model < 4)
			strcat(proctext,AMD_K5);
		else if (family == 5 && model == 6)
			strcat(proctext,AMD_K6);
		else if (family == 5 && model == 7)
			strcat(proctext,AMD_K6);
		else if (family == 5 && model == 8)
			strcat(proctext,AMD_K6_2);
		else if (family == 5 && model == 9)
			strcat(proctext,AMD_K6_3);
		else if (family == 5 && model == 0xD)
			strcat(proctext,AMD_K6_3PLUS);
		else if (family == 6 && model == 1)
			strcat(proctext,AMD_K7);
		else if (family == 6 && model == 2)
			strcat(proctext,AMD_K7);
		else if (family == 6 && model == 3)
			strcat(proctext,AMD_K7);
		else if (family == 6 && model == 4)
			strcat(proctext,AMD_K7);
	}
	else if ( strcmp(strVendorID,"CyrixInstead") == 0 )
	{
        strcpy(proctext,"Cyrix :/");
	    // Cyrix CPUs
	}
	else
	{
		// Unknown CPUs
	    strcpy(proctext,strVendorID);
		strcat(proctext," T(");
		_itoa(type,proctext+strlen(proctext),10);
		strcat(proctext,")F(");
		_itoa(family,proctext+strlen(proctext),10);
		strcat(proctext,")M(");
		_itoa(model,proctext+strlen(proctext),10);
		strcat(proctext,")S(");
		_itoa(stepping,proctext+strlen(proctext),10);
		strcat(proctext,")B(");
        _itoa(brand,proctext+strlen(proctext),10);
		strcat(proctext,")");
	}

    

}

void GetProcessorVendor(char *vid)
{

	DWORD regEBX = 0x00000000;
	DWORD regECX = 0x00000000;
	DWORD regEDX = 0x00000000;
	DWORD *curDWORD; // point to the dword to convert

	int reps = 0;

	__try { 
		_asm {
			mov eax, 0
			CPUID
			mov regEBX, ebx
			mov regECX, ecx
			mov regEDX, edx
		}
	} __except(EXCEPTION_EXECUTE_HANDLER) { return; }

	curDWORD = &regEBX;
	strncpy(vid,(char*)curDWORD,4);
	curDWORD = &regEDX;
	strncat(vid,(char*)curDWORD,4);
	curDWORD = &regECX;
	strncat(vid,(char*)curDWORD,4);


}

int GetProcessorExtra(void)
{

    // Function to return whether chip is plain old PII/PIII, Celeron or Xeon 
	// 1 = Normal, 2 = Celeron (0/128K cache), 3 = XEON (>512KB cache)

    DWORD regEAX, regEBX, regECX, regEDX;

	__try { 
		_asm {
			mov eax, 2
			CPUID
			mov regEAX, eax
			mov regEBX, ebx
			mov regECX, ecx
			mov regEDX, edx
		}
	} __except(EXCEPTION_EXECUTE_HANDLER) { return 0; }

	// enumerate through each value
	// 15 checks in total, AL need not be checked (but is currently), should = 0x01
	// EAX
    // (((regEAX & 0xFF000000) >> 24) == 0x40) - Celeron 0K L2 Cache
	// (((regEAX & 0xFF000000) >> 24) == 0x41) - Celeron 128K L2 Cache
	// (((regEAX & 0xFF000000) >> 24) > 0x43) - Xeon

	DWORD ShiftTable[4] =
	{
		0xFF000000, 0x00FF0000, 0x0000FF00, 0x000000FF
	};

    DWORD *regCurrent[4] =
	{
		&regEAX, &regEBX, &regECX, &regEDX
	};
	
	for ( int regreps = 0; regreps < 4; regreps++ ) {
		for ( int shreps = 0; shreps < 4; shreps++ ) {
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x40) { return 2; }
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x41) { return 2; }
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x44) { return 3; }
			if (((*regCurrent[regreps] & ShiftTable[shreps]) >> (shreps*8)) == 0x45) { return 3; }
		}
    }

    return 1;
}

void CSysInfo::UpdateConnection() {


	UpdateOSInfo();
	if (!blRasCompat) { 
		strcpy(pstrConnection,"unknown");	
		return; 
	}

	// Dynamically link available ras api library
	TRasModule rasmod;
	DWORD dwConnections;
	rasmod.Create();

	if (blRas2K) {
		// Generic connection
		RASCONN2K rasconn;
		rasconn.dwSize = sizeof(RASCONN2K);
		DWORD dwSize = rasconn.dwSize;
		char* connduration[20];
		rasmod.RasEnumConnections2K(&rasconn, &dwSize, &dwConnections);
		if (dwConnections!=1 && dwConnections!=2) {
			strcpy(pstrConnection,"none detected");
			rasmod.Destroy();
			return;
		}
		strcpy(pstrConnection,rasconn.szEntryName);
		strcat(pstrConnection," via ");
		strcat(pstrConnection,rasconn.szDeviceName);
		strcat(pstrConnection," @ ");
		RAS_STATS rasstats;
		rasstats.dwSize = sizeof(RAS_STATS);
		rasmod.RasGetConnectionStatistics(rasconn.hrasconn, &rasstats);
		_itoa(rasstats.dwBps,pstrConnection+strlen(pstrConnection),10);
		strcat(pstrConnection,"bps");
		strcat(pstrConnection," for ");
		MSecToTime(rasstats.dwConnectDuration,(char*)connduration,sizeof(connduration));
		strcat(pstrConnection,(char*)connduration);
		float connup = 0, conndown = 0;
		connup = ((float)rasstats.dwBytesXmited/1000000);
		conndown = ((float)rasstats.dwBytesRcved/1000000);
		strcat(pstrConnection," (");
		sprintf(pstrConnection+strlen(pstrConnection),"%.2f",connup);
		strcat(pstrConnection,"MB up, ");
		sprintf(pstrConnection+strlen(pstrConnection),"%.2f",conndown);
		strcat(pstrConnection,"MB down)");
	} else if (blRas9X) {
		// Generic connection
		RASCONN98 rasconn;
		rasconn.dwSize = sizeof(RASCONN98);
		DWORD dwSize = rasconn.dwSize;
		rasmod.RasEnumConnections98(&rasconn, &dwSize, &dwConnections);
		if (dwConnections!=1 && dwConnections!=2) {
			strcpy(pstrConnection,"none detected");
			rasmod.Destroy();
			return;
		}
		strcpy(pstrConnection,rasconn.szEntryName);
		strcat(pstrConnection," via ");
		strcat(pstrConnection,rasconn.szDeviceName);
		// Connection speed 
		strcat(pstrConnection," @ ");

		DWORD dwConnectionSpeed;
		DWORD dwBytesRecvd;
		DWORD dwBytesXmitd;

		GetPerformanceData("Dial-Up Adapter","ConnectSpeed",&dwConnectionSpeed);
		GetPerformanceData("Dial-Up Adapter","TotalBytesRecvd",&dwBytesRecvd);
		GetPerformanceData("Dial-Up Adapter","TotalBytesXmit",&dwBytesXmitd);

		_itoa(dwConnectionSpeed,pstrConnection+strlen(pstrConnection),10);
		strcat(pstrConnection,"bps");
		float connup = 0, conndown = 0;
		connup = ((float)dwBytesXmitd/1000000);
		conndown = ((float)dwBytesRecvd/1000000);
		strcat(pstrConnection," (");
		sprintf(pstrConnection+strlen(pstrConnection),"%.2f",connup);
		strcat(pstrConnection,"MB up, ");
		sprintf(pstrConnection+strlen(pstrConnection),"%.2f",conndown);
		strcat(pstrConnection,"MB down)");

    } else {
		// NT4???
		RASCONN98 rasconn;
		rasconn.dwSize = sizeof(RASCONN98);
		DWORD dwSize = rasconn.dwSize;
		DWORD dwSuccess = rasmod.RasEnumConnections98(&rasconn, &dwSize, &dwConnections);
		strcpy(pstrConnection,rasconn.szEntryName);
		strcat(pstrConnection," via ");
		strcat(pstrConnection,rasconn.szDeviceName);
	}
	rasmod.Destroy();
}

void GetPerformanceData(char* pstrObjectName, char* pstrCounterName, DWORD* dwDataVal) {

	char* pstrCounter[100];

	// Create full counter path
	ZeroMemory(pstrCounter,sizeof(pstrCounter));
	strcpy((char*)pstrCounter,pstrObjectName);
	strcat((char*)pstrCounter,"\\");
	strcat((char*)pstrCounter,pstrCounterName);

	HKEY hKeyDynData;
	DWORD dwRegConnect, dwType, cbData;
	dwRegConnect = RegConnectRegistry(NULL, HKEY_DYN_DATA, &hKeyDynData);

	if (dwRegConnect == ERROR_SUCCESS) {
		HKEY hOpen;
		// Start the counter
		if (RegOpenKeyEx(hKeyDynData, "PerfStats\\StartStat", 0, KEY_READ, &hOpen) == ERROR_SUCCESS) {
			cbData = 0;
			dwType = 0;
			if (RegQueryValueEx(hOpen, (LPCSTR)pstrCounter, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS) {
				BYTE* pByte = new BYTE[cbData];
				RegQueryValueEx(hOpen, (LPCSTR)pstrCounter, NULL, &dwType, pByte, &cbData);
				delete [] pByte;
			}
			RegCloseKey(hOpen);
		}

		// Collect the data
		if (RegOpenKeyEx(hKeyDynData, "PerfStats\\StatData", 0, KEY_READ, &hOpen) == ERROR_SUCCESS) {
			cbData = 4;
			RegQueryValueEx(hOpen, (LPCSTR)pstrCounter, NULL, &dwType, (LPBYTE)dwDataVal, &cbData);
			RegCloseKey(hOpen);
		}    

		// Stop the counter
		if (RegOpenKeyEx(hKeyDynData, "PerfStats\\StopStat", 0, KEY_READ, &hOpen) == ERROR_SUCCESS) {
			dwType = 0;
			cbData = 0;
			if (RegQueryValueEx(hOpen, (LPCSTR)pstrCounter, NULL, &dwType, NULL, &cbData) == ERROR_SUCCESS) {
				BYTE* pByte = new BYTE[cbData];
				RegQueryValueEx(hOpen, (LPCSTR)pstrCounter, NULL, &dwType, pByte, &cbData);
				delete [] pByte;
			}
			RegCloseKey(hOpen);
		}

		//Don't forget to close the registry key
		RegCloseKey(hKeyDynData);
	}


}