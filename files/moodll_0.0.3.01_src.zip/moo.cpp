/*
moo.dll component file 
[moo.cpp - provides interface between si class and mirc]
Copyright (C) 2000 Mark Hutton - mailto:mark@influenced.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include "windows.h"
#include "stdio.h"
#include "si.h"

int __stdcall version(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	// Outputs DLL Version
	CSysInfo SysInfo;
	SysInfo.UpdateVersion();
	strcpy(data,SysInfo.pstrVersion);
	return 3;
}

int __stdcall uptime(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
    // Outputs System Uptime
	CSysInfo SysInfo;
	SysInfo.UpdateUptime();
	strcpy(data,SysInfo.pstrUptime);
	return 3;
}

int __stdcall osinfo(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
    // Outputs Operating System Version
	CSysInfo SysInfo;
	SysInfo.UpdateOSInfo();
	strcpy(data,SysInfo.pstrOSInfo);
	return 3;
}


int __stdcall cpuinfo(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	// Outputs CPU Info
	CSysInfo SysInfo;
	SysInfo.UpdateCPU();
	strcpy(data,SysInfo.pstrCPU);
	return 3;
}

int __stdcall meminfo(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	// Outputs Memory Info
	CSysInfo SysInfo;
	SysInfo.UpdateMemInfo();
	strcpy(data,SysInfo.pstrMemInfo);
	return 3;
}

int __stdcall connection(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	// Outputs Connection Info
	CSysInfo SysInfo;
	SysInfo.UpdateConnection();
	strcpy(data,SysInfo.pstrConnection);
	return 3;
}

int __stdcall rambar(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	// Merely outputs % of ram used
	MEMORYSTATUS memi;
	DWORD ramtotal;
	DWORD ramused;
	float pctused = 0;

	GlobalMemoryStatus(&memi);
	ramtotal = (((memi.dwTotalPhys / 1024) / 1024) + 1); // stops the peons whining :|
	ramused = ramtotal - (((memi.dwAvailPhys / 1024) / 1024) + 1);
	pctused = (((float)ramused / (float)ramtotal)*100);
    sprintf(data,"%.2f",pctused);
	return 3;

}

int __stdcall screeninfo(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL print, BOOL nopause)
{
	// Outputs Screen Info
	CSysInfo SysInfo;
	SysInfo.UpdateScreenInfo();
	strcpy(data,SysInfo.pstrScreenInfo);
	return 3;
}