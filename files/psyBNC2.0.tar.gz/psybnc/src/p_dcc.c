/************************************************************************
 *   psybnc2.1, src/p_dcc.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_dcc.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_DCC

#include <p_global.h>

/* DCC - Support */
/* adding a dcc */

int adddcc(int usern, char *host, int port, char *luser, char *pass, char *name,int noini)
{
    char buf[400];
    struct linknodes *thisdcc;
    char afile[30];
    FILE *infile;
    char *ppt;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(afile,sizeof(afile),"USER%d.DCC",usern);
    thisdcc=user(usern)->dcc;
    while (1)
    {
	if (thisdcc->link==NULL) {
	    thisdcc->link=(struct datalinkt *)pmalloc(sizeof(struct datalinkt));
	    break;
	}
	if (thisdcc->next==NULL)
	{
	    thisdcc->next=(struct linknodes *)pmalloc(sizeof(struct linknodes));
	    thisdcc->next->link=(struct datalinkt *)pmalloc(sizeof(struct datalinkt));
	    thisdcc=thisdcc->next;
	    break;
	}
	thisdcc=thisdcc->next;
    }
    thisdcc->link->outstate==0;
    thisdcc->link->outsock=0;
    thisdcc->link->port=port;
    thisdcc->uid=usern;
    thisdcc->link->type=LI_DCC;
    thisdcc->link->delayed=usern;
    snprintf(thisdcc->link->user,sizeof(thisdcc->link->user),"%s",luser);
    snprintf(thisdcc->link->name,sizeof(thisdcc->link->name),"%s",name);
    snprintf(thisdcc->link->pass,sizeof(thisdcc->link->pass),"%s",pass);
    snprintf(thisdcc->link->host,sizeof(thisdcc->link->host),"%s",host);    
    if (noini==1) return 0x0;
    if ((infile = fopen(afile,"a")) == NULL) {
	if ((infile = fopen(afile,"w")) == NULL) {
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :DCC to %s temporarily added. Could not write to INI-File.\r\n",user(userp)->nick,thisdcc->link->name);
	    writesock(user(usern)->insock,buf);
	    return 0x0;
	}
    }
    snprintf(buf,sizeof(buf),"%s",pass);
    ppt=cryptit(buf);
    snprintf(buf,sizeof(buf),"%s %s %s:%s:%d\n",thisdcc->link->name,thisdcc->link->user,ppt,thisdcc->link->host,thisdcc->link->port);
    fprintf(infile,buf);
    fclose(infile);
    snprintf(buf,sizeof(buf),"DCC to %s(%s:%d) added by %s.\r\n",thisdcc->link->name,thisdcc->link->host,thisdcc->link->port,user(usern)->login);
    log(buf);
    if (user(userp)->rights != RI_ADMIN) systemnotice(userp,buf);
}

/* load all dccs of a user */

int loaddccs(int usern)
{
    char buf[400];
    struct linknodes *thisdcc;
    char afile[30];
    char *hpt;
    char *upt;
    char *ppt;
    char *npt;
    char *spt;
    int port;
    FILE *infile;
    pcontext;
    snprintf(afile,sizeof(afile),"USER%d.DCC",usern);
    if ((infile = fopen(afile,"r")) == NULL)
	return 0x0;
    while(fgets(buf,sizeof(buf),infile)) {
	npt=buf;
	upt=strchr(npt,' ');
	if (upt!=NULL)
	{
	    *upt=0;upt++;
	    ppt=strchr(upt,' ');
	    if (ppt!=NULL)
	    {
		*ppt=0;ppt++;
		hpt=strchr(ppt,':');
		if (hpt!=NULL)
		{
		    *hpt=0;hpt++;
		    spt=strchr(hpt,':');
		    if (spt!=0)
		    {
			*spt=0;spt++;
			port=atoi(spt);
			adddcc(usern,hpt,port,upt,decryptit(ppt),npt,1);
		    }	    
		}
	    }	
	}
    }      
    fclose(infile);    	    
    return 0x0;
}

/* listing dccs */

int listdccs(int usern)
{
    char buf[400];
    struct linknodes *thisdcc;
    int cnt;
    char l;
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    cnt =1;
    thisdcc=user(usern)->dcc;
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :Listing DCCs\r\n",user(userp)->nick);
    writesock(user(usern)->insock,buf);
    while (thisdcc != NULL)
    {
	if (thisdcc->link!=NULL)
	{
	    if (thisdcc->link->outstate==STD_CONN)
		l='*';
	    else
		l=' ';
	    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :%d%c %s (%s:%d)\r\n",user(userp)->nick,cnt,l,thisdcc->link->name,thisdcc->link->host,thisdcc->link->port);
	    writesock(user(usern)->insock,buf);
	    cnt++;
	}
	thisdcc=thisdcc->next;
    }
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :End of DCCs\r\n",user(userp)->nick);
    writesock(user(usern)->insock,buf);
}


/* erasing dccs */

int erasedcc(int usern,int dccn)
{
    char buf[8192];
    struct linknodes *thisdcc;
    struct linknodes *lastdcc;
    int cnt;
    char l;
    FILE *infile;
    FILE *tmp;
    char fbuf[40];
    char afile[30];
    int userp;
    pcontext;
    if (user(usern)->parent!=0) userp=user(usern)->parent; else userp=usern;
    snprintf(afile,sizeof(afile),"USER%d.DCC",usern);
    cnt =1;
    thisdcc=user(usern)->dcc;
    lastdcc=thisdcc;
    while (thisdcc != NULL)
    {
	if (thisdcc->link!=NULL)
	{
	    if (cnt==dccn) break;
	    lastdcc=thisdcc;
	    cnt++;
	}
	thisdcc=thisdcc->next;
    }
    if (thisdcc==NULL || thisdcc->link==NULL)
    {
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :No such DCC.\r\n",user(userp)->nick);
	writesock(user(usern)->insock,buf);
	return 0x0;    
    }
    if (thisdcc->link->outstate==STD_CONN)
    {
	killsocket(thisdcc->link->outsock);
	snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :DCC %d session closed.\r\n",user(userp)->nick);
	writesock(user(usern)->insock,buf);
    }
    if (thisdcc==user(usern)->dcc)
    {
	if (thisdcc->next==NULL)
	{
	    free(thisdcc->link);
	    thisdcc->link=NULL;
	} else {
	    user(usern)->dcc=thisdcc->next;
	    free(thisdcc->link);
	    free(thisdcc);
	}
    } else {
	lastdcc->next=thisdcc->next;
	free(thisdcc->link);
	free(thisdcc);
    }
    cnt=1;
    snprintf(fbuf,sizeof(fbuf),"%s.tmp",afile);
    if ((infile = fopen(afile,"r")) == NULL) {
	return 0x0;
    }
    if ((tmp = fopen(fbuf,"w")) == NULL) {
	fclose(infile);
	return 0x0;
    }
    while (fgets(buf,sizeof(buf),infile))
    {
	if (cnt != dccn) {
	   fprintf(tmp,buf);
	}
	cnt++;
    }
    fclose(infile);
    fclose(tmp);
    rename(fbuf,afile);
    snprintf(buf,sizeof(buf),":psyBNC!psyBNC@lam3rz.de NOTICE %s :DCC %d deleted.\r\n",user(userp)->nick,dccn);
    writesock(user(usern)->insock,buf);
}
/* check a dcc connection */

struct datalinkt *checkdcc(int usern, char *dccname)
{
    struct linknodes *th;
    pcontext;
    th=user(usern)->dcc;
    while (th!=NULL)
    {
	if (th->link != NULL)
	{
	    if (strlen(th->link->name)==strlen(dccname))
	    {
		if (strstr(th->link->name,dccname)!=NULL)
		    return th->link;
	    }
	}
	th=th->next;
    }
    return NULL;
}

int dcchandler(int usern)
{
    struct linknodes *lkm;
    struct datalinkt *th;
    char buf[400];
    char l=')';
    char netc[15];
    int rc;
    pcontext;
    if (user(usern)->parent!=0)
	snprintf(netc,sizeof(netc),"%s~",user(usern)->network);
    else
	memset(netc,0x0,sizeof(netc));
    lkm=user(usern)->dcc;
    while(lkm!=NULL)
    {
	if(lkm->link!=NULL)
	    if(lkm->link->outsock==currentsocket->sock->syssock) break;
	lkm=lkm->next;    
    }
    if (lkm==NULL) return 0x0;
    th=lkm->link;
    if(th->outstate==STD_CONN)
    {
	if (user(usern)->instate==STD_CONN)
	{
	    snprintf(buf,sizeof(buf),":%s%c%s!DCC@%s PRIVMSG %s :%s\r\n",netc,l,th->name,th->host,user(usern)->nick,ircbuf);
	    writesock(user(usern)->insock,buf);		
	    return 0x0;
	}
    }
}

/* connected dcc */

int connecteddcc(int usern)
{
    struct linknodes *lkm;
    struct datalinkt *th;
    char *pt;
    char buf[400];
    pcontext;
    lkm=user(usern)->dcc;
    while(lkm!=NULL)
    {
	if(lkm->link!=NULL)
	    if(lkm->link->outsock==currentsocket->sock->syssock) break;
	lkm=lkm->next;    
    }
    if (lkm==NULL) return 0x0;
    th=lkm->link;
    snprintf(buf,sizeof(buf),"Connected to DCC: %s to %s (%s:%d)",user(usern)->login,th->name,th->host,th->port);
    log(buf);
    th->delayed=5;
    if (user(usern)->rights != RI_ADMIN) systemnotice(usern,buf);
    snprintf(buf,sizeof(buf),"%s\r\n",th->user);
    writesock_DELAY(th->outsock,buf,5);
    pt=rtrim(th->pass);
    snprintf(buf,sizeof(buf),"%s\r\n",pt);
    writesock_DELAY(th->outsock,buf,5);
    th->outstate=STD_CONN;
    th->delayed=1;
}

/* connection terminated */

int killeddcc(int usern)
{
    struct linknodes *lkm;
    struct datalinkt *th;
    char buf[400];
    pcontext;
    lkm=user(usern)->dcc;
    while(lkm!=NULL)
    {
	if(lkm->link!=NULL)
	    if(lkm->link->outsock==currentsocket->sock->syssock) break;
	lkm=lkm->next;    
    }
    if (lkm==NULL) return 0x0;
    th=lkm->link;
    snprintf(buf,sizeof(buf),"Lost DCC: %s to %s (%s:%d)",user(usern)->login,th->name,th->host,th->port);
    th->delayed=5;
    log(buf);
    killsocket(th->outsock);
    th->outstate=0;
    if (user(usern)->rights != RI_ADMIN) systemnotice(usern,buf);
    return 0x0;	
}

/* connection could not be established */

int errordcc(int usern, int errn)
{
    struct linknodes *lkm;
    struct datalinkt *th;
    char buf[400];
    pcontext;
    lkm=user(usern)->dcc;
    while(lkm!=NULL)
    {
	if(lkm->link!=NULL)
	    if(lkm->link->outsock==currentsocket->sock->syssock) break;
	lkm=lkm->next;    
    }
    if (lkm==NULL) return 0x0;
    th=lkm->link;
    snprintf(buf,sizeof(buf),"Cant connect DCC: %s to %s (%s:%d)",user(usern)->login,th->name,th->host,th->port);
    th->delayed=5;
    log(buf);
    th->outstate=0;
    killsocket(th->outsock);
    if (user(usern)->rights != RI_ADMIN) systemnotice(usern,buf);
    return 0x0;	
}

/* checking a single dcc link */

int checkdcclink(int usern, struct datalinkt *th)
{
    struct socketnodes *eth;
    char buf[8192];
    char l=')';
    char netc[15];
    int rc;
    pcontext;
    if (user(usern)->parent!=0)
	snprintf(netc,sizeof(netc),"%s~",user(usern)->network);
    else
	memset(netc,0x0,sizeof(netc));
    if (th->outstate==0) {
	if (th->delayed >0)
	{
	    th->delayed-=delayinc;
	    return 0x0;
	}
    	snprintf(buf,sizeof(buf),"Connecting DCC: %s to %s (%s:%d)",user(usern)->login,th->name,th->host,th->port);
	log(buf);
	if (user(usern)->rights != RI_ADMIN) systemnotice(usern,buf);
	th->outsock=createsocket(0,ST_CONNECT,usern,NULL,connecteddcc,errordcc,dcchandler,killeddcc);
	th->outsock=connectto(th->outsock,th->host,th->port,NULL);
	eth=getpsocketbysock(th->outsock);
	if (eth!=NULL)
	{
	    eth->sock->encryption=SE_REFUSE;
	}
	th->outstate=STD_NEWCON;
	if (th->outsock==0)
	{
    	    snprintf(buf,sizeof(buf),"Cant connect DCC: %s to %s (%s:%d)",user(usern)->login,th->name,th->host,th->port);
	    th->delayed=20;
	    log(buf);
	    if (user(usern)->rights != RI_ADMIN) systemnotice(usern,buf);
	    return 0x0;	
	}
	return 0x1;
    }
    return 0x0;
}

/* checking all dcc links */

int checkdccs()
{
    struct usernodes *th;
    struct linknodes *dh;
    pcontext;
    th=usernode;
    while (th!=NULL)
    {
	if (th->user != NULL)
	{
	    dh=th->user->dcc;
	    while (dh!=NULL)
	    {
		if (dh->link!=NULL)
		{
		    if(checkdcclink(th->uid,dh->link)==1) return 0x0;
		}
		dh=dh->next;
	    }
	}
	th=th->next;
    }
}
