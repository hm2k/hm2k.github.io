// mIRC Bandwidth Monitor DLL v1.2 by Caerdydd <mike@lagged.co.uk>

#include "main.h"

EXPORT downstream(MIRC_SPECS)
{
	DWORD bandw = 0;
	bandw=band();
	sprintf(data,"%.2f",(float)bandw/1024);
	return 3;
}

EXPORT upstream(MIRC_SPECS)
{
	DWORD bandw = 0;
	bandw = upband();
	sprintf(data,"%.2f",(float)bandw/1024);
	return 3;
}

EXPORT combined(MIRC_SPECS)
{
	DWORD bandw = 0;
	bandw = band() + upband();
	sprintf(data,"%.2f",(float)bandw/1024);
	return 3;
}

EXPORT version(MIRC_SPECS)
{
	sprintf(data,"mIRC Bandwidth Monitor DLL v1.2 by Caerdydd <mike@lagged.co.uk>");
	return 3;
}

EXPORT dllinfo(MIRC_SPECS)
{
	sprintf(data,"mIRC Bandwidth Monitor DLL v1.2 by Caerdydd <mike@lagged.co.uk>");
	return 3;
}