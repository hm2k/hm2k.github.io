 ---------------------------------------------------------------
 mIRC32 Extension DLL [moo.dll]
 ---------------------------------------------------------------

 General:
 ========

 moo.dll is a penis extension for mIRC, originally developed in Object Pascal [Delphi 5] but is now
 living its life in C++ (and is 200K smaller) :D

 Usage:
 ======

 [in mIRC]
 $dll(moo.dll,<function>,_)

 Accompanying moodll.mrc should be used.

 Functions:
 ==========
 uptime - returns system uptime
 osinfo - returns operating system version
 cpuinfo - returns cpu information
 meminfo - returns memory usage information
 version - returns moo.dll version

 Research:
 =========
 http://www.mircscripter.com/mirc_dll.html
 ... mIRC DLL coding
 http://developer.intel.com/software/idap/
 ... Intel CPUID informaton, see 24161815.pdf
 http://www.escape.ca/~rrrobins/Assembly/index.html
 ... Assembly language tutorial
 http://cplus.about.com/compute/cplus/
 ... Misc C/C++ articles
 http://web.inter.nl.net/hcc/J.Steunebrink/chkcpu.htm
 ... CPUID program (IIRC)
 http://developer.earthweb.com/dlink.resource-jhtml.72.1685.|repository||softwaredev|content|article|2000|06|28|SDNgocSysInfo|SDNgocSysInfo~xml.0.jhtml?cda=true
 ... More C/C++ Stuff
 http://www.jungo.com/faq.html
 ... No idea :)
 http://www.sandpile.org/ia32/cpuid.htm
 ... V.Useful CPUID stuff
 http://www.codetools.com/system/sysinfox.asp
 ... Very basic CPUID C/C++ code

 ---------------------------------------------------------------
 Copyright � Mark Hutton 2000 mailto: mark.hutton@btinternet.com
 ---------------------------------------------------------------