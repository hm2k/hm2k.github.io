/************************************************************************
 *   psybnc2.1, src/p_socket.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_socket.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_SOCKET

#include <p_global.h>

#define MAX_SENDQ 100

/* gets a socketnode from the corresponding system socket number */

struct socketnodes *previous;

struct socketnodes *getpsocketbysock(int syssock)
{
    struct socketnodes *th;
    th=socketnode;
    previous=socketnode;
    while(th!=NULL)
    {
	if (th->sock!=NULL)
	{
	    if (th->sock->syssock==syssock) return th;
	}
	previous=th;
	th=th->next;
    }
    return NULL;
}

char rbuf[200];
int errn;

/* random string */

const char *randstring(int length)
{
    char *po;
    int i;
    memset(rbuf,0x0,sizeof(rbuf));
    po=rbuf;
    if (length >100) length = 100;
    for(i=0;i<length;i++) { *po=(char)(0x61+(rand()&15)); po++; }
    *po=0x0;
    po=rbuf;
    return po;
}
/* replaces given character with another character */

int replace(char *rps,char whatc, char toc)
{
   char *p1;    
   p1=strchr(rps,whatc);
   while (p1) {
      *p1=toc;
      p1++;
      p1=strchr(p1,whatc);
   }
}

int log(char *what)
{
    struct socketnodes *lkm;
    char buf[8192];
    if(currentsocket==NULL) return 0x0;
    if(currentsocket->sock->type==ST_LISTEN)
	lkm=currentsocket;
    else
	lkm=getpsocketbysock(currentsocket->sock->relaysock);
    if(lkm!=NULL)
    {
	snprintf(buf,sizeof(buf),":psyPIPE:psyBNC@lam3rz.de NOTICE * :%s\r\n",what);
	writesock(lkm->sock->syssock,buf);
    }
}


/* creates a socket */

int createsocket(int syssock,int type,int index,int(*constructor)(int),int(*constructed)(int),int(*errorhandler)(int,int),int(*handler)(int),int(*destructor)(int))
{
    struct psockett *th;
    struct socketnodes *lkm;
    int flags,ret;
    int lsock;
    time_t tm;
    time(&tm);
    pcontext;
    lsock=syssock;
    if(syssock!=0)
    {
	lkm=getpsocketbysock(lsock);
	if (lkm!=NULL) return lsock; /* already existent.. so why the hell... */
    } else 
    	lsock = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);
    flags = fcntl(lsock,F_GETFL,0);
    ret = fcntl(lsock,F_SETFL,flags | O_NONBLOCK);
    lkm=socketnode;
    while (lkm!=NULL)
    {
	if (lkm->next==NULL || lkm->sock==NULL)
	{
	    if(lkm->sock!=NULL)
	    {
		lkm->next=(struct socketnodes *) pmalloc(sizeof(struct socketnodes));
		lkm=lkm->next;
	    }
	    lkm->sock=(struct psockett *) pmalloc(sizeof(struct psockett));
	    lkm->next=NULL;
	    th=lkm->sock;
	    th->type=type;
	    th->flag=SOC_NOUSE;
	    th->syssock=lsock;
#ifdef CRYPT
	    th->encryption=SE_NOENC;
#endif
	    th->constructor=constructor;
	    th->constructed=constructed;
	    th->errorhandler=errorhandler;
	    th->handler=handler;
	    th->destructor=destructor;
	    th->commbuf=(char *)pmalloc(8192);
	    th->bytesin=0;
	    th->bytesout=0;
	    th->param=index;
	    snprintf(th->since,sizeof(th->since),"%s",ctime(&tm));
/*	    if(th->type==ST_LISTEN && lkm!=socketnode)
	    {
#ifdef BLOWFISH
		snprintf(ircbuf,sizeof(ircbuf),":Welcome!psyBNC@lam3rz.de NOTICE * :psyBNC2.1 [B508]\r\n");
#endif
#ifdef IDEA
		snprintf(ircbuf,sizeof(ircbuf),":Welcome!psyBNC@lam3rz.de NOTICE * :psyBNC2.1 [I128]\r\n");
#endif
#ifndef CRYPT
		snprintf(ircbuf,sizeof(ircbuf),":Welcome!psyBNC@lam3rz.de NOTICE * :psyBNC2.1 [N]\r\n");
#endif
		writesock(th->syssock,ircbuf);
	    }*/
	    break;
	}
	lkm=lkm->next;
    }
    if(lkm==NULL)
    {
	log("CANT ALLOCATE SOCKETSPACE - ABORTING");
	exit(0x0);
    }
    return lsock;
}

/* kill a socket. used instead of close. possibly called iterative */

int killsocket(int syssock)
{
    struct socketnodes *lkm;
    int(*caller)(int);
    int rc,i;
    pcontext;
    lkm=getpsocketbysock(syssock);    
    if(lkm==NULL || lkm==socketnode) return 0x0;
    if(lkm->sock!=NULL)
    {
	if(lkm->sock->destructor!=NULL)
	{
	    caller=lkm->sock->destructor;
	    lkm->sock->destructor=NULL;
	    rc=(*caller)(lkm->sock->param);
	    lkm=getpsocketbysock(syssock); /* if we are destroyed.. */
	    if(lkm==NULL) return 0x0;
	}
	for (i=0;i<MAX_SENDQ;i++)
	    flushsendq(lkm->sock->syssock,Q_FORCED);
	free(lkm->sock->commbuf);
	free(lkm->sock);
	previous->next=lkm->next;
	free(lkm);
    }
    shutdown(syssock,2);
    close(syssock);
    return 0x0;
}

/* conntectto - builds a connection to a host and port using a given vhost */

int rsock;

int connectto(int sockt,char *host,int port, char *vhost)
{
    int l, error;
    struct socketnodes *lkm;
    struct sockaddr_in sin;
    struct hostent *he;
    char myhost[15];
    char hishost[15];
    int flags, ret;
    pcontext;
    /* we got a server and a port */
    memset( &sin, 0, sizeof( struct sockaddr_in ));
    rsock = sockt;
    if (rsock < 1) return 0x0;
    if (vhost!=NULL) {
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = (	*vhost ? inet_addr(vhost) : INADDR_ANY );
	if(sin.sin_addr.s_addr == -1 && *vhost)
	{
    	    he = gethostbyname(vhost);
    	    if(!he) return 0x0;
    	    memcpy(&sin.sin_addr,he->h_addr,he->h_length);
        }
	snprintf(myhost,sizeof(myhost),"%s",inet_ntoa(sin.sin_addr));
	if(bind(rsock, (struct sockaddr *)&sin, sizeof(struct sockaddr_in)) < 0)
	{
	    snprintf(myhost,sizeof(myhost),"*");
	}
    }
    memset(&sin,0,sizeof(struct sockaddr_in));
    sin.sin_family = AF_INET;
    sin.sin_port = htons(port);
    sin.sin_addr.s_addr = inet_addr(host);
    if (sin.sin_addr.s_addr == -1)
    {
	he = gethostbyname(host);
	if (!he) return 0x0;
	memcpy(&sin.sin_addr,he->h_addr, he->h_length);
    }
    snprintf(hishost,sizeof(hishost),"%s",inet_ntoa(sin.sin_addr));
    ret =connect(rsock, (struct sockaddr *)&sin, sizeof(sin));
    if (ret < 0) {
        if (errno != EINPROGRESS && ret != -EINPROGRESS) goto connerr;
    }
    lkm=getpsocketbysock(rsock);
    if(lkm!=NULL)
    {
	lkm->sock->flag=SOC_SYN;
	lkm->sock->delay=0;
	if(socketnode->sock!=NULL)
	    lkm->sock->sport=socketnode->sock->sport;
	lkm->sock->dport=port;
	replace(myhost,'%',255);
	replace(hishost,'%',255);
	snprintf(lkm->sock->source,sizeof(lkm->sock->source),myhost);
	snprintf(lkm->sock->dest,sizeof(lkm->sock->dest),hishost);
    }
    return rsock;
connerr:
    killsocket(rsock);
    return 0x0;
}

int urgent=0;

/* flush the queue */

int flushsendq(int socket, int forced)
{
    struct socketnodes *lkm;
    struct sendqt *msq;
    lkm=getpsocketbysock(socket);
    if(lkm==NULL) return 0x0; /* no socket, no queue */
    msq=lkm->sock->sendq;
    if(msq==NULL) return 0x0; /* nothing to flush */
    if(lkm->sock->flag<SOC_CONN) return 0x0; /* not yet connected.. no flush */
    if(forced!=Q_FORCED)
    {
	if(msq->delay>0)
	{
	    msq->delay-=delayinc;
	    return 0x0;
	}
    }
    urgent=1;
    writesock(socket,msq->data);
    free(msq->data);
    msq=msq->next;
    free(lkm->sock->sendq);
    lkm->sock->sendq=msq;
    lkm->sock->entrys--;
    return 0x0;
}

/* add data to a queue */

int addq(int socket, char *data, int sqdelay)
{
    struct socketnodes *lkm;
    struct sendqt *msq;
    lkm=getpsocketbysock(socket);
    if(lkm==NULL) /* no socket descriptor, URGENT sent */
    {
	urgent=1;
	return writesock(socket,data);
    }
    lkm->sock->entrys++;
    if(lkm->sock->entrys>MAX_SENDQ)
	flushsendq(socket,Q_FORCED); /* too much entry -> flushing */
    if (lkm->sock->sendq==NULL)
    {
	lkm->sock->sendq=(struct sendqt *)pmalloc(sizeof(struct sendqt));
	msq=lkm->sock->sendq;
    } else {
	msq=lkm->sock->sendq;
	while(msq->next!=NULL) msq=msq->next;
	msq->next=(struct sendqt *)pmalloc(sizeof(struct sendqt));
	msq=msq->next;
    }
    msq->data=(char *)pmalloc(strlen(data)+2);
    msq->delay=sqdelay;
    snprintf(msq->data,strlen(data)+1,"%s",data);
    return 0x0;
}

/* write data to a socket */

int writesock (int socket, char *data)
{
    char buf[8200];
    char kbuf[30];
    char *po;
    struct socketnodes *lkm;
    lkm=getpsocketbysock(socket);
    if(lkm==NULL) return 0x0;
    if(lkm->sock->flag<SOC_CONN) urgent=0;
    if(urgent==0 && lkm->sock->nowfds != 1)
    {
	addq(socket,data,0);
	return 0x0;
    }
    if (socket == 0) return -1;
    snprintf(buf,sizeof(buf),"%s",data);
    po=strchr(buf,'\n');
//    if(po==NULL) po = strchr(buf,'\n');
    if (po == NULL) strcat(buf,"\r\n");
    if(po!=NULL)
    {
        po--;
        if (*po!='\r')
        {
    	    po++;
	    *po='\r';
	    po++;
	    *po='\n';
	    po++;
	    *po=0;
	}
    }
    errn=0;
    if(lkm!=NULL)
    {
	if(lkm->sock!=NULL)
	{
#ifdef CRYPT
	    if(lkm->sock->encryption==SE_ENC)
	    {
#ifdef BLOWFISH
		po=BLOW_stringencrypt(buf,lkm->sock->outcrkey);
		snprintf(buf,sizeof(buf),"[B]%s\r\n",po);
#endif
#ifdef IDEA
		po=IDEA_stringencrypt(buf,lkm->sock->outcrkey);
		snprintf(buf,sizeof(buf),"[I]%s\r\n",po);
#endif
		free(po);
	    }
#endif
	    lkm->sock->bytesout+=strlen(buf);
	}
    }
    if(urgent==1 || lkm->sock->nowfds == 1)
    {
	replace(buf,255,'%');
	write(socket,buf,strlen(buf));
	lkm->sock->delay=300;
#ifdef CRYPT
	if(lkm->sock->encryption==SE_ENC)
	{
	    lkm->sock->keydelay+=delayinc;
	    if(lkm->sock->keydelay>15)
	    {
		snprintf(kbuf,sizeof(kbuf),"%s",randstring(16));
		snprintf(buf,sizeof(buf),"ENC %s\r\n",kbuf);
#ifdef BLOWFISH
		po=BLOW_stringencrypt(buf,lkm->sock->outcrkey);
		snprintf(buf,sizeof(buf),"[B]%s\r\n",po);
#else
		po=IDEA_stringencrypt(buf,lkm->sock->outcrkey);
		snprintf(buf,sizeof(buf),"[I]%s\r\n",po);
#endif
		write(socket,buf,strlen(buf));
		snprintf(lkm->sock->outcrkey,sizeof(lkm->sock->outcrkey),"%s",kbuf);
		free(po);
		lkm->sock->keydelay=0;
	    }
	}
#endif
	urgent=0;	
    }
    if (errn == 1) {
       /* heavy error on writing */
       return -1;
    }
    return 0x0;
}

/* urgent writes */

int writesock_URGENT (int socket, char *data)
{
    urgent=1;
    return writesock(socket,data);
}

int writesock_DELAY (int socket, char *data, int delay)
{
    return addq(socket,data,delay);
}


int receivesock(struct psockett *sock)
{
    int ret=1,i;
    int sz=8191;
    int rc;
    char *br,*ebr;
    int kln;
    int esck;
    char *puk,*pt,*eh;
    char buf[4096],kbuf[20];
    pcontext;
    sz-=sock->bytesread;
    memset(ircbuf,0x0,sizeof(ircbuf));
    if(sz>0)
    {
	errno=0;
	ret=recv(sock->syssock,sock->commbuf+sock->bytesread,sz,0);
	if (ret>0) sock->bytesread+=ret;
	if (ret==-1 && ((errno == EWOULDBLOCK) || (errno == EAGAIN))) return 1;
	if (ret<=0) return ret;
    } else {
	*ircbuf=0;
	return 0x1;
    }
    if (ret>0) sock->bytesin+=ret;
    br=strchr(sock->commbuf,'\n');
    if(br==sock->commbuf) ret=0; /* nulline, ignore */
    esck=sock->syssock;
    while(br!=NULL && getpsocketbysock(esck)!=NULL && ret>0)
    {
    	br++; /* :) */
	memset(ircbuf,0x0,sizeof(ircbuf));
	memcpy((void *)ircbuf,(void *)sock->commbuf,(br-sock->commbuf));
	memcpy((void *)sock->commbuf,(void *)br,8192-((br-sock->commbuf)));
	sock->bytesread-=((br-sock->commbuf));
	memset((void *)sock->commbuf+sock->bytesread,0x0,(8191-sock->bytesread));
	replace(ircbuf,'%',255);
	ebr=strchr(ircbuf,'\r');
	if(ebr==NULL) ebr=strchr(ircbuf,'\n');
#ifdef CRYPT
	if(sock->encryption==SE_ENC)
	{
	    if(strstr(ircbuf,"[I]")==ircbuf)
	    {
		*ebr=0;
		br=IDEA_stringdecrypt(ircbuf+3,sock->incrkey);
		replace(br,'%',255);
		snprintf(ircbuf,sizeof(ircbuf),"%s",br);
		free(br);
	    } else
	    if(strstr(ircbuf,"[B]")==ircbuf)
	    {
		*ebr=0;
		br=BLOW_stringdecrypt(ircbuf+3,sock->incrkey);
		replace(br,'%',255);
		snprintf(ircbuf,sizeof(ircbuf),"%s",br);
		free(br);
	    } else {
		log("Warning, got nonecnrypted Data on an encrypted socket. Disconnecting.");
		killsocket(sock->syssock);
		return -1;		
	    }
	}
	if(strstr(ircbuf,"ENC ")==ircbuf)
	{
	    if(sock->encryption!=SE_ENC)
	    {
		*ircbuf=0;
		return 1;
	    } else {
		ebr=strchr(ircbuf,'\r');
		if(ebr==0) ebr=strchr(ircbuf,'\n');
		if(ebr!=NULL) *ebr=0;
		ebr=ircbuf+4;
		snprintf(sock->incrkey,sizeof(sock->incrkey),"%s",ebr);
		for (i=0;i<MAX_SENDQ;i++)
		    flushsendq(sock->syssock,Q_FORCED);
		*ircbuf=0;
		return 1;
	    }
	}
#endif
	esck=sock->syssock;
	if (sock->handler!=NULL && strlen(ircbuf)>1)
	{
	    pcontext;
	    rc=(*sock->handler)(sock->param);
	    pcontext;
	}
        if (getpsocketbysock(esck)==NULL) { ret=-1;break; }
	br=strchr(sock->commbuf,'\n');
	if(br==NULL) br=strchr(sock->commbuf,10);
    }
    return ret;
}

unsigned long oldsec=0;

/* central socketdriver event routine */

int socketdriver()
{
    fd_set rfds;
    fd_set wfds;
    struct socketnodes *th,*par;
    int rc,altsock;
    int fdscnt=0,wfdscnt=0;
    int sockit=0,sockat=9999,ret,noadv,ln,opt;
    int tt,optbuf;
    unsigned long sec;
    int sck;
    long otm;
    struct tm *xtm;
    struct socketnodes *lkm;
    struct timeval tv;
    int nowf=0;
    time_t tm;
    pcontext;
    /* checking the advancing timer */
    delayinc=0;
    time(&tm);
    xtm=gmtime(&tm);
    sec=xtm->tm_sec;
    if (sec!=oldsec) delayinc=1;
    oldsec=sec;
    th=socketnode;
    par=th;
    /* constructors / socket set / selects */
    FD_ZERO( &rfds);
    FD_ZERO( &wfds);
    while(th!=NULL)
    {
	rc=0;noadv=0;
	if(th->sock!=NULL)
	{
	    if (th->sock->syssock>sockit) sockit=th->sock->syssock;
	    if (th->sock->syssock<sockat) sockat=th->sock->syssock;
	    if (th->sock->flag==SOC_NOUSE)
	    {
		currentsocket=th;
		altsock=th->sock->syssock;
		pcontext;
		if(th->sock->constructor!=NULL)
		    rc=(*th->sock->constructor)(th->sock->param);
	        pcontext;
		th=par->next;
		if(th!=NULL)
		{
		    if(altsock==th->sock->syssock)
			th->sock->flag=SOC_SYN;    
		    else
			noadv=1;
		} else
		    noadv=1;
	    } else {
		if (th->sock->flag==SOC_SYN || th->sock->flag==SOC_CONN)
		{
		    FD_SET(th->sock->syssock, &rfds);
		    fdscnt++;
		    if(th->sock->flag==SOC_SYN || th->sock->sendq!=NULL)
		    {
			FD_SET(th->sock->syssock, &wfds);
			wfdscnt++;
		    }
		}
	    }
	}
	if(noadv==0)
	{
	    par=th;
	    th=th->next;
	}
    }
    if(sockat>sockit) sockat=sockit;
    /* selecting */
    pcontext;
    if (fdscnt==0) return 0x0;
    tv.tv_usec = 0;
    tv.tv_sec = 1;
    if(wfdscnt>0)
    	ln=select(sockit +1, &rfds, &wfds,NULL,&tv);
    else
    	ln=select(sockit +1, &rfds, NULL,NULL,&tv);
    if(ln<=0) return 0x0;
    th=socketnode;
    par=th;
    /* reading, connecting done, errorhandling */
    for(sck=sockit;sck>=sockat;sck--)
    {
	noadv=0;
	th=getpsocketbysock(sck);
	if(th!=NULL)
	{
	    currentsocket=th;
	    nowf=th->sock->nowfds;
	    if(th->sock->flag==SOC_SYN)
	    {
		if(FD_ISSET(sck,&rfds) || FD_ISSET(sck,&wfds))
		{
    		    opt=sizeof(optbuf);
    		    if (getsockopt(th->sock->syssock, SOL_SOCKET, SO_ERROR, &optbuf,&opt) >=0) 
		    {
			if(optbuf==0)
			{
			    /* connected */
			    th->sock->flag=SOC_CONN;
			    th->sock->delay=300;
			    if(th->sock->constructed!=NULL)
			    {
				pcontext;
				rc=(*th->sock->constructed)(th->sock->param);
				pcontext;
			    }
			}
		    } else {
		        optbuf==-1;
		    }
		    if(optbuf!=0) {
			/* error */
			th->sock->flag=SOC_ERROR;
			altsock=th->sock->syssock;
			if(th->sock->errorhandler!=NULL)
			{
//			    th->sock->destructor=NULL;
			    pcontext;
			    rc=(*th->sock->errorhandler)(th->sock->param,SERR_REFUSED);
			    pcontext;
			}
			if(getpsocketbysock(altsock)!=NULL)
			{
			    killsocket(th->sock->syssock);
			}
		    }	
		} else {
		    if(th->sock->flag==SOC_SYN && th->sock->type==ST_CONNECT)
		    {
			th->sock->delay+=delayinc;
			if(th->sock->delay>SOC_TIMEOUT)
			{
			    altsock=th->sock->syssock;
			    /* timed out, terminating socket and calling error */
			    if(th->sock->errorhandler!=NULL)
			    {
//				th->sock->destructor=NULL;
				pcontext;
				rc=(*th->sock->errorhandler)(th->sock->param,SERR_TIMEOUT);
				pcontext;
			    }
			    if(getpsocketbysock(altsock)!=NULL)
			    {
				killsocket(th->sock->syssock);
			    }
			}
		    }
		}
	    } else 
	    if (th->sock->flag==SOC_CONN) {
		noadv=0;
		if(FD_ISSET(sck,&rfds))
		{
		    if (th->sock->flag==SOC_CONN)
		    {
			altsock=th->sock->syssock;
			rc=receivesock(th->sock);
			th=par->next;
			if (getpsocketbysock(altsock)==NULL) rc=-1;
			if (rc<=0)
			{
			    killsocket(altsock);
			    noadv=1;
			}
		    }
		} else {
		    /* disconnection sensing at outgoing sockets */
		    if(th->sock->flag==SOC_CONN && th->sock->type==ST_CONNECT)
		    {
			th->sock->delay-=delayinc;
			if(th->sock->delay<=0)
			{
			    writesock_URGENT(th->sock->syssock,"\r\n");
			    th->sock->delay=300;
			}
		    }
		}
		if(FD_ISSET(sck,&wfds) && noadv==0)
		{
		    flushsendq(sck,Q_NEXT);
		}
	    }
	}
    }
    return 0x0;
}

