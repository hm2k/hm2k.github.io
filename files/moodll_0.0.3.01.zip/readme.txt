Moo.dll
=======

Addon for mIRC, reports various statistics.

Change log:
===========
13/12/00 - [0.0.3.01] : Added RAS statistics, however the output will depend
                        upon which operating system you are using;
                        NT4 = dialup name + modem name
                        Win98 = dialup name + modem name + connection speed
                        Win2K = dialup name + modem name + connection speed + duration
                        This is because some of the OS's lack the features to 
                        get some of the values (obviously).
                        Warning: I wouldn't try using this feature if you haven't
                        actually got an active dialup connection, mIRC will probably
                        crash.
                        I've tested it in Win98a and Win2K SP1 on a modem, and it works.
                        Should work with ISDN, won't report on multi link connections,
                        just the first ras connection it finds.
			Added Screen statistics, horizonalxvertical res + BPP.

31/08/00 - [0.0.2.13] : Made rambar optional, defaults to 10 bars though.
			Rewrote dll to make use of C++ classes, also fixed
			some bugs which should've caused it to crash, but didn't :P

20/08/00 - [0.0.2.01] : 'final'.
                        Decreased RamBar� back to 10 bars, made it less 'bright'
                        , though it will look shite on anything but a white/gray
                        background.
                        Removed additional CPU info to make it shorter, i.e. die
                        size, model number.

18/08/00 - [0.0.1.26] : Updated OS code a bit, still not got full Windows 2000
                        recognition, downloading the latest Platform SDK as I 
                        type this.
                        Increased the RamBar� to 20 bars ;) I could actually make
                        it customisable, but I like it hard-coded �D
                        
17/08/00 - [0.0.0.19] : Mostly done, except for OS code.

Loading:
1) stick both the .dll and .mrc files in your main mirc directory
2) fire up mirc, /load -rs moodll.mrc
3) use any of the following commands:

   /stat
         /say statistics to current channel / query window
   /statself
         /echo statistics to current window
   /uptime
         /say uptime to current channel / query window
   /connstat
         /say dialup connection statistics to current channel / query window
   /screenstat
	 /say screen statistics to current channel / query window

Unloading:
Should the script annoy you or something, you may unload it as follows:
1) in mirc, type /unload -rs moodll.mrc

Please customise the appearance thx.