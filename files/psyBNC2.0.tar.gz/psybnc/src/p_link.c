/************************************************************************
 *   psybnc2.1, src/p_link.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_link.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_LINK

#include <p_global.h>

/* look for a link by hostname and port */

int getlink(int peern)
{
    int i=1;
    pcontext;
    while (i<MAX_USER)
    {
	if (strlen(datalink(i)->host)==strlen(newpeer(peern)->host)) {
	    if (strstr(datalink(i)->host,newpeer(peern)->host)!=NULL) {
		if (datalink(i)->port==newpeer(peern)->lnkport)
		    return i;
	    }
	}
	i++;
    }
    return 0x0;
}

/* look for a link by name */

int getlinkbyname(char *namelink)
{
    struct linknodes *th;
    int i;
    pcontext;
    th=linknode;
    while (th!=NULL)
    {
	i=th->uid;
	if (strlen(datalink(i)->name)==strlen(namelink)) {
	    if (strstr(datalink(i)->name,namelink)!=NULL) {
		return i;
	    }
	}
	th=th->next;
    }
    return 0x0;
}
/* return a new link */

int getnewlink()
{
    int i=1;
    pcontext;
    D_CREATE=1;
    while (i<MAX_USER)
    {
	if (datalink(i)->type==0) return i;
	i++;
    }
    return 0x0;
}

/* linking a relay */

    
int linkrelayconnected(int nlink)
{
    char buf[400];
    int tmpsock;
    pcontext;
    tmpsock=datalink(nlink)->outsock;
    snprintf(ircbuf,sizeof(ircbuf),"USER %s %s 127.0.0.1 :%s\r\n",datalink(nlink)->iam,datalink(nlink)->iam,datalink(nlink)->iam);
    writesock(tmpsock,ircbuf);
    snprintf(ircbuf,sizeof(ircbuf),"NICK %s\r\n",datalink(nlink)->iam);
    writesock(tmpsock,ircbuf);
    snprintf(buf,sizeof(buf),"RELAY: User %s connected.",datalink(nlink)->iam);
    log(buf);
    return 0x0;
}

int errorrelaylink(int nlink, int errn)
{
    char buf[400];
    struct socketnodes *lkm;
    pcontext;
    snprintf(buf,sizeof(buf),"RELAY: User %s: cant connect.",datalink(nlink)->iam);
    log(buf);
    lkm=getpsocketbysock(datalink(nlink)->outsock);
    if(lkm!=NULL)
    {
	lkm->sock->errorhandler=NULL;
	killsocket(datalink(nlink)->outsock);
    }
    lkm=getpsocketbysock(datalink(nlink)->insock);
    if(lkm!=NULL)
    {
	lkm->sock->errorhandler=NULL;
	killsocket(datalink(nlink)->insock);
    }
    datalink(nlink)->instate=STD_NOCON;
    datalink(nlink)->outstate=STD_NOCON;
    datalink(nlink)->insock=0;
    datalink(nlink)->outsock=0;
    return -1;
}

int killrelaylink(int nlink)
{
    char buf[400];
    struct socketnodes *lkm;
    pcontext;
    snprintf(buf,sizeof(buf),"RELAY: User %s: lost connection.",datalink(nlink)->iam);
    log(buf);
    lkm=getpsocketbysock(datalink(nlink)->outsock);
    if(lkm!=NULL)
    {
	lkm->sock->destructor=NULL;
	killsocket(datalink(nlink)->outsock);
    }
    lkm=getpsocketbysock(datalink(nlink)->insock);
    if(lkm!=NULL)
    {
	lkm->sock->destructor=NULL;
	killsocket(datalink(nlink)->insock);
    }
    datalink(nlink)->instate=STD_NOCON;
    datalink(nlink)->outstate=STD_NOCON;
    datalink(nlink)->insock=0;
    datalink(nlink)->outsock=0;
    return -1;
}


/* link connected */

int connectedlink(int nlink)
{
    char buf[400];
    struct socketnodes *lkm;
    int tmpsock;
    pcontext;
    tmpsock=datalink(nlink)->outsock;
    snprintf(ircbuf,sizeof(ircbuf),"PSYBNC %s :%d\r\n",datalink(nlink)->name,listenport);
    writesock_URGENT(tmpsock,ircbuf);
    if(*datalink(nlink)->crkey!=0)
    {
	lkm=getpsocketbysock(tmpsock);
	if(lkm!=NULL)
	{
	    snprintf(lkm->sock->incrkey,sizeof(lkm->sock->incrkey),"%s",datalink(nlink)->crkey);
	    snprintf(lkm->sock->outcrkey,sizeof(lkm->sock->outcrkey),"%s",datalink(nlink)->crkey);
	    lkm->sock->encryption=SE_ENC;
	}
    }
    if (*datalink(nlink)->pass==0)
    {
	snprintf(datalink(nlink)->pass,sizeof(datalink(nlink)->pass),"%s",randstring(15));
	writelink(nlink);
    }
    snprintf(ircbuf,sizeof(ircbuf),"PASS %s\r\n",datalink(nlink)->pass);
    writesock(tmpsock,ircbuf);
    snprintf(ircbuf,sizeof(ircbuf),":*!*@%s RECURSIVE :%s\r\n",me,me);
    writesock(tmpsock,ircbuf);
    snprintf(ircbuf,sizeof(ircbuf),":*!*@* BWHO :\r\n");
    writesock(tmpsock,ircbuf);
    snprintf(buf,sizeof(buf),"LINK %d: connected to %s port %d.",
	nlink,datalink(nlink)->host,datalink(nlink)->port);
    log(buf);
    return 0x0;
}

int errorlink(int nlink,int errn)
{
    char buf[400];
    pcontext;
    snprintf(buf,sizeof(buf),"LINK %d: cannot connect to %s port %d.",
	nlink,datalink(nlink)->host,datalink(nlink)->port);
    killsocket(datalink(nlink)->outsock);
    datalink(nlink)->outstate=STD_NOCON;
    log(buf);
    return -1;
}

int killedlink(int nlink)
{
    char buf[400];
    pcontext;
    snprintf(buf,sizeof(buf),"LINK %d: connection to %s port %d lost.",
	nlink,datalink(nlink)->host,datalink(nlink)->port);
    log(buf);
    snprintf(buf,sizeof(buf),"Lost Link (%s)",datalink(nlink)->iam);
    sysparty(buf);
    killsocket(datalink(nlink)->outsock);
    datalink(nlink)->outstate=STD_NOCON;
#ifdef PARTYCHANNEL
    partylinklost();
#endif
    return -1;
}


/* the simplest way of the proxy - the relay handling */

int relay(int nlink)
{
    pcontext;
    if(currentsocket->sock->syssock==datalink(nlink)->outsock)
	writesock(datalink(nlink)->insock,ircbuf);
    if(currentsocket->sock->syssock==datalink(nlink)->insock)
	writesock(datalink(nlink)->outsock,ircbuf);
}

/* process a single link */

int processlink(int nlink, int sock, int state)
{
    struct usernodes *th,*th2;
    struct linknodes *lh;
    struct stringarray *lkm,*pre;
    int rc,rr=0;
    char *pt,*pt2;
    char buf[600];
    char l,k;
    char o[]="->";
    char i[]="<-";
    char r[]="R ";
    char sic[500];
    int last;
    pcontext;
    if (state!=STD_CONN) return 0x0;
    parse();
    pcontext;
    if (!ifcommand("IAM")) broadcast(nlink); /* if its the IAM message, it does NOT
						get broadcasted */
    pcontext;
    pt=strchr(ircto,'@');
#ifdef PARTYCHANNEL
    if(pt==NULL) pt=strchr(ircto,'*');
#endif
    pcontext;
    if (pt==NULL) goto notme;
    *pt=0;
    pt++;
    if(*ircto!='*' || strlen(pt)!=1)
    {
	if (strlen(pt)!=strlen(me)) goto notme;
	if (strstr(pt,me)==NULL) goto notme;
    }
    pcontext;
    if (ifcommand("QUERY"))
    {
	rc=checkuser(ircto);
	if (rc==0)
	{
	    snprintf(ircbuf,sizeof(ircbuf),":psyBNC!*@%s SYSMSG %s@%s :%s - No such user\r\n",me,ircnick,irchost,ircto);
	    broadcast(0);	    
	    return 0x0;
	}
#ifdef PARTYCHANNEL
	snprintf(ircbuf,sizeof(ircbuf),":$%s*%s!psyBNC@lam3rz.de PRIVMSG %s :%s\r\n",ircnick,irchost,user(rc)->nick,irccontent);
#else
	snprintf(ircbuf,sizeof(ircbuf),":$%s@%s!psyBNC@lam3rz.de PRIVMSG %s :%s\r\n",ircnick,irchost,user(rc)->nick,irccontent);
#endif
	writesock(user(rc)->insock,ircbuf);
	return 0x0;
    }
    pcontext;
    if (ifcommand("SYSMSG"))
    {
#ifdef PARTYCHANNEL
	if(strstr(ircbuf,":psyBNC!*@")==ircbuf)
	{
	    if(*ircto=='*') /* systemrequest */
	    {
		pt=strchr(irccontent,']');
		if(pt!=NULL)
		{
		    pt+=2;
		    if(*pt=='*')
		    {
			pt2=strchr(pt,'(');
			if (pt2!=NULL)
			{
			    pt+=2;
			    *pt2=0;
			    snprintf(buf,sizeof(buf),"%s*%s",pt,irchost);
			    if(partyadd(buf)==1)
			    {
				snprintf(buf,sizeof(buf),":$%s*%s!%s@%s. JOIN :" PARTYCHAN "\r\n",pt,irchost,pt,irchost);
				th=usernode;
				while(th!=NULL)
				{
				    rc=th->uid;
				    if(user(rc)->instate==STD_CONN && user(rc)->sysmsg==1 && user(rc)->parent==0)
				    {
					writesock(user(rc)->insock,buf);
				    }
				    th=th->next;
				}
				return 0x0;
			    }
			}
		    }
		}
	    }
	}
#endif
	rc=checkuser(ircto);
	if (rc!=0)
	{
	    snprintf(ircbuf,sizeof(ircbuf),":%s!psyBNC@lam3rz.de NOTICE %s :%s\r\n",ircnick,user(rc)->nick,irccontent);
	    writesock(user(rc)->insock,ircbuf);
	    return 0x0;
	}
    }
notme:
    pcontext;
    if (ifcommand("IAM"))
    {
	if(*ircnick==0)
	{
	    snprintf(buf,sizeof(buf),"This Link has no Name. Deleting.");
	    sysparty(buf);
	    killsocket(sock);
	    datalink(nlink)->instate=STD_NOCON;
	    datalink(nlink)->outstate=STD_NOCON;
	    datalink(nlink)->insock=0;
	    datalink(nlink)->outsock=0;
	    clearlink(nlink);
	    eraselinkini(nlink);
	    return 0x0;
	}
	snprintf(datalink(nlink)->iam,sizeof(datalink(nlink)->iam),"%s",ircnick);
	writelink(nlink);
    }
    pcontext;
    if (ifcommand("RECURSIVE"))
    {
	if (strlen(ircto)!=strlen(me)) goto br;
	if (strstr(ircto,me)==NULL) goto br;
	snprintf(buf,sizeof(buf),"LINK %d: RECURSIVE (%s:%d) - Erasing Link",
	  nlink,datalink(nlink)->host,datalink(nlink)->port);
	log(buf);
	killsocket(sock);
	datalink(nlink)->instate=STD_NOCON;
	datalink(nlink)->outstate=STD_NOCON;
	datalink(nlink)->insock=0;
	datalink(nlink)->outsock=0;
	clearlink(nlink);
	eraselinkini(nlink);
	return 0x0;	
    }
    pcontext;
    if (ifcommand("PARTY"))
    {
	th=usernode;
	while (th!=NULL) {
	    rc=th->uid;
	    if ((user(rc)->instate==STD_CONN && user(rc)->parent==0 && user(rc)->sysmsg==1) || rc==1)
	    {
#ifdef PARTYCHANNEL
		snprintf(sic,sizeof(sic),"%s",irccontent);
		strcpy(irccommand,"PRIVMSG");
		strcpy(ircto,PARTYCHAN);
		strcat(ircto," ");
		/* keeping being compatible with earlier versions requires this */
		if(strlen(ircnick)==6 && strstr(ircnick,"psyBNC")==ircnick)
		{
		    if(strstr(irccontent,"logged in.")!=NULL)
		    {
			pt=strstr(irccontent,"User ");
			if(pt!=NULL)
			{
			    pt+=5;
			    pt2=strchr(pt,' ');
			    if (pt2!=NULL) *pt2=0;
			    snprintf(ircnick,sizeof(ircnick),"%s",pt);
			    snprintf(buf,sizeof(buf),"%s@%s",pt,irchost);
			    strcpy(irccommand,"JOIN");
			    strcpy(irccontent,PARTYCHAN);
			    *ircto=0;
			    if(rr==0) { partyadd(buf); rr=1; }
			}
		    }
		    if(strstr(irccontent,"logged off.")!=NULL)    
		    {
			pt=strstr(irccontent,"User ");
			if(pt!=NULL)
			{
			    pt+=5;
			    pt2=strchr(pt,' ');
			    if (pt2!=NULL) *pt2=0;
			    snprintf(ircnick,sizeof(ircnick),"%s",pt);
			    snprintf(buf,sizeof(buf),"%s@%s",pt,irchost);
			    strcpy(irccommand,"PART");
			    strcpy(irccontent,"logged off");
			    if(rr==0) { partyremove(buf); rr=1; }
			}
		    }
		    if(strstr(irccontent,"Lost Link (")==irccontent)    
		    {
			pt=irccontent+11;
			snprintf(buf,sizeof(buf),"*%s",pt);
			pt2=strchr(buf,')');
			if(pt2!=NULL) *pt2=0;
			lkm=partyusers;
			pre=NULL;
			while(lkm!=NULL && rr==0)
			{
			    pt=strstr(lkm->entry,buf);
			    if(pt==NULL) pt=buf;
			    if(pt!=buf && strlen(pt)==strlen(buf))
			    {
				pt=lkm->entry+1;
				snprintf(ircbuf,sizeof(ircbuf),":%s!psyBNC@%s QUIT :Lost Link\r\n",lkm->entry,pt);
				th2=usernode;
				while(th2!=NULL)
				{
				    if(th->user->instate==STD_CONN && th->user->sysmsg==1)
				    {
					writesock(th->user->insock,ircbuf);
				    }
				    th2=th2->next;
				}
				if(pre==NULL)
				{
				    partyusers=lkm->next;
				} else {
				    pre->next=lkm->next;
				}
				free(lkm->entry);
				free(lkm);
				if(pre!=NULL)
				    lkm=pre->next;
				else
				    lkm=partyusers;
			    } else {
				pre=lkm;
				lkm=lkm->next;
			    }
			}
			rr=1;
		    }
		}
		snprintf(buf,sizeof(buf),":$%s*%s!%s@%s. %s %s:%s",
						    ircnick,irchost,ircnick,irchost,
						    irccommand,ircto,irccontent);
#else
		snprintf(buf,sizeof(buf),":$$!psyBNC@lam3rz.de PRIVMSG %s :[%s@%s] %s",
						    user(rc)->nick,
						    ircnick,irchost,irccontent);
#endif
		if(user(rc)->instate==STD_CONN && user(rc)->parent==0 && user(rc)->sysmsg==1)
		    writesock(user(rc)->insock,buf);						    
		snprintf(irccontent,sizeof(irccontent),"%s",sic);
	    }
	    th=th->next;
	}	
	return 0x0;
    }
    pcontext;
    if (ifcommand("BWHO"))
    {
	th=usernode;
	while (th!=NULL) {
	    rc=th->uid;last=0;
	    if (user(rc)->instate!=STD_NOUSE)
	    {
	       if (user(rc)->parent != 0) l='^'; else { l='*';last=1; }
	       if (user(rc)->sysmsg == 0) l='+';
	       if (*user(rc)->host==0) l=' '; else last=0;
	       if(last==1)
      	           snprintf(ircbuf,sizeof(ircbuf),":psyBNC!*@%s SYSMSG %s@%s :[%s] %c %s(%s) [%s:%s] :%s [last:%-20s]\r\n",me,ircnick,irchost,me,l,user(rc)->login,user(rc)->nick,user(rc)->network,user(rc)->server,user(rc)->user,user(rc)->last);
	       else	 
      	           snprintf(ircbuf,sizeof(ircbuf),":psyBNC!*@%s SYSMSG %s@%s :[%s] %c %s(%s) [%s:%s] :%s\r\n",me,ircnick,irchost,me,l,user(rc)->login,user(rc)->nick,user(rc)->network,user(rc)->server,user(rc)->user);
	       broadcast(0);						    
	    }
	    th=th->next;
	}
	return 0x0;	
    }
    pcontext;
    if (ifcommand("LISTLINKS"))
    {
	lh=linknode;	
	while (lh!=NULL)
	{	
	    rc=lh->uid;
	    l=' ';
	    if (datalink(rc)->type!=0)
	    {
		if (datalink(rc)->type==LI_LINK) 
		{
		    pt=o;
		    if (datalink(rc)->outstate==STD_CONN) l='*';
		}
		if (datalink(rc)->type==LI_ALLOW) 
		{
		    if (datalink(rc)->instate==STD_CONN) l='*';
		    pt=i;
		}
		if (datalink(rc)->type==LI_RELAY) { pt=r; l='*';}
		snprintf(ircbuf,sizeof(ircbuf),":psyBNC!*@%s SYSMSG %s@%s :[%s]%c%d %s %s %s(%d)\r\n",me,ircnick,irchost,me,l,rc,pt,datalink(rc)->iam,datalink(rc)->host,datalink(rc)->port); 
		broadcast(0);
	    }    
	    lh=lh->next;
	}
	return 0x0;
    }
    pcontext;
#ifdef PARTYCHANNEL
    if (ifcommand("TOPIC"))
    {
	snprintf(partytopic,sizeof(partytopic),"%s",irccontent);
	th=usernode;
	while (th!=NULL) {
	    rc=th->uid;
	    if (user(rc)->instate==STD_CONN && user(rc)->parent==0)
	    {
  	       snprintf(ircbuf,sizeof(ircbuf),":$%s*%s!%s@%s TOPIC " PARTYCHAN " :%s\r\n",
	                       ircnick,irchost,ircnick,irchost,irccontent);
	       writesock(user(rc)->insock,ircbuf);
	    }
	    th=th->next;
	}
    }
#endif
    pcontext;
br:
}

/* error handler for the link checking */

int checklinkerror(int nlink,int errn)
{
    checklinkkill(nlink);
}

/* Destructor for the link checking */

int checklinkkill(int nlink,int errn)
{
    int sock;
    char buf[400];
    pcontext;
    if(datalink(nlink)->type==LI_ALLOW)
	sock=datalink(nlink)->insock;
    else
	sock=datalink(nlink)->outsock;
    snprintf(buf,sizeof(buf),"Lost Link (%s)",datalink(nlink)->iam);
    sysparty(buf);
    snprintf(buf,sizeof(buf),"LINK %d: Lost Link.",nlink);
    log(buf);
    killsocket(sock);
    datalink(nlink)->instate=STD_NOCON;
    datalink(nlink)->outstate=STD_NOCON;
    datalink(nlink)->insock=0;
    datalink(nlink)->outsock=0;
#ifdef PARTYCHANNEL
    partylinklost();
#endif
    return 0x0;
}

/* checking a single linktraffic */

int checklinkdata (int nlink)
{
    pcontext;
    if (datalink(nlink)->type==0) return 0x0;
    if (datalink(nlink)->instate!=STD_CONN && datalink(nlink)->outstate!=STD_CONN) return 0x0;
    if (datalink(nlink)->type==LI_RELAY)
	relay(nlink);
    if (datalink(nlink)->type==LI_LINK)
	processlink(nlink,datalink(nlink)->outsock,datalink(nlink)->outstate);
    if (datalink(nlink)->type==LI_ALLOW)
	processlink(nlink,datalink(nlink)->insock,datalink(nlink)->instate);
}

/* linking a relay */

int linkrelay(int npeer, int rootlink)
{
    char buf[400];
    int tmpsock;
    struct socketnodes *lkm;
    int nlink;
    pcontext;
    snprintf(buf,sizeof(buf),"RELAY: User %s@%s (%s:%d): trying %s port %d (%s).",
         newpeer(npeer)->login,
	 datalink(rootlink)->name,
	 newpeer(npeer)->host,
	 newpeer(npeer)->lnkport,
	 newpeer(npeer)->server,
	 newpeer(npeer)->port,
	 newpeer(npeer)->vhost);
    log(buf);
    lkm=getpsocketbysock(newpeer(npeer)->insock);
    if(lkm!=NULL)
    {
	lkm->sock->flag=SOC_CONN;
	lkm->sock->param=npeer;
	lkm->sock->constructor=NULL;
	lkm->sock->constructed=NULL;
	lkm->sock->handler=checklinkdata;
	lkm->sock->errorhandler=errorrelaylink;
	lkm->sock->destructor=killrelaylink;
    }
    tmpsock=createsocket(0,ST_CONNECT,0,NULL,linkrelayconnected,errorrelaylink,checklinkdata,killrelaylink);
    tmpsock=connectto(tmpsock,newpeer(npeer)->server,newpeer(npeer)->port,newpeer(npeer)->vhost);
    if (tmpsock==0) goto conrrrr;
    nlink=getnewlink();
    if (nlink==0) {
	killsocket(tmpsock);
	log("out of linkdescriptors");
	return -1;
    }
    datalink(nlink)->type=LI_RELAY;
    datalink(nlink)->instate=STD_CONN;
    datalink(nlink)->insock=newpeer(npeer)->insock;
    snprintf(datalink(nlink)->iam,sizeof(datalink(nlink)->iam),"%s",newpeer(npeer)->nick);
    snprintf(datalink(nlink)->host,sizeof(datalink(nlink)->host),"%s",datalink(rootlink)->host);
    snprintf(datalink(nlink)->pass,sizeof(datalink(nlink)->pass),"%s",datalink(rootlink)->pass);
    snprintf(datalink(nlink)->name,sizeof(datalink(nlink)->pass),"%s",datalink(rootlink)->name);
    datalink(nlink)->port=datalink(nlink)->port;
    datalink(nlink)->outstate=STD_CONN;
    datalink(nlink)->outsock=tmpsock;
    clearpeer(npeer);
    lkm=getpsocketbysock(tmpsock);
    if(lkm!=NULL)
    {
	lkm->sock->flag=SOC_SYN;
	lkm->sock->param=nlink;
    }
    return 0x0;
conrrrr:
    snprintf(buf,sizeof(buf),"RELAY: cannot connect to %s port %d.",
	newpeer(npeer)->server,newpeer(npeer)->port);
    log(buf);
    return -1;
}

/* connect a single link */

int connectlink(int nlink)
{
    char buf[400];
    int tmpsock;
    pcontext;

    if (datalink(nlink)->type!=LI_LINK)
	return 0x0;
    if (datalink(nlink)->outstate==STD_CONN)
	return 0x0;
    if (datalink(nlink)->delayed>0)
    {
	datalink(nlink)->delayed-=delayinc;
	return 0x0;
    }
    datalink(nlink)->delayed=20;
    snprintf(buf,sizeof(buf),"LINK %d: Connecting to %s:%d.",
	 nlink,datalink(nlink)->host,datalink(nlink)->port);
    log(buf);
    /* we got a server and a port */
    tmpsock=createsocket(0,ST_CONNECT,nlink,NULL,connectedlink,errorlink,checklinkdata,killedlink);
    tmpsock=connectto(tmpsock,datalink(nlink)->host,datalink(nlink)->port,NULL);
    if (tmpsock==0) goto conrrr;
    datalink(nlink)->outstate=STD_CONN;
    datalink(nlink)->outsock=tmpsock;
    return 0x1;
conrrr:
    snprintf(buf,sizeof(buf),"LINK %d: cannot connect to %s port %d.",
	nlink,datalink(nlink)->host,datalink(nlink)->port);
    datalink(nlink)->outstate=STD_NOCON;
    log(buf);
    return -1;
}

/* checking unconnected links */

int checklinks()
{
    struct linknodes *th;
    int i;
    pcontext;
    th=linknode;
    while (th!=NULL)
    {
	i=th->uid;
	if (connectlink(i)==1) return 0x0;
	th=th->next;
    }
}
