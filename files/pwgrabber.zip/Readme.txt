
     ����    �� 
     �� ��   �� 
     ��  ��  �� 
     ��   �� �� 
     ��    ���� 
     ��     ��� 
     ��      �� 
    -<<NEMESIS>>-
      Presentz...

What    :  Happieman2000's Password Grabber v1.0
Made By :  HAPPIEMAN2000 [NEMESIS]

NOTES:
Saved passwords are great - one less thing to remember.  The dialog
appears with those charming asterisks and your simply hit enter.  Of 
course, there comes a time that you actually do need to remember 
that password - what to do???  

Happieman2000's Password Grabber allows you to 'see behind' the 
asterisks and remember the password.

How to...
	 > With the dialog containing the password visible start up Revelation.
	 > Left click on the 'Password Field Selector' and drag it over the password field
	 > Read the password in the 'Revealed Password' field.