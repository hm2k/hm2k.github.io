/************************************************************************
 *   psybnc2.1, src/p_hash.c
 *   Copyright (C) 1999 the most psychoid  and
 *                      the cool lam3rz IRC Group, IRCnet
 *			http://www.psychoid.lam3rz.de
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 1, or (at your option)
 *   any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef lint
static char rcsid[] = "@(#)$Id: p_hash.c, v 2.1 1999/11/08 02:34:00 psychoid Exp $";
#endif

#define P_HASH

#include <p_global.h>


/* the userbound relay processing */

int bound(int sockit)
{
    struct socketnodes *th,*th2;
    char *pt;
    th=getpsocketbysock(sockit);
    if(th==NULL) return 0x0;
    if(th->sock->adone==0 && th->sock->type==ST_LISTEN)
    {
	if(strstr(ircbuf,"NICK ")==ircbuf)
	{
	    snprintf(th->sock->nickline,sizeof(th->sock->nickline),"%s",ircbuf);
	}
	if(strstr(ircbuf,"PASS ")==ircbuf)
	{
	    snprintf(th->sock->passline,sizeof(th->sock->passline),"%s",ircbuf);
	}
	if(strstr(ircbuf,"USER ")==ircbuf)
	{
	    snprintf(th->sock->userline,sizeof(th->sock->userline),"%s",ircbuf);
	    snprintf(ircbuf,sizeof(ircbuf),":psyPIPE!psyBNC@lam3rz.de NOTICE * :Please do /QUOTE EPASS encryptionpassword\r\n");
	    writesock(sockit,ircbuf);
	}
	if(strstr(ircbuf,"EPASS ")==ircbuf)
	{
	    pt=strchr(ircbuf,'\r');
	    if(pt==NULL) pt=strchr(ircbuf,'\n');
	    if(pt!=NULL) *pt=0;
	    pt=ircbuf+6;
	    th2=getpsocketbysock(th->sock->relaysock);
	    if(th2!=NULL)
	    {
		snprintf(th2->sock->incrkey,sizeof(th2->sock->incrkey),"%s",pt);
		snprintf(th2->sock->outcrkey,sizeof(th2->sock->outcrkey),"%s",pt);
	    }
	    th->sock->adone=1;
	    snprintf(ircbuf,sizeof(ircbuf),"%s",th->sock->userline);
	    writesock_URGENT(th->sock->relaysock,ircbuf);
	    if(th2!=NULL)
		th2->sock->encryption=SE_ENC;
	    snprintf(ircbuf,sizeof(ircbuf),"%s",th->sock->nickline);
	    writesock_URGENT(th->sock->relaysock,ircbuf);
	    snprintf(ircbuf,sizeof(ircbuf),"%s",th->sock->passline);
	    writesock_URGENT(th->sock->relaysock,ircbuf);
	}
    } else {
	writesock(th->sock->relaysock,ircbuf);
    }
}
