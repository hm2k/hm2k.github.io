---------------------------------------------------
How to use:
---------------------------------------------------
[1]. Type the name of program you search for its crack/serial.
[2]. Select what you search for ,Crack or Serial.
[3]. Select the site number where the program will search, you can choose "All Sites" to search in all available sites.
[4]. Select the max results you want to show, if you prefer to search for all results choose "All"
[5]. Press "Search" button to start searching.
[6]. When the search complete, select the files you want to download from the list.
[7]. Check the option "Selected" to download selected items or check the option "All" to download all items.
[8]. Press "Download" button to start downloading.
---------------------------------------------------
Tips:
---------------------------------------------------
[9]. You can set the default folder to download the files to [Program -> Setting], else you'll be asked to select the folder when you press "Download"
[10]. The program use your current proxy configuration by default but you can set the proxy stting in setting window [Program -> Setting].
[11]. For best results choose [All Sites,20] for [3],[4] options.
---------------------------------------------------
** Move the mouse over any field to get help **
---------------------------------------------------
[ HiSoft - CrackDownloader v1.02 - 2005 ]
---------------------------------------------------