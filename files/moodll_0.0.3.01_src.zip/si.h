/*
moo.dll component file 
[si.h - header for system information class]
Copyright (C) 2000 Mark Hutton - mailto:mark@influenced.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#define WIN32_LEAN_AND_MEAN

#ifndef __SI_H_
#define __SI_H_
#define VERSION "0.0.3.1"

#define INTEL_P2_NORMAL "Pentium II"
#define INTEL_P2_CELERON "Celeron"
#define INTEL_P2_XEON "Pentium II Xeon"
#define INTEL_P3_NORMAL "Pentium III"
#define INTEL_P3_CELERON "Celeron"
#define INTEL_P3_XEON "Pentium III Xeon"
#define INTEL_P1_NORMAL "Pentium"
#define INTEL_P1_PRO "Pentium Pro"
#define AMD_K5 "K5"
#define AMD_K6 "K6"
#define AMD_K6_2 "K6/2"
#define AMD_K6_3 "K6/3"
#define AMD_K6_3PLUS "K6/3+"
#define AMD_K7 "Athlon K7"

class CSysInfo
{
	public:
	// Functions
	CSysInfo();
	~CSysInfo();
	void UpdateUptime();
	void UpdateCPU();
	void UpdateOSInfo();
	void UpdateMemInfo();
	void UpdateVersion();
	void UpdateConnection();
	void UpdateScreenInfo();
	// Variables
	char pstrUptime[100];
	char pstrCPU[100];
	char pstrOSInfo[100];
	char pstrMemInfo[100];
	char pstrVersion[100];
	char pstrConnection[200];
	char pstrScreenInfo[100];
	bool blRasCompat;
	bool blRas2K;
	bool blRas9X;

};

// *************************************************
//                Other functions
// *************************************************

#pragma warning(disable:4035)

inline unsigned __int64 theCycleCount(void)
{  
    _asm    _emit 0x0F
    _asm    _emit 0x31
}

#pragma warning(default:4035)

class CTimer
{
    unsigned __int64  m_start;
public:
    unsigned __int64  m_overhead;

    CTimer(void)
    {
        m_overhead = 0;
        Start();              /// we get the start cycle
        m_overhead = Stop();  // then we get the stop cycle catching the overhead time
    }

    void Start(void)
    {
        m_start = theCycleCount();
    }

    unsigned __int64 Stop(void)
    {
	/// with the stop cycle we remove the overhead's time
        return theCycleCount()-m_start-m_overhead;
    }
};

void GetProcessorType(char *proctext);
void GetProcessorVendor(char *vid);
int GetProcessorExtra(void);
void MSecToTime(unsigned long msectime, char *timestring, int timestrlen);

#endif